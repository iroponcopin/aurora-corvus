ASTRAEA V1.0.0 "The Celestial Sovereign & Blade Genesis"
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある jar を、Minecraft の mods フォルダーに入れる。
   - astraea-1.0.0+mc26.3.jar
2. Fabric API を同じフォルダーに入れる(上の版以上)。
3. サーバーで遊ぶ場合は、サーバー側にも同じ jar と Fabric API を入れる。

■ ご注意
- Fabric API のほかに要る MOD はありません。
- Cherry 1.2.0(26.3)と一緒に入れて動くことを確かめています。Alpha との同時導入には対応していません。
- 設定ファイル: config/astraea.json(Aegis の保護機能。すべて既定で有効)。
- 管理者用のコマンド: /aegis(OP 権限レベル 2 以上)— status・integrity・quarantine list / clear / release
- /astraeabench(クライアント): 幻影剣 32 本と毎秒の空間切断を 10 秒間描き、平均フレームレート・1% ロー・最悪のフレームを表示します。

■ 5 つの防壁ドア
- 置いたマスから上へ、幅と高さの分だけ 1 枚の壁として立ちます(幅 3 のドアは置いたマスを中央に、幅 2 のドアは置いたマスを
  左の列にします)。どのマスを壊しても、ドア全体が 1 つのアイテムに戻ります。
- 素手の右クリックか、レッドストーンの信号(入ると開き、切れると閉まる)で開け閉めします。
  通り抜けられるのは、仕掛けが本当に道を空けてからです。
- アイリス絞り型ヘビィ・ブラストドア(3×3): 6 枚の装甲羽根が渦を描いて枠へ畳まれます。
- モノリス油圧式重装両開きゲート(3×3): 閂が抜け、左右の扉が 2 枚折りで畳まれます。
- バイオメトリック・レーザーグリッドドア(2×3): 赤い格子が消え、ガラスが上の枠へ上がります。
- 極低温断熱ハーメチック・ドア(2×3): 4 つの留め金が外れ、蒸気と共に扉がまっすぐ抜けて上へ跳ね上がります。
- アストロラーベ天球ゲート(3×3): 金と白金の 3 つの輪が回って印を揃え、障壁が光になって消えます。

■ 錠(ドア・トラップドア・フェンスゲート・チェスト・樽に付けられます)
- 錠を持ってブロックに使うと取り付けます。付いた錠は、持ち主(と OP)でなければ壊せません。ブロックが壊れると錠も落ちます。
- 施錠中は、レッドストーンでドアや門は開かず、ホッパー(ホッパー付きトロッコ・ドロッパーも)は
  チェストや樽から吸い出しも入れ込みもできません。TNT とピストンは止まりません。
- 開いている錠は、持ち主がスニークして素手で使うと取り外せます(鍵・暗証番号・カードはそのまま残ります)。
- 強化鋼鉄の南京錠: 初めて取り付けたときに鍵(No. 付き)ができます。その鍵で開け閉めします。ピッキングもできます。
- 機械式ダイヤル暗証錠: 取り付けると 4 桁の暗証番号を決めます(スニークして取り付けると番号を消します)。
  正しい番号で 10 秒間開きます。3 回まで間違えられ、その後は 10 秒、倍々に最長 5 分まで入力できません
  (人ごと・錠ごと。ログアウトしても消えません)。
- 生体暗号シリアルスキャナー: 持ち主を登録します。持ち主がスニークして未登録の暗号キーカードを使うと、そのカードを登録します
  (人とカードそれぞれ 16 まで)。登録された人か、登録されたカードを持った人だけが 5 秒間通れます。ほかの人には赤い光とサイレン。

■ ピッキング
- ピッキングツール(ピック 8 本)を、施錠された南京錠に使うと始まります。一人称では、手元の錠に左手でテンションレンチ、
  右手でピックを差して操作します。
- マウスの左右(または A・D)でピックの角度、左ボタンを押し続ける(または Space)とシリンダーを回します。
- 正しい角度に近いほど、カチカチという音が速くなり、シリンダーが大きく回ります。
- 回らない角度で無理に回すと、ピックがしなって錠が震え、やがてピックが折れます。力を抜けば負担は戻ります。Esc でやめます。

■ 天星超合金と 5 つの天星ツール
- 天星超合金: ネザライトインゴット 1・ダイヤモンド 4・アメジストの欠片 4。
- 5 つの道具はネザライトと同じ段の上位の道具です。耐久 4500、採掘速度 14.0。燃えず、奈落に落ちても最後の持ち主の手に戻ります。
  天星超合金で修理できます。
- 天星の削岩鎚: 天星アクションキー(V)で掘る範囲を 1×1・3×3・5×5 に切り替えます。掘ったものはまとめてインベントリへ。
  打ったブロックより硬いものは残します。
- 天星の大伐斧: 丸太を切ると、つながった木を丸ごと(葉まで)伐ります。スニーク中は 1 本だけ。落ちたものは切り株に集まります。
  盾を構えた相手への一撃は盾を貫き、盾を 5 秒間使えなくします。
- 天星の地鎮鍬: スニークして使うと、前方 5×5 を使ったブロックの高さに均します(土・砂・砂利・雪など。石は残ります)。
- 天星の豊穣鎌: 1 マス耕すと周りの 5×5 を耕し、中央を水源にします。実った作物に使うと 5×5 の実りを収穫して植え直します。
- 天星の聖槍: 手の届きが 2.5 ブロック伸びます。走りながら攻撃すると 5.5 ブロック突進して貫きます(攻撃力の 300%)。
  使用を押し続けて放すと、光の槍を投げます(槍は手を離れず、すぐ戻ります)。

■ 宿星刀(天星超合金 2・棒 1。剣の形)
- 攻撃で抜刀します。抜刀そのものが一の太刀です。続けて攻撃すると地上で 4 連、空中で 3 連と兜割り(急降下)。
- 使用(構え)でパリィ。正面からの一撃を完璧な間で受けると、ダメージは無く、相手はよろめきます。矢も弾きます。
- 1.5 秒ほど何もしないと残心の後に納刀します。何かを斬っていれば、鍔が鳴った瞬間に、斬った相手すべてが
  その場で 3 度斬られます(神威のディレイ切断)。
- 大技では、画面が一線に沿って割れる「空間切断」が起きます(ゲームの「画面のゆがみ効果」の設定に従います)。
- 評価ランク(画面右上): 技を当てるほど D → C → B → A → S → SS → SSS と上がります。被弾で下がり、倒れると 0 に戻ります。
- 神性覚醒(SSS で刀を持っている間): 刀の速さ 1.5 倍、移動速度 +30%、攻撃速度 +50%、受けるダメージ半分。
- 星辰の幻影剣: 刀を持って天星アクションキー(V)かマウスの中ボタンで、見えている 24 ブロック以内の敵をロックオンします。
  8 本の光の剣が背後に浮かび、斬るたびに 1 本ずつ敵へ飛びます。
  幻影剣キー(R)で次の技: 螺旋防壁(8 秒間、剣が周りを回って斬る。再使用 12 秒)→ 重力雨(敵の上から降り注ぐ。再使用 15 秒)。
- 魂気: 刀で倒した相手の魂気(最大体力の 5 分の 1)が刀に流れ込みます。
- 天星の炉(鍛冶台でスニークして使う。刀を手に): 修復(摩耗 150 ごとに魂気 1)・鍛錬(次の段 × 10。1 段ごとに一撃 +2.5%、
  20 段で銘刀になり輝く)・討伐数の刻印(+10 に魂気 50)・秘技の解放(討伐数 50: 星落とし、200: 月輪、500: 天割)。

■ キー(設定の「操作」で変えられます)
- 天星アクション: V(ロックオン/削岩鎚の範囲)
- 幻影剣: 次の技: R

■ レシピ
作業台で作れます: ドア 5 種・錠 3 種・暗号キーカード・ピッキングツール・天星超合金・5 つの道具・宿星刀。
レシピは、作るまでレシピ本には出ません。南京錠の鍵は取り付けのときにできます。

■ ライセンス
MIT(LICENSES/ASTRAEA_MIT.txt)。


==================================================================

[English]

■ Requirements
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

■ Installing (client and server)
1. Put the jar from this zip's mods/ folder into Minecraft's mods folder:
   - astraea-1.0.0+mc26.3.jar
2. Put Fabric API into the same folder (the version above or newer).
3. For a server, install the same jar and Fabric API on the server too.

■ Notes
- No other mod is needed besides Fabric API.
- Tested together with Cherry 1.2.0 (26.3). Installing it together with Alpha is not supported.
- Settings: config/astraea.json (the Aegis protections; all on by default).
- Admin command: /aegis (operator permission level 2 or higher) — status, integrity, quarantine list / clear / release.
- /astraeabench (client): draws 32 phantom blades and a space cut every second for 10 seconds, then reports the average frame
  rate, the 1 % low and the worst frame.

■ Five blast doors
- A door stands as one wall of its width and height, rising from the block you place it on (a 3-wide door is centred on that
  block, a 2-wide door has it as its left column). Breaking any part of it gives back the whole door as one item.
- Open and close it with an empty hand (use) or with redstone (a signal opens it, losing the signal closes it). You can walk
  through only once the mechanism has really cleared the way.
- Iris Aperture Blast Door (3×3): six armoured blades spiral and fold back into the frame.
- Monolithic Hydraulic Double Gate (3×3): the bolts withdraw and each leaf folds as a two-panel concertina.
- Biometric Laser-Grid Hatch (2×3): the red grid powers down and the glass rises into the housing.
- Sub-Zero Hermetic Cryo-Door (2×3): four clamps release, and with a burst of steam the leaf slides straight out and swings up.
- Celestial Astrolabe Gate (3×3): three gold and platinum rings turn until their marks meet, and the barrier dissolves into light.

■ Locks (for doors, trapdoors, fence gates, chests and barrels)
- Use a lock on a block to fit it. Only its owner (or an operator) can break a locked block; if the block breaks, the lock drops.
- While locked, redstone opens no door or gate, and no hopper (nor hopper minecart or dropper) takes from or puts into the
  chest or barrel. TNT and pistons are not stopped.
- The owner takes down an open lock by sneaking and using it with an empty hand; it keeps its key, PIN and cards.
- Hardened Steel Padlock: its numbered key is cut when it is first fitted. The key locks and unlocks it. It can be picked.
- Mechanical Combination Lock: when fitted it asks its owner for a 4-digit PIN (fitting it while sneaking clears the PIN).
  The right PIN opens it for 10 seconds. Three wrong tries are free; after that input is refused for 10 seconds, doubling each
  time up to 5 minutes (per player and per lock; logging out does not reset it).
- Biometric Cipher Lock: enrols its owner. The owner, sneaking, uses a blank Encrypted Keycard on it to enrol the card (up to 16
  people and 16 cards). Enrolled people, and anyone holding an enrolled card, may pass for 5 seconds; anyone else gets the red
  light and the siren.

■ Lockpicking
- Use a Lockpick Kit (8 picks) on a locked padlock. In first person you see the lock at hand: the tension wrench under your left
  hand, the pick under your right.
- Move the mouse left and right (or A and D) to set the pick's angle; hold the left button (or Space) to turn the cylinder.
- The nearer the pick is to the right angle, the faster the clicks and the further the cylinder turns.
- Forcing a cylinder that will not turn bends the pick and shakes the lock until the pick snaps; easing off lets the strain
  relax. Esc stops.

■ Celestial alloy and the five Celestial tools
- Astraea Celestial Ingot: 1 netherite ingot, 4 diamonds and 4 amethyst shards.
- The five tools sit at netherite's tier and above it: 4,500 uses, mining speed 14.0. They do not burn, and one that falls out of
  the world returns to its last holder's inventory. Repair them with the ingot.
- Celestial Pickaxe: the Celestial Action key (V) switches its area between 1×1, 3×3 and 5×5; everything mined goes into your
  inventory. Blocks harder than the one struck are left.
- Celestial Axe: cutting a log fells the whole connected tree, leaves included (sneaking cuts one log); the drops gather at the
  stump. Its blows go through a raised shield and disable it for 5 seconds.
- Celestial Shovel: sneak and use to level the 5×5 ahead to the height of the block used on (earth, sand, gravel, snow …;
  stone is left).
- Celestial Hoe: tilling one block tills the 5×5 around it and makes the centre a water source; used on a ripe crop it harvests
  the 5×5 and replants.
- Celestial Spear: +2.5 blocks of reach. Attack while sprinting to dash 5.5 blocks, piercing everything (300 % damage). Hold use
  and release to throw a spear of light (the spear never leaves your hand; it is back at once).

■ Celestial Blade (2 Celestial Ingots and a stick, in a sword's shape)
- Attack draws it; the draw is the first cut. Keep attacking: four cuts on the ground, or three in the air and a diving
  helm-splitter.
- Use (guard) to parry: a blow from in front caught in the perfect window does no damage and staggers the attacker; arrows are
  turned aside too.
- After about 1.5 seconds without input it rests (zanshin) and is sheathed. If it struck anything, then as the guard clicks home
  every foe it struck is cut again where it stands, three times (the delayed cleave).
- The great strikes part the screen along a line — the space cut (it follows the game's Distortion Effects setting).
- Style rank (top right): landing techniques raises it from D through C, B, A, S and SS to SSS; blows taken lower it; death
  resets it.
- Sovereign awakening (at SSS, blade in hand): blade tempo ×1.5, movement +30 %, attack speed +50 %, half damage taken.
- Phantom starlight blades: with the blade in hand, press Celestial Action (V) or the middle mouse button to lock on to a foe in
  sight within 24 blocks. Eight blades of light hang behind you, and one flies at the foe with each of your cuts. The Phantom
  Blades key (R) calls the next technique: Spiral Drive (8 seconds of blades circling you; 12 s cooldown), then Blistering Rain
  (they fall on the foe from above; 15 s cooldown).
- Soul energy: each foe the blade fells pours a fifth of its maximum health into it as soul energy.
- The Celestial Forge (sneak and use a smithing table, blade in hand): mend (1 soul energy per 150 points of wear), temper
  (10 × the next level; +2.5 % to every blow per level; the twentieth makes a named blade that gleams), inscribe defeats
  (+10 for 50 soul energy), and unlock the secret arts (at 50, 200 and 500 defeats: Starfall, Lunar Ring, Heaven's Rift).

■ Keys (change them under Controls)
- Celestial Action: V (lock on / pickaxe area)
- Phantom Blades, next technique: R

■ Recipes
Made at a crafting table: five doors, three locks, the Encrypted Keycard, the Lockpick Kit, the Celestial Ingot, the five tools
and the Celestial Blade. A recipe shows in the recipe book once you have made it. A padlock's key is cut when the padlock is
fitted.

■ Licence
MIT (LICENSES/ASTRAEA_MIT.txt).
