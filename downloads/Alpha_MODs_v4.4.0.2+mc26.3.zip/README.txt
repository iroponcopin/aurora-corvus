ALPHA HAS BEEN RETIRED / Alpha は廃止されました
================================================
Version 4.4.0.2 for Minecraft 26.3 - the last Alpha release.
4.4.0.2(Minecraft 26.3 用)- Alpha の最後の版です。


ENGLISH
-------
What this update does
  It switches Alpha off. The 13 Alpha mods are replaced by 13 placeholders that add nothing to
  the game. This ZIP holds no Alpha content: only those 13 placeholder jars and this file.

BACK UP YOUR WORLDS FIRST
  Blocks that Alpha added turn into empty air when a world is opened without Alpha. Once the
  world has been saved that way they are gone for good: putting Alpha back afterwards does not
  bring them back (measured on a dedicated server, 2026-09-28). Alpha's items and creatures are
  expected to go the same way (not tested). Copy your saves folder somewhere safe before you update.

Builds high up in the overworld
  Alpha raised the overworld's ceiling from Y=319 to Y=1023. The alpha-sky placeholder keeps that
  ceiling, so what you built above Y=319 with ordinary blocks is not deleted. Keep alpha-sky-4.4.0.2+mc26.3.jar
  for as long as you want those builds. If you remove it, the ceiling drops back to Y=319 and
  everything above it is deleted for good the next time the world is saved (measured).

If you use Corvus
  Nothing to do. Corvus offers this as a normal update; it removes the old Alpha jars, places the
  placeholders and keeps a backup of the files it replaced (its update log names the folder).
  Cherry, OUKA and Aureum are separate and are not touched.

If you installed by hand, or run a server
  1. Close Minecraft (or stop the server).
  2. In your mods folder, delete every file whose name starts with "alpha-" or "glimpse-alpha-"
     and does not end in "4.4.0.2+mc26.3.jar" (for example alpha-guns-4.4.0.1+mc26.3.jar).
  3. Copy the placeholder jars from this ZIP into the mods folder. At least copy
     alpha-sky-4.4.0.2+mc26.3.jar (see "Builds high up in the overworld").
  4. Server admins: config/sorakaze_sapporo/data/sapporo_mode_a.spro is no longer needed.
  Keep fabric-api and the mods of other brands (Cherry, OUKA, Aureum, Sodium ...) as they are.

A server and its players must move together: a player who still has Alpha cannot join a server
that no longer does, and the other way round.


日本語
------
この更新がすること
  Alpha を止めます。Alpha の 13 個の MOD を、ゲームに何も足さない 13 個のプレースホルダーに
  置き換えます。この ZIP に Alpha の中身はありません。プレースホルダーの jar 13 個とこのファイルだけです。

先にワールドのバックアップを
  Alpha が足したブロックは、Alpha 無しでワールドを開くと空気(何も無い空間)になります。
  その状態で 1 度保存されると、完全に消えます。あとから Alpha を戻しても戻りません
  (2026-09-28 に専用サーバーで測りました)。Alpha のアイテムと生き物も同じように消えると
  考えられます(試していません)。更新の前に saves フォルダーを安全な場所へコピーしてください。

オーバーワールドの高い所の建築
  Alpha はオーバーワールドの天井を Y=319 から Y=1023 に上げていました。alpha-sky の
  プレースホルダーがその天井をそのまま保つので、Y=319 より上に普通のブロックで建てたものは
  消えません。残したい間は alpha-sky-4.4.0.2+mc26.3.jar を残してください。これを外すと天井が
  Y=319 に戻り、それより上にあるものは次にワールドが保存されたときに完全に消えます(測りました)。

Corvus を使っている場合
  何もする必要はありません。Corvus が通常の更新として案内し、古い Alpha の jar を消して
  プレースホルダーを置き、置き換えたファイルのバックアップを残します(場所は更新ログに出ます)。
  Cherry・OUKA・Aureum は別のものなので、触りません。

手で入れた場合、またはサーバーの場合
  1. Minecraft を閉じます(サーバーは止めます)。
  2. mods フォルダーの中で、名前が「alpha-」または「glimpse-alpha-」で始まり、
     「4.4.0.2+mc26.3.jar」で終わらないファイルをすべて削除します
     (例: alpha-guns-4.4.0.1+mc26.3.jar)。
  3. この ZIP のプレースホルダーの jar を mods フォルダーへコピーします。少なくとも
     alpha-sky-4.4.0.2+mc26.3.jar はコピーしてください(「オーバーワールドの高い所の建築」を参照)。
  4. サーバー管理者: config/sorakaze_sapporo/data/sapporo_mode_a.spro は不要になります。
  fabric-api と、他のブランド(Cherry・OUKA・Aureum・Sodium など)の MOD はそのままにします。

サーバーとプレイヤーは同時に移ってください。Alpha を残したプレイヤーは Alpha をやめた
サーバーに入れず、その逆も同じです。
