Cherry Framework V1.0.1 "The Lunar Genesis Update"
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - cherry-1.0.1+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar(GeckoLib。MIT ライセンス。改変せずに同梱)
2. Fabric API も mods フォルダーに入れる。
3. 起動する。ワールドの設定を変える必要はありません。

■ はじめ方(月へ行く)
1. 発射台を置く(周り 3×3 に空きが要ります)。Cherry Apex-1 を発射台の上で使うと、台に固定されて立ちます。
2. 推進剤キャニスターを持ってロケットを右クリックして給油する。1 本で 250、満タンは 1000。月へは 600、地球へは 300 使います。
3. 右クリックで乗り込み、ジャンプを 1 秒長押しすると秒読み(T-5)が始まります。
4. 上昇中の Y300〜Y800 は姿勢補正区間です。W/A/S/D で十字を補正サークルの中心に保つほど速く昇り、ずっと中心なら Y300 から Y1000 までの時間が半分になります。
5. Y1000 で月へ入ります。降下中は W/A/S/D で着陸地点を修正できます。
6. 月から帰るときは、着陸したロケットに乗ってジャンプを 1 秒長押し。飛び立った発射台の近くに降りれば、その台の上に戻ります。
7. 降りるときは、発射台や地面の上でスニーク(飛行中は降りられません)。
8. ロケットを持ち帰るには、素手でスニークしながら右クリック(燃料と帰る発射台を覚えています)。

■ 月面
- 重力と落下ダメージはバニラの 1/6 です。
- 空気がありません。与圧スーツを 4 部位すべて着るか、気密フィールド投射機の周り(半径 12 ブロック)にいるか、ロケットに乗っていないと、毎秒 最大体力の 15% の減圧ダメージを受けます。
- 音は低い音しか伝わりません(ヘルメットの中の呼吸、足元の振動、無線ノイズははっきり聞こえます)。
- 3 つの素材
  - レゴリス・コア … 深いクレーターの底の下に鉱床があります。超音波カッターを鉱床に向けて長押しし、針が共振帯に重なった瞬間に放します(ツルハシでは砕けて何も残りません)。
  - コズミック・ヘリウム 3 セル … 月の海(暗い平原)にヘリウム 3 噴出孔があります。噴き出している間にクライオキャニスターを使います。
  - ヴォイド・クォーツ … 月にいると 5〜10 分おきに近くへ微小隕石が落ち、クレーターの中心に結晶が残ります。

■ 分子共鳴融合炉と超越融合
- 画面はありません。素材を持って右クリックすると、レシピに要る数だけが入ります。素手で右クリックすると完成品を(無ければ最後に入れた物を)取り出します。
- レゴリス・コア ×2 + ヘリウム 3 セル ×4 + ヴォイド・クォーツの欠片 ×2 + チェリー・コア ×1 → アストラル・カタリスト
- アストラル・カタリスト + 武器・道具・防具 1 つ → 超越融合
  攻撃力・採掘速度・防御力・防具強度が 3 倍、ノックバック耐性が 1 部位ごとに +25%、空の下では毎秒 耐久値が 2 回復します。
- アストラル・リフト … 超越融合した胸当てを着て、ジャンプを 2 回押して 2 回目を長押し。重力を離れ、運動量を保ったまま空中を滑るように動けます(W/S は視線の向き、A/D は横)。宇宙エネルギーを毎秒 5 使います。
- ディメンショナル・クリーヴ … 超越融合した剣・斧・メイス・トライデント・槍で、右クリックを 1 秒以上長押ししてから放します。前方 25 ブロックの空間を十字に切り、敵に攻撃力の 300% を防具を無視して与えます(宇宙エネルギー 100、待ち時間 3 秒)。

■ 管理者向けコマンド(OP 権限)
- /cherry meteor … 自分の近くに隕石を落とす(月のみ)
- /cherry moon、/cherry earth … 同じ座標の地表へ移動
- /cherry overdrive … 手に持った装備を超越融合する

■ ライセンス
Cherry は MIT ライセンスです(LICENSES/Cherry_MIT.txt)。
GeckoLib は MIT ライセンスで、改変せずに同梱しています(LICENSES/GeckoLib_MIT.txt)。

------------------------------------------------------------------

[English]

REQUIREMENTS
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

INSTALL (client and server)
1. Put both jars from this zip's mods/ folder into your Minecraft mods folder:
   - cherry-1.0.1+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar (GeckoLib, MIT licence, bundled unmodified)
2. Put Fabric API in the mods folder as well.
3. Start the game. No world settings need to change.

GETTING TO THE MOON
1. Place a Launch Pad (it needs a clear 3x3 area). Use the Cherry Apex-1 on the pad and it stands docked.
2. Right-click the rocket holding a Propellant Canister to refuel: 250 per canister, 1000 when full. The Moon costs 600, the way home 300.
3. Right-click to board, then hold Jump for one second to start the T-5 countdown.
4. Between Y300 and Y800 during the ascent is the alignment window. Keep the cross in the centre of the correction circle with W/A/S/D: the better you hold it, the faster you climb, and holding it perfectly halves the time from Y300 to Y1000.
5. At Y1000 you enter the Moon. During the descent W/A/S/D steers the landing.
6. To return, board the landed rocket and hold Jump for one second. If you land near the pad you launched from, you settle back onto it.
7. Sneak to leave the cockpit while docked or landed (you cannot leave in flight).
8. To pick the rocket up, sneak and right-click it with an empty hand (it keeps its fuel and its home pad).

ON THE MOON
- Gravity and fall damage are 1/6 of vanilla.
- There is no air. Unless you wear all four Pressure Suit pieces, stand within 12 blocks of a Pressure Field Projector, or ride the rocket, vacuum takes 15% of your maximum health every second.
- Only low sounds carry (your breathing in the helmet, footsteps felt through the suit and radio noise stay clear).
- Three materials:
  - Lunar Regolith Core: deposits sleep beneath the floors of deep craters. Hold an Ultrasonic Cutter on the deposit and release while the needle sits in the resonance band (a pickaxe only shatters it).
  - Cosmic Helium-3 Cell: Helium-3 geysers stand on the maria (the dark plains). Use a Cryo Canister while one is erupting.
  - Void Quartz: while you are on the Moon a micrometeorite strikes nearby every 5 to 10 minutes and leaves a crystal at the crater's centre.

RESONANCE CRUCIBLE AND OVERDRIVE
- There is no screen. Right-click with materials and the crucible takes exactly as many as the recipe still needs. Right-click with an empty hand to take the result (or, without one, the last thing you put in).
- Lunar Regolith Core x2 + Cosmic Helium-3 Cell x4 + Void Quartz Fragment x2 + Cherry Core x1 -> Astral Catalyst
- Astral Catalyst + one weapon, tool or armour piece -> Overdrive
  Attack damage, mining speed, armour and armour toughness x3, knockback resistance +25% per piece, and 2 durability repaired every second under open sky.
- Astral Lift: wearing an overdriven chestplate, press Jump twice and hold the second press. You leave gravity behind and slide through the air keeping your momentum (W/S along your view, A/D sideways). Uses 5 cosmic energy per second.
- Dimensional Cleave: with an overdriven sword, axe, mace, trident or spear, hold Use for at least one second, then release. The space ahead is cut in a cross for 25 blocks, dealing 300% of your attack damage to enemies through armour (100 cosmic energy, 3-second cooldown).

OPERATOR COMMANDS
- /cherry meteor: strike a meteor near you (Moon only)
- /cherry moon, /cherry earth: move to the surface at the same coordinates
- /cherry overdrive: overdrive the item in your main hand

LICENCES
Cherry is MIT licensed (LICENSES/Cherry_MIT.txt).
GeckoLib is MIT licensed and bundled unmodified (LICENSES/GeckoLib_MIT.txt).
