Cherry Framework V1.1.4 "The Aerospace and Naval Update"
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ V1.1.4 で変わったこと
- 音の出力の機器が変わっても(イヤホンの抜き差し、設定で機器を選ぶ)、飛行機のエンジン・アフターバーナー・ミサイルのモーター・ロックの音が
  すぐにひとりでに鳴り直します。1.1.0〜1.1.3 では、乗り直すまで消えたままでした(機器が変わるとゲームが音のエンジンを作り直し、鳴り続ける
  音をすべて止めるため)。
- 月では、宇宙服の呼吸も同じように鳴り直します(1.1.0〜1.1.3 はヘルメットを被り直すまで消えていました)。

■ V1.1.3 で変わったこと
- 操縦を、誰でもかんたんに動かせるよう作り直しました。視点の固定をやめ、飛行機は見た方へ飛び、艦はボートと同じ W・A・S・D で動きます
  (下の「飛行機」「艦艇」)。1.1.2 の飛行機のキー(R・U・Y・K・Z・N・M・J と矢印キー)と舵輪のキー(, . = - ; ')は無くなりました。
- 艦の不具合を 4 つ直しました: 舵がキーと逆に回った、後進が効かなかった、岸から艦を降ろせなかった、サバイバルで艦を回収できなかった。
- 主砲の弾が当たるようになりました。1.1.0〜1.1.2 の主砲は、撃っても何も傷つけていませんでした。弾は進む先で最初に当たった物
  (ブロック・生き物・艦・飛行機)で炸裂し、周り 4 m の生き物と艦・飛行機に傷を与えます。撃った艦と乗っている人は傷つけず、
  地形は壊しません。艦や飛行機のどこを見ても、2 基の砲はその船体・機体の上の点へ向きます。
- 砲術席に就いている間と斉射のたびに、見えない遠くのチャンクまで読み込んでいたのを直しました。
- 名前を付けた物を手に持った人が Cherry の兵器で倒すと、死亡メッセージが翻訳されない文字列のまま出ていたのを直しました。
- Aegis-X の計器の左下にあるミサイルの数が、画面の下端で切れていたのを直しました(GUI の大きさが「自動」のとき、720p・1440p・4K や
  ゲームの既定の窓など、多くの画面の大きさで切れていました)。
- 海図の航路の点は、いちばん広い縮尺で見える範囲(艦から約 1.4 km)の中だけ受け付けます。不正な航路の要求からサーバーを守るため
  でもあります。

■ V1.1.2 で変わったこと
- 2 隻の艦に本番の模型と艦内が入りました(船体・甲板・艦橋・CIC・客室・車両甲板。見えている甲板はどれも歩けます)。
- 艦の持ち場がすべてゲームの中から使えるようになりました。1.1.0 と 1.1.1 では、レールガン・VLS・海図台を実際には使えませんでした。
- Dreadnought 級は 3 連装砲塔 2 基に。斉射の閃光・衝撃波・弾道の光と砲身の後退、VLS のハッチと白煙、船首の波と航跡、スクリューの泡。
- Leviathan 級のバウバイザーと船首・船尾ランプが開きます(止まっている時だけ)。
- 舵輪のキーを Minecraft 自身のキーと重ならない位置へ移し、舵輪の計器をホットバーと体力の上へ上げました。
  キーの名前が変わったので、1.1.0・1.1.1 で変えた舵輪のキーの割り当ては付け直してください。

■ V1.1.1 で直したこと
- ビデオ設定の「透明物の描画の改良」を有効にしていると、Cherry Aegis-X のアフターバーナーを点けた瞬間にゲームが落ちていました。
  直しました。噴流のショックダイヤモンドは、コックピットからキャノピー越しにも見えます。

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - cherry-1.1.4+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar(GeckoLib。MIT ライセンス。改変せずに同梱)
2. Fabric API も mods フォルダーに入れる。
3. 起動する。ワールドの設定を変える必要はありません。

■ はじめ方(月へ行く)
1. 発射台を置く(周り 3×3 に空きが要ります)。Cherry Apex-1 を発射台の上で使うと、台に固定されて立ちます。
2. 推進剤キャニスターを持ってロケットを右クリックして給油する。1 本で 250、満タンは 1000。月へは 600、地球へは 300 使います。
3. 右クリックで乗り込み、ジャンプを 1 秒長押しすると秒読み(T-5)が始まります。
4. 上昇中の Y300〜Y800 は姿勢補正区間です。W/A/S/D で十字を補正サークルの中心に保つほど速く昇り、ずっと中心なら Y300 から Y1000 までの時間が半分になります。
5. Y1000 で月へ入ります。降下中は W/A/S/D で着陸地点を修正できます。
6. 月から帰るときは、着陸したロケットに乗ってジャンプを 1 秒長押し。飛び立った発射台の近くに降りれば、その台の上に戻ります。
7. 降りるときは、発射台や地面の上でスニーク(飛行中は降りられません)。
8. ロケットを持ち帰るには、素手でスニークしながら右クリック(燃料と帰る発射台を覚えています)。

■ 月面
- 重力と落下ダメージはバニラの 1/6 です。
- 空気がありません。与圧スーツを 4 部位すべて着るか、気密フィールド投射機の周り(半径 12 ブロック)にいるか、ロケットに乗っていないと、毎秒 最大体力の 15% の減圧ダメージを受けます。
- 音は低い音しか伝わりません(ヘルメットの中の呼吸、足元の振動、無線ノイズははっきり聞こえます)。
- 3 つの素材
  - レゴリス・コア … 深いクレーターの底の下に鉱床があります。超音波カッターを鉱床に向けて長押しし、針が共振帯に重なった瞬間に放します(ツルハシでは砕けて何も残りません)。
  - コズミック・ヘリウム 3 セル … 月の海(暗い平原)にヘリウム 3 噴出孔があります。噴き出している間にクライオキャニスターを使います。
  - ヴォイド・クォーツ … 月にいると 5〜10 分おきに近くへ微小隕石が落ち、クレーターの中心に結晶が残ります。

■ 分子共鳴融合炉と超越融合
- 画面はありません。素材を持って右クリックすると、レシピに要る数だけが入ります。素手で右クリックすると完成品を(無ければ最後に入れた物を)取り出します。
- レゴリス・コア ×2 + ヘリウム 3 セル ×4 + ヴォイド・クォーツの欠片 ×2 + チェリー・コア ×1 → アストラル・カタリスト
- アストラル・カタリスト + 武器・道具・防具 1 つ → 超越融合
  攻撃力・採掘速度・防御力・防具強度が 3 倍、ノックバック耐性が 1 部位ごとに +25%、空の下では毎秒 耐久値が 2 回復します。
- アストラル・リフト … 超越融合した胸当てを着て、ジャンプを 2 回押して 2 回目を長押し。重力を離れ、運動量を保ったまま空中を滑るように動けます(W/S は視線の向き、A/D は横)。宇宙エネルギーを毎秒 5 使います。
- ディメンショナル・クリーヴ … 超越融合した剣・斧・メイス・トライデント・槍で、右クリックを 1 秒以上長押ししてから放します。前方 25 ブロックの空間を十字に切り、敵に攻撃力の 300% を防具を無視して与えます(宇宙エネルギー 100、待ち時間 3 秒)。

■ 管理者向けコマンド(OP 権限)
- /cherry meteor … 自分の近くに隕石を落とす(月のみ)
- /cherry moon、/cherry earth … 同じ座標の地表へ移動
- /cherry overdrive … 手に持った装備を超越融合する

■ 飛行機(V1.1.0、V1.1.3 で操縦を作り直し)
- 2 機あります。Cherry Stratos-900(超大型の旅客・貨物機)と Cherry Aegis-X(ステルス戦闘機)。
- アイテムを平らな地面に使うと、見ている向きに機首を向けて止まります。右クリックで乗り込み、スニークで降ります(空中では降りられません)。
- 止まって誰も乗っていないときは、スニークしながら素手で右クリックすると回収できます(体力・燃料・ミサイルを覚えています)。
- 燃料は推進剤キャニスター、ミサイルは誘導ミサイルのアイテムで、地上にいるときに補給します。
- 操縦: 行きたい方を見るだけです。機体はひとりでに傾いて、その方へ回り、上り、下ります。W / S で推力(離した位置に留まり、
  いっぱいで Aegis-X のアフターバーナー。地上で推力 0 のまま S でブレーキ)。左 Alt を押している間は、機体の向きを保ったまま見回せます。
  Aegis-X は左クリックでミサイル(目標はレーダーが自動で選びます)。
- フラップ・脚・ブレーキ・逆推力・アフターバーナー・キャノピーと後部ランプ・着艦フックは自動です。
- 離陸: 推力いっぱいで地平線の少し上を見ると、離陸の速さで浮き上がります。着陸: 地平線の少し下に滑走路を見ると、脚を出し、
  進入の速さを保ち、接地の直前に機首を起こします。接地したら S を押し続けて推力を 0 に。
- 視点は自由です(一人称に固定されず、機体と一緒に傾かず、F5 でいつでも切り替えられます)。計器(速度・高度・方位、機首と飛ぶ道の印、
  ミサイルの照準)はどの視点でも出て、乗ったときと止まっている間は操作の案内も出ます。

■ 空港(V1.1.0)
- PAPI 進入角指示灯 … 滑走路の左に 4 基並べ、進入してくる側へ向けます。適正な 3° では白 3・赤 1。
  赤が多いほど低すぎ、すべて白なら高すぎです。
- 電磁カタパルトの軌道 … 滑走路に沿って並べます。前輪が載った飛行機を約 3 G で 75 m/s まで押し出します
  (スロットル 9 割以上で、ブレーキを放しているときだけ)。
- 着艦ワイヤー … 滑走路を横切って張られ、5 m/s より速く上を通る「下ろした」テイルフックを約 3.5 G で止めます。
- 管制レーダー・ドームと管制ホログラフィック・コンソール … ドームは周り 2,048 ブロックの Cherry の飛行機を追い、
  32 ブロック以内のコンソールが机の上に 1:1024 の空域の地図を映します。

■ 艦艇(V1.1.0、V1.1.2 で仕上げ)
- 2 隻あります。Cherry Leviathan 級(全長 48 m の大型海洋カーフェリー。車両甲板・客室ラウンジ・展望デッキ・艦橋。
  武装は無し)と Cherry Dreadnought 級(全長 64 m の誘導ミサイル駆逐艦。艦橋・CIC・格納庫)。
- 岸やボートから水面を見てアイテムを使うと、見ている所のすぐ先に艦尾を置き、見ている向きに船首を向けて浮かびます(V1.1.3)。
  船体の長さにわたって喫水より深い水が要ります(浅ければ断られます)。
- 甲板や艦内を歩けます。持ち場に立つと就くキーが画面に出るので、持ち場のキー(既定は H)を押すと就きます。もう一度押すと離れます。
- 舵輪(V1.1.3): W で機関の前進、S で停止の側へ(前進から押し続けると停止で止まり、押し直すと後進)。A で取舵、D で面舵
  (押している間だけ。離すと舵は中央に戻り、そのときの方位を保ちます)。スニークでも舵輪を離れます。計器は画面の下、ホットバーと
  体力の上に出ます。
- 海図台: クリックで航路の点を置くと、浅瀬を避けて自動で航行します(陸や浅瀬を横切る区間は断られます)。
- Leviathan 級の扉: 止まっていて(0.3 m/s 未満、機関 0)舵輪に就いている時に扉のキー(既定は Y)を押すと、バウバイザーが
  上がってから船首ランプが下り、船尾ランプも下ります。もう一度押すと閉じます。扉が閉じきるまで機関は推力を出しません。
  下ろしたランプは歩いて上れます。
- Dreadnought 級だけが武装しています。CIC の砲術席では、見ている点へ 406mm 電磁レールガンの 3 連装砲塔 2 基が向き、
  左クリックで一斉射、右クリックでレーダーがロックした目標へ VLS を撃ちます(ハッチが開き切ってから)。
  弾は当たった所で炸裂し、周り 4 m の生き物と艦・飛行機に傷を与えます(V1.1.3。地形は壊しません)。
  砲術席に誰もいなければ、舵輪に就いた人が同じように撃てます(V1.1.3。砲術士が就けば砲はその人へ移ります)。
  CIC のソナー席は、回る走査の画面に周りの艦と水中の相手を映します。Leviathan 級には砲術の持ち場がありません。
- 止まっていて、ほかに誰も乗っていなければ、艦の真ん中(Dreadnought 級は CIC の中)に立ってスニークしながら素手で足もとを
  右クリックすると回収できます。受けた傷は覚えているので、置き直しても直りません。

■ 動いている甲板の上(V1.1.0)
- 航行中の艦や飛行中の機体の上を、走ったり飛び跳ねたりできます。足元がそのまま運びます。

■ ライセンス
Cherry は MIT ライセンスです(LICENSES/Cherry_MIT.txt)。
GeckoLib は MIT ライセンスで、改変せずに同梱しています(LICENSES/GeckoLib_MIT.txt)。

------------------------------------------------------------------

[English]

CHANGED IN V1.1.4
- After the audio device changes (earphones plugged in or out, or a device chosen in the options), the aircraft engines,
  afterburner, missile motors and lock tones start again by themselves within a moment. In 1.1.0 to 1.1.3 they stayed
  silent until you boarded again (a device change makes the game restart its sound engine, which stops every looping sound).
- On the Moon, the pressure suit's breathing does the same (in 1.1.0 to 1.1.3 it stayed silent until you put the helmet
  back on).

CHANGED IN V1.1.3
- The controls are rebuilt so that anyone can fly and sail. The view is no longer locked: the aircraft fly where you look,
  and the ships answer to W, A, S and D like a boat (see AIRCRAFT and SHIPS below). 1.1.2's flight keys (R, U, Y, K, Z, N,
  M, J and the arrow keys) and helm keys (, . = - ; ') are gone.
- Four ship defects are fixed: the rudder turned the opposite way to its keys, astern gave no thrust, a ship could not be
  launched from the shore, and a ship could not be picked back up in survival.
- The railgun now hits. In 1.1.0 to 1.1.2 its shells damaged nothing. Each shell bursts on the first thing in its path
  (a block, a creature, a ship or an aircraft) and damages creatures, ships and aircraft within 4 m. It spares the ship
  that fired it and everyone aboard her, and it never breaks blocks. Look at any part of a ship or an aircraft and both
  turrets train on that point of her hull.
- Manning the gunnery station and firing no longer load distant chunks you cannot see.
- A death message from one of Cherry's weapons no longer shows an untranslated key when the attacker holds a renamed item.
- The Aegis-X's missile count at the bottom left of the flight display is no longer cut off by the bottom of the screen.
  With the automatic GUI scale this happened at many screen sizes, among them 720p, 1440p, 4K and the game's default window.
- Chart waypoints are accepted only within the chart's widest view, about 1.4 km from the ship, which also protects servers
  from malformed waypoint requests.

CHANGED IN V1.1.2
- Both ships get their real models and interiors (hull, decks, bridge, CIC, lounge, vehicle deck; every deck you see is a
  deck you can walk on).
- Every station aboard now works from the game. In 1.1.0 and 1.1.1 the railgun, the VLS and the chart table could not
  actually be used.
- The Dreadnought-Class carries two triple turrets. Salvo flashes, blast rings, tracers and recoiling barrels, the VLS
  hatch and its white smoke, bow waves and wakes, and the screw's bubbles.
- The Leviathan-Class opens her bow visor and bow and stern ramps (only when stopped).
- The helm keys moved off Minecraft's own keys, and the helm instruments now sit above the hotbar and health bar.
  The key names changed, so set again any helm key you rebound in 1.1.0 or 1.1.1.

FIXED IN V1.1.1
- With the video setting "Improved Transparency" turned on, lighting the Cherry Aegis-X's afterburner crashed the game.
  It no longer does, and the shock diamonds still show through the canopy from the cockpit.

REQUIREMENTS
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

INSTALL (client and server)
1. Put both jars from this zip's mods/ folder into your Minecraft mods folder:
   - cherry-1.1.4+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar (GeckoLib, MIT licence, bundled unmodified)
2. Put Fabric API in the mods folder as well.
3. Start the game. No world settings need to change.

GETTING TO THE MOON
1. Place a Launch Pad (it needs a clear 3x3 area). Use the Cherry Apex-1 on the pad and it stands docked.
2. Right-click the rocket holding a Propellant Canister to refuel: 250 per canister, 1000 when full. The Moon costs 600, the way home 300.
3. Right-click to board, then hold Jump for one second to start the T-5 countdown.
4. Between Y300 and Y800 during the ascent is the alignment window. Keep the cross in the centre of the correction circle with W/A/S/D: the better you hold it, the faster you climb, and holding it perfectly halves the time from Y300 to Y1000.
5. At Y1000 you enter the Moon. During the descent W/A/S/D steers the landing.
6. To return, board the landed rocket and hold Jump for one second. If you land near the pad you launched from, you settle back onto it.
7. Sneak to leave the cockpit while docked or landed (you cannot leave in flight).
8. To pick the rocket up, sneak and right-click it with an empty hand (it keeps its fuel and its home pad).

ON THE MOON
- Gravity and fall damage are 1/6 of vanilla.
- There is no air. Unless you wear all four Pressure Suit pieces, stand within 12 blocks of a Pressure Field Projector, or ride the rocket, vacuum takes 15% of your maximum health every second.
- Only low sounds carry (your breathing in the helmet, footsteps felt through the suit and radio noise stay clear).
- Three materials:
  - Lunar Regolith Core: deposits sleep beneath the floors of deep craters. Hold an Ultrasonic Cutter on the deposit and release while the needle sits in the resonance band (a pickaxe only shatters it).
  - Cosmic Helium-3 Cell: Helium-3 geysers stand on the maria (the dark plains). Use a Cryo Canister while one is erupting.
  - Void Quartz: while you are on the Moon a micrometeorite strikes nearby every 5 to 10 minutes and leaves a crystal at the crater's centre.

RESONANCE CRUCIBLE AND OVERDRIVE
- There is no screen. Right-click with materials and the crucible takes exactly as many as the recipe still needs. Right-click with an empty hand to take the result (or, without one, the last thing you put in).
- Lunar Regolith Core x2 + Cosmic Helium-3 Cell x4 + Void Quartz Fragment x2 + Cherry Core x1 -> Astral Catalyst
- Astral Catalyst + one weapon, tool or armour piece -> Overdrive
  Attack damage, mining speed, armour and armour toughness x3, knockback resistance +25% per piece, and 2 durability repaired every second under open sky.
- Astral Lift: wearing an overdriven chestplate, press Jump twice and hold the second press. You leave gravity behind and slide through the air keeping your momentum (W/S along your view, A/D sideways). Uses 5 cosmic energy per second.
- Dimensional Cleave: with an overdriven sword, axe, mace, trident or spear, hold Use for at least one second, then release. The space ahead is cut in a cross for 25 blocks, dealing 300% of your attack damage to enemies through armour (100 cosmic energy, 3-second cooldown).

OPERATOR COMMANDS
- /cherry meteor: strike a meteor near you (Moon only)
- /cherry moon, /cherry earth: move to the surface at the same coordinates
- /cherry overdrive: overdrive the item in your main hand

AIRCRAFT (V1.1.0, controls rebuilt in V1.1.3)
- Two of them: the Cherry Stratos-900 (a very large passenger and freight aircraft) and the Cherry Aegis-X (a stealth fighter).
- Use the item on level ground and it parks facing the way you look. Right-click to board, sneak to leave (not in the air).
- Parked and empty, sneak and right-click with an empty hand to recover it (it keeps its health, fuel and missiles).
- Refuel with Propellant Canisters and rearm with Guided Missiles while it is on the ground.
- Flying: look where you want to go, and she banks, turns, climbs and dives towards it by herself. W / S set the throttle
  (it stays where you leave it; full throttle lights the Aegis-X afterburner; on the ground, S at zero holds her on the
  brakes). Hold Left Alt to look around while she keeps her course. On the Aegis-X, left-click fires a missile at the
  target the radar picks by itself.
- Flaps, gear, brakes, reverse thrust, afterburner, canopy and rear ramp, and the tail hook all work by themselves.
- Take-off: full throttle, and look a little above the horizon; she lifts off at take-off speed. Landing: look at the
  runway a little below the horizon; she lowers her gear, holds her approach speed and flares. Once down, hold S to bring
  the throttle to zero.
- The view is yours (it never locks to first person or tilts with the aircraft, and F5 works at any time). The
  instruments (speed, altitude, heading, the nose and flight-path markers, the missile reticle) show in every view, with a
  short guide to the keys when you board and while she is parked.

AIRPORT (V1.1.0)
- PAPI lights: set four in a row to the left of the runway, facing the approach. On the correct 3 degree path you see
  three white and one red; more red means too low, all white means too high.
- Electromagnetic catapult track: lay it along the runway. It pushes an aircraft whose nose wheel is on it to 75 m/s at
  about 3 G, only above 90% throttle and with the brake released.
- Arresting wire: strung across the runway, it catches a LOWERED tail hook passing over it faster than 5 m/s and stops
  the aircraft at about 3.5 G.
- Control radar dome and holographic console: the dome tracks every Cherry aircraft within 2,048 blocks, and a console
  within 32 blocks projects a 1:1024 map of the airspace above the desk.

SHIPS (V1.1.0, finished in V1.1.2)
- Two of them: the Cherry Leviathan-Class (a 48 m ocean car ferry with a vehicle deck, lounge, observation deck and
  bridge; unarmed) and the Cherry Dreadnought-Class (a 64 m guided missile destroyer with a bridge, CIC and hangar).
- Look at the water from the shore or a boat and use the item: she floats with her stern just past the spot you look at
  and her bow the way you look (V1.1.3). She needs water deeper than her draught along her whole length, and is refused
  where it is shallower.
- Walk her decks and interiors. Standing at a station shows the key that takes it: press the station key (H by default),
  and again to leave.
- The wheel (V1.1.3): W for the engine ahead, S back towards stop (held from ahead it stops at zero; press it again to go
  astern). A for port, D for starboard, only while held: let go and the wheel centres and she holds her heading. Sneak
  leaves the wheel too. The instruments sit at the bottom of the screen, above the hotbar and health bar.
- The chart table: click to lay waypoints and she sails the route, keeping clear of shallows (a leg across land or
  shallow water is refused).
- The Leviathan-Class doors: stopped (slower than 0.3 m/s, engine at 0) and at the wheel, press the doors key (Y by default).
  The bow visor rises, then the bow ramp lowers, and the stern ramp lowers too; press again to close. The engine gives
  no thrust until the doors are shut, and you can walk up the lowered ramps.
- Only the Dreadnought-Class is armed. At the gunnery station in the CIC, both triple 406 mm railgun turrets train on
  the point you look at: left click fires a salvo, right click launches the VLS at the radar-locked target (once its hatch
  is fully open). The shells burst where they strike and damage creatures, ships and aircraft within 4 m (V1.1.3; they
  never break blocks). With nobody at the gunnery station, whoever has the wheel fires the guns the same way (V1.1.3; a
  gunner who takes the station takes the guns over). The sonar station in the CIC shows ships and submerged contacts on a
  sweeping scope. The Leviathan-Class has no gunnery station.
- Stopped and with nobody else aboard, stand amidships (on the Dreadnought-Class, in the CIC), sneak and right-click at
  your feet with an empty hand to recover her. She remembers the damage she took, so putting her back on the water does
  not mend her.

ON A MOVING DECK (V1.1.0)
- Run and jump about on a ship under way or an aircraft in flight. The deck under you carries you with it.

LICENCES
Cherry is MIT licensed (LICENSES/Cherry_MIT.txt).
GeckoLib is MIT licensed and bundled unmodified (LICENSES/GeckoLib_MIT.txt).
