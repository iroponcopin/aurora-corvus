Cherry Framework V1.2.0 "Celestial Crucible & Tactical Superiority"
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ V1.2.0 で変わったこと
- 5 丁の銃: CR-14 ブルパップ突撃銃、CP-9 短機関銃、CS-50 対物レール狙撃銃、CX-12 マグパルス散弾銃、C-Pistol(下の「銃」)。
- 月の生き物 3 種(下の「月の生き物」)。
- ボス「ルナリス・プライム」と星核の牢獄、3 つの至高遺物(下の「ルナリス・プライム」)。
- 火星: 0.38 G、−60 °C の二酸化炭素、砂塵嵐、2 つの鉱石(下の「火星」)。
- Apex-1 のステラ・ナビゲーション(航法コンソール): 発射台の上でジャンプを押すと開き、地球・月・火星から行き先を選ぶ。1.1.x の「ジャンプを 1 秒長押し」の
  発射は無くなりました(下の「はじめ方」)。
- 高度分子加工機: 銃・弾倉・部品・燃料・すべての乗り物を作る(下の「高度分子加工機」)。

■ V1.1.4 で変わったこと
- 音の出力の機器が変わっても(イヤホンの抜き差し、設定で機器を選ぶ)、飛行機のエンジン・アフターバーナー・ミサイルのモーター・ロックの音が
  すぐにひとりでに鳴り直します。1.1.0〜1.1.3 では、乗り直すまで消えたままでした(機器が変わるとゲームが音のエンジンを作り直し、鳴り続ける
  音をすべて止めるため)。
- 月では、宇宙服の呼吸も同じように鳴り直します(1.1.0〜1.1.3 はヘルメットを被り直すまで消えていました)。

■ V1.1.3 で変わったこと
- 操縦を、誰でもかんたんに動かせるよう作り直しました。視点の固定をやめ、飛行機は見た方へ飛び、艦はボートと同じ W・A・S・D で動きます
  (下の「飛行機」「艦艇」)。1.1.2 の飛行機のキー(R・U・Y・K・Z・N・M・J と矢印キー)と舵輪のキー(, . = - ; ')は無くなりました。
- 艦の不具合を 4 つ直しました: 舵がキーと逆に回った、後進が効かなかった、岸から艦を降ろせなかった、サバイバルで艦を回収できなかった。
- 主砲の弾が当たるようになりました。1.1.0〜1.1.2 の主砲は、撃っても何も傷つけていませんでした。弾は進む先で最初に当たった物
  (ブロック・生き物・艦・飛行機)で炸裂し、周り 4 m の生き物と艦・飛行機に傷を与えます。撃った艦と乗っている人は傷つけず、
  地形は壊しません。艦や飛行機のどこを見ても、2 基の砲はその船体・機体の上の点へ向きます。
- 砲術席に就いている間と斉射のたびに、見えない遠くのチャンクまで読み込んでいたのを直しました。
- 名前を付けた物を手に持った人が Cherry の兵器で倒すと、死亡メッセージが翻訳されない文字列のまま出ていたのを直しました。
- Aegis-X の計器の左下にあるミサイルの数が、画面の下端で切れていたのを直しました(GUI の大きさが「自動」のとき、720p・1440p・4K や
  ゲームの既定の窓など、多くの画面の大きさで切れていました)。
- 海図の航路の点は、いちばん広い縮尺で見える範囲(艦から約 1.4 km)の中だけ受け付けます。不正な航路の要求からサーバーを守るため
  でもあります。

■ V1.1.2 で変わったこと
- 2 隻の艦に本番の模型と艦内が入りました(船体・甲板・艦橋・CIC・客室・車両甲板。見えている甲板はどれも歩けます)。
- 艦の持ち場がすべてゲームの中から使えるようになりました。1.1.0 と 1.1.1 では、レールガン・VLS・海図台を実際には使えませんでした。
- Dreadnought 級は 3 連装砲塔 2 基に。斉射の閃光・衝撃波・弾道の光と砲身の後退、VLS のハッチと白煙、船首の波と航跡、スクリューの泡。
- Leviathan 級のバウバイザーと船首・船尾ランプが開きます(止まっている時だけ)。
- 舵輪のキーを Minecraft 自身のキーと重ならない位置へ移し、舵輪の計器をホットバーと体力の上へ上げました。
  キーの名前が変わったので、1.1.0・1.1.1 で変えた舵輪のキーの割り当ては付け直してください。

■ V1.1.1 で直したこと
- ビデオ設定の「透明物の描画の改良」を有効にしていると、Cherry Aegis-X のアフターバーナーを点けた瞬間にゲームが落ちていました。
  直しました。噴流のショックダイヤモンドは、コックピットからキャノピー越しにも見えます。

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - cherry-1.2.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar(GeckoLib。MIT ライセンス。改変せずに同梱)
2. Fabric API も mods フォルダーに入れる。
3. 起動する。ワールドの設定を変える必要はありません。

■ はじめ方(月へ行く)
1. 発射台を置く(周り 3×3 に空きが要ります)。Cherry Apex-1 を発射台の上で使うと、台に固定されて立ちます。
2. 推進剤キャニスター(1 本で 250)か過塩素酸推進剤(750)を持ってロケットを右クリックして給油する。満タンは 1000。航路の燃料は
   地球→月 600、地球→火星 900、月→地球 300、月→火星 600、火星→地球・月 450。
3. 右クリックで乗り込み、ジャンプを押すとステラ・ナビゲーション(航法コンソール)が開きます。A・D(←・→)かクリックで行き先を選び、Space か Enter か
   「発射」で秒読み(T-5)が始まります。Esc か「やめる」で閉じます。燃料が足りない行き先には発射できません。
4. 上昇中の Y300〜Y800 は姿勢補正区間です。W/A/S/D で十字を補正サークルの中心に保つほど速く昇り、ずっと中心なら Y300 から Y1000 までの時間が半分になります。
5. Y1000 で行き先の世界へ入ります。降下中は W/A/S/D で着陸地点を修正できます(火星では薄い大気で機体が赤く焼けます)。
6. 帰るときも、着陸したロケットに乗ってジャンプを押し、コンソールで行き先を選びます。飛び立った発射台の近くに降りれば、その台の上に戻ります。
7. 降りるときは、発射台や地面の上でスニーク(飛行中は降りられません)。
8. ロケットを持ち帰るには、素手でスニークしながら右クリック(燃料と帰る発射台を覚えています)。

■ 月面
- 重力と落下ダメージはバニラの 1/6 です。
- 空気がありません。与圧スーツを 4 部位すべて着るか、気密フィールド投射機の周り(半径 12 ブロック)にいるか、ロケットに乗っていないと、毎秒 最大体力の 15% の減圧ダメージを受けます。
- 音は低い音しか伝わりません(ヘルメットの中の呼吸、足元の振動、無線ノイズははっきり聞こえます)。
- 3 つの素材
  - レゴリス・コア … 深いクレーターの底の下に鉱床があります。超音波カッターを鉱床に向けて長押しし、針が共振帯に重なった瞬間に放します(ツルハシでは砕けて何も残りません)。
  - コズミック・ヘリウム 3 セル … 月の海(暗い平原)にヘリウム 3 噴出孔があります。噴き出している間にクライオキャニスターを使います。
  - ヴォイド・クォーツ … 月にいると 5〜10 分おきに近くへ微小隕石が落ち、クレーターの中心に結晶が残ります。

■ 月の生き物(V1.2.0)
- セレナイト・ストーカー: 月面の下に潜み、16 ブロックの内をしゃがまずに歩く者を感じると飛び出して跳びかかる。噛まれると 10 秒間、
  与圧スーツが真空を防がない。しゃがんで歩けば気づかれない。ヴォイド・クォーツ・フラグメントを落とす。
- ヴォイド・ドリフター: 地面の 12〜20 ブロック上を群れで漂い、プレイヤーを見つけると降りてくる。10 秒ごとに EMP を放ち、16 ブロックの内の
  銃の照準・残弾計・弾数の表示を 10 秒消す。コズミック・ヘリウム3・セルを落とす。
- レゴリス・デバウラー: 地面を打って 8 ブロックの内の者を高く跳ね上げ、溶けた隕石を投げつける。ルナ・レゴリス・コアを落とす。

■ ルナリス・プライム(V1.2.0)
- 月の原点から 8,000 ブロックより遠い巨大クレーターに「星核の牢獄」がある(/locate structure cherry:astraea_shackle で探せる)。封印の
  制御盤にアストラル・カタリストを注ぐと目覚め、空が深紅に染まる。
- 第 1 形態: 6 基の重力シールドビットが撃つ攻撃を防ぐ。アリーナのグラビティ・ウェルで跳び上がり、頭頂の弱点コアを近接で打つとビットが
  剥がれ、すべて剥がれると短い間は何でも効く。
- 第 2 形態(体力の半分以下): 外殻が爆砕し、速さは 3 倍。十字の斬撃波と、空からのオービタル・レイ。毎分、アリーナの重力が超重力か
  ゼロ G に変わる。
- 至高遺物(作れない): ルナリスの星核破片(持っているだけで超越融合の回復と宇宙エネルギーが 2 倍、ディメンショナル・クリーヴが 1.5 倍)、
  重力崩壊砲(撃った所にブラックホール)、セレーネの天球冠(被るとどの世界でも息が尽きず、真空と落下の傷を受けず、超越融合の胸当て無しで
  アストラル・リフトを使える。壊れない)。

■ 火星(V1.2.0)
- 重力と落下ダメージはバニラの 0.38 倍。
- 空気が無く(二酸化炭素)、−60 °C。与圧スーツ 4 部位で空気は防げるが、寒さは防げない。耐寒の内張り(作業台で白い羊毛・ブレイズパウダー・
  鉄から 2 つ)を型に、鍛冶台で与圧スーツの部位 1 つと合わせると内張り入りになる(エンチャントと耐久は残る)。4 部位すべて内張り入りか、
  ロケットに乗るか、気密フィールドの中にいないと、毎秒ハート 1 つの凍えの傷を受け、画面の縁が凍る。
- 砂塵嵐: 約 20 分おきに 3 分ほど。霧が数ブロックまで寄って錆色になり、Cherry の計器(銃・ロケット・飛行機)に雑音が走る。
- 火星赤色フェライト鉱石(地表の近く、鉄のツルハシ以上)→ 原石 → かまどか溶鉱炉でインゴット(チタン・カーボン板の材料)。
- 過塩素酸塩の鉱石(地下深く、鉄のツルハシ以上)→ 過塩素酸エナジーソルト。ソルト 4 つを推進剤キャニスターの周りに置くと過塩素酸推進剤
  (キャニスター 3 本ぶん)。

■ 銃(V1.2.0)
- CR-14(突撃銃、弾倉 30、連射)、CP-9(短機関銃、弾倉 40、秒間 20 発、跳ね上がりが小さい)、CS-50(対物レール狙撃銃、弾倉 5、ボルト、
  岩と敵を貫く)、CX-12(マグパルス散弾銃、弾倉 8、ポンプ、9 粒の扇。低重力の宙で撃つと反動で自分が吹き飛ぶ)、C-Pistol(拳銃、弾倉 12、
  消音器、レーザーサイト)。
- 左クリックで撃つ。右クリックで狙う(ドア・チェスト・機械に向けたときはブロックが先)。R で装填、F で確認(銃を持つ間、F は手を持ち替えない)。
- 狙うと、狙った先より手前と奥の世界がなだらかにぼける。CS-50 のスコープは中だけが 6 倍に拡大され、サーマルの色で写る(生き物は熱く光るが、
  壁の向こうは見えない)。
- C-Pistol を持っている間、狙う先に赤い点、拳銃からそこへ赤い光線(ほかのプレイヤーの拳銃にも見える)。
- サバイバルの装填は、その銃の弾倉を 1 つ使う(クリエイティブは要らない)。弾倉と銃は高度分子加工機で作る。
- 弾の数は弾倉と薬室の 1 発で数える(満たした CR-14 は 31)。

■ 高度分子加工機(V1.2.0)
- 作業台で作る(ヴォイド・クォーツ・フラグメント 2・チェリー・コア 1・鉄ブロック 5・鍛冶台 1)。置いて右クリックすると画面が開く。
- 一覧でレシピを選び、6 つの材料の枠に材料を入れると、時間をかけて作る(動力は要らない)。ホッパーで上と横から材料を入れ、下から完成品を出せる。
- 作れる物: 5 丁の銃と弾倉、チタン・カーボン板(銃と乗り物の装甲板)、精密銃身部品、推進剤キャニスター、過塩素酸推進剤、耐寒の内張り、
  誘導ミサイル、発射台、Apex-1 の補助ブースター、レールガン砲身、Apex-1(補助ブースター 2 本から)、Stratos-900、Aegis-X、Leviathan級、
  Dreadnought級(レールガン砲身 2 本から)。ブースターと砲身は月の素材(コズミック・ヘリウム3・セルとルナ・レゴリス・コア)から作る。
- レゴリス粉末(弾倉の材料)は、作業台で月のレゴリス 1 つから 2 つ。

■ 分子共鳴融合炉と超越融合
- 画面はありません。素材を持って右クリックすると、レシピに要る数だけが入ります。素手で右クリックすると完成品を(無ければ最後に入れた物を)取り出します。
- レゴリス・コア ×2 + ヘリウム 3 セル ×4 + ヴォイド・クォーツの欠片 ×2 + チェリー・コア ×1 → アストラル・カタリスト
- アストラル・カタリスト + 武器・道具・防具 1 つ → 超越融合
  攻撃力・採掘速度・防御力・防具強度が 3 倍、ノックバック耐性が 1 部位ごとに +25%、空の下では毎秒 耐久値が 2 回復します。
- アストラル・リフト … 超越融合した胸当てを着て、ジャンプを 2 回押して 2 回目を長押し。重力を離れ、運動量を保ったまま空中を滑るように動けます(W/S は視線の向き、A/D は横)。宇宙エネルギーを毎秒 5 使います。
- ディメンショナル・クリーヴ … 超越融合した剣・斧・メイス・トライデント・槍で、右クリックを 1 秒以上長押ししてから放します。前方 25 ブロックの空間を十字に切り、敵に攻撃力の 300% を防具を無視して与えます(宇宙エネルギー 100、待ち時間 3 秒)。

■ 管理者向けコマンド(OP 権限)
- /cherry meteor … 自分の近くに隕石を落とす(月のみ)
- /cherry moon、/cherry earth、/cherry mars … 同じ座標の地表へ移動
- /cherry storm start、/cherry storm clear … 火星の砂塵嵐を始める・止める
- /cherry overdrive … 手に持った装備を超越融合する

■ 飛行機(V1.1.0、V1.1.3 で操縦を作り直し)
- 2 機あります。Cherry Stratos-900(超大型の旅客・貨物機)と Cherry Aegis-X(ステルス戦闘機)。
- アイテムを平らな地面に使うと、見ている向きに機首を向けて止まります。右クリックで乗り込み、スニークで降ります(空中では降りられません)。
- 止まって誰も乗っていないときは、スニークしながら素手で右クリックすると回収できます(体力・燃料・ミサイルを覚えています)。
- 燃料は推進剤キャニスター、ミサイルは誘導ミサイルのアイテムで、地上にいるときに補給します。
- 操縦: 行きたい方を見るだけです。機体はひとりでに傾いて、その方へ回り、上り、下ります。W / S で推力(離した位置に留まり、
  いっぱいで Aegis-X のアフターバーナー。地上で推力 0 のまま S でブレーキ)。左 Alt を押している間は、機体の向きを保ったまま見回せます。
  Aegis-X は左クリックでミサイル(目標はレーダーが自動で選びます)。
- フラップ・脚・ブレーキ・逆推力・アフターバーナー・キャノピーと後部ランプ・着艦フックは自動です。
- 離陸: 推力いっぱいで地平線の少し上を見ると、離陸の速さで浮き上がります。着陸: 地平線の少し下に滑走路を見ると、脚を出し、
  進入の速さを保ち、接地の直前に機首を起こします。接地したら S を押し続けて推力を 0 に。
- 視点は自由です(一人称に固定されず、機体と一緒に傾かず、F5 でいつでも切り替えられます)。計器(速度・高度・方位、機首と飛ぶ道の印、
  ミサイルの照準)はどの視点でも出て、乗ったときと止まっている間は操作の案内も出ます。

■ 空港(V1.1.0)
- PAPI 進入角指示灯 … 滑走路の左に 4 基並べ、進入してくる側へ向けます。適正な 3° では白 3・赤 1。
  赤が多いほど低すぎ、すべて白なら高すぎです。
- 電磁カタパルトの軌道 … 滑走路に沿って並べます。前輪が載った飛行機を約 3 G で 75 m/s まで押し出します
  (スロットル 9 割以上で、ブレーキを放しているときだけ)。
- 着艦ワイヤー … 滑走路を横切って張られ、5 m/s より速く上を通る「下ろした」テイルフックを約 3.5 G で止めます。
- 管制レーダー・ドームと管制ホログラフィック・コンソール … ドームは周り 2,048 ブロックの Cherry の飛行機を追い、
  32 ブロック以内のコンソールが机の上に 1:1024 の空域の地図を映します。

■ 艦艇(V1.1.0、V1.1.2 で仕上げ)
- 2 隻あります。Cherry Leviathan 級(全長 48 m の大型海洋カーフェリー。車両甲板・客室ラウンジ・展望デッキ・艦橋。
  武装は無し)と Cherry Dreadnought 級(全長 64 m の誘導ミサイル駆逐艦。艦橋・CIC・格納庫)。
- 岸やボートから水面を見てアイテムを使うと、見ている所のすぐ先に艦尾を置き、見ている向きに船首を向けて浮かびます(V1.1.3)。
  船体の長さにわたって喫水より深い水が要ります(浅ければ断られます)。
- 甲板や艦内を歩けます。持ち場に立つと就くキーが画面に出るので、持ち場のキー(既定は H)を押すと就きます。もう一度押すと離れます。
- 舵輪(V1.1.3): W で機関の前進、S で停止の側へ(前進から押し続けると停止で止まり、押し直すと後進)。A で取舵、D で面舵
  (押している間だけ。離すと舵は中央に戻り、そのときの方位を保ちます)。スニークでも舵輪を離れます。計器は画面の下、ホットバーと
  体力の上に出ます。
- 海図台: クリックで航路の点を置くと、浅瀬を避けて自動で航行します(陸や浅瀬を横切る区間は断られます)。
- Leviathan 級の扉: 止まっていて(0.3 m/s 未満、機関 0)舵輪に就いている時に扉のキー(既定は Y)を押すと、バウバイザーが
  上がってから船首ランプが下り、船尾ランプも下ります。もう一度押すと閉じます。扉が閉じきるまで機関は推力を出しません。
  下ろしたランプは歩いて上れます。
- Dreadnought 級だけが武装しています。CIC の砲術席では、見ている点へ 406mm 電磁レールガンの 3 連装砲塔 2 基が向き、
  左クリックで一斉射、右クリックでレーダーがロックした目標へ VLS を撃ちます(ハッチが開き切ってから)。
  弾は当たった所で炸裂し、周り 4 m の生き物と艦・飛行機に傷を与えます(V1.1.3。地形は壊しません)。
  砲術席に誰もいなければ、舵輪に就いた人が同じように撃てます(V1.1.3。砲術士が就けば砲はその人へ移ります)。
  CIC のソナー席は、回る走査の画面に周りの艦と水中の相手を映します。Leviathan 級には砲術の持ち場がありません。
- 止まっていて、ほかに誰も乗っていなければ、艦の真ん中(Dreadnought 級は CIC の中)に立ってスニークしながら素手で足もとを
  右クリックすると回収できます。受けた傷は覚えているので、置き直しても直りません。

■ 動いている甲板の上(V1.1.0)
- 航行中の艦や飛行中の機体の上を、走ったり飛び跳ねたりできます。足元がそのまま運びます。

■ ライセンス
Cherry は MIT ライセンスです(LICENSES/Cherry_MIT.txt)。
GeckoLib は MIT ライセンスで、改変せずに同梱しています(LICENSES/GeckoLib_MIT.txt)。

------------------------------------------------------------------

[English]

CHANGED IN V1.2.0
- Five guns: the CR-14 bullpup rifle, the CP-9 sub-machine gun, the CS-50 rail sniper, the CX-12 magpulse shotgun and the
  C-Pistol (see GUNS below).
- Three kinds of life on the Moon (see LIFE ON THE MOON below).
- The boss Lunaris Prime in the Astraea Shackle, with three relics (see LUNARIS PRIME below).
- Mars: 0.38 g, -60 C carbon dioxide, dust storms and two ores (see MARS below).
- The Apex-1's Stellar Navigation console: press Jump on the pad and it opens; choose Earth, the Moon or Mars. 1.1.x's
  "hold Jump for one second" launch is gone (see GETTING TO THE MOON below).
- The Advanced Cherry Fabricator makes the guns, magazines, parts, fuel and every vehicle (see THE FABRICATOR below).

CHANGED IN V1.1.4
- After the audio device changes (earphones plugged in or out, or a device chosen in the options), the aircraft engines,
  afterburner, missile motors and lock tones start again by themselves within a moment. In 1.1.0 to 1.1.3 they stayed
  silent until you boarded again (a device change makes the game restart its sound engine, which stops every looping sound).
- On the Moon, the pressure suit's breathing does the same (in 1.1.0 to 1.1.3 it stayed silent until you put the helmet
  back on).

CHANGED IN V1.1.3
- The controls are rebuilt so that anyone can fly and sail. The view is no longer locked: the aircraft fly where you look,
  and the ships answer to W, A, S and D like a boat (see AIRCRAFT and SHIPS below). 1.1.2's flight keys (R, U, Y, K, Z, N,
  M, J and the arrow keys) and helm keys (, . = - ; ') are gone.
- Four ship defects are fixed: the rudder turned the opposite way to its keys, astern gave no thrust, a ship could not be
  launched from the shore, and a ship could not be picked back up in survival.
- The railgun now hits. In 1.1.0 to 1.1.2 its shells damaged nothing. Each shell bursts on the first thing in its path
  (a block, a creature, a ship or an aircraft) and damages creatures, ships and aircraft within 4 m. It spares the ship
  that fired it and everyone aboard her, and it never breaks blocks. Look at any part of a ship or an aircraft and both
  turrets train on that point of her hull.
- Manning the gunnery station and firing no longer load distant chunks you cannot see.
- A death message from one of Cherry's weapons no longer shows an untranslated key when the attacker holds a renamed item.
- The Aegis-X's missile count at the bottom left of the flight display is no longer cut off by the bottom of the screen.
  With the automatic GUI scale this happened at many screen sizes, among them 720p, 1440p, 4K and the game's default window.
- Chart waypoints are accepted only within the chart's widest view, about 1.4 km from the ship, which also protects servers
  from malformed waypoint requests.

CHANGED IN V1.1.2
- Both ships get their real models and interiors (hull, decks, bridge, CIC, lounge, vehicle deck; every deck you see is a
  deck you can walk on).
- Every station aboard now works from the game. In 1.1.0 and 1.1.1 the railgun, the VLS and the chart table could not
  actually be used.
- The Dreadnought-Class carries two triple turrets. Salvo flashes, blast rings, tracers and recoiling barrels, the VLS
  hatch and its white smoke, bow waves and wakes, and the screw's bubbles.
- The Leviathan-Class opens her bow visor and bow and stern ramps (only when stopped).
- The helm keys moved off Minecraft's own keys, and the helm instruments now sit above the hotbar and health bar.
  The key names changed, so set again any helm key you rebound in 1.1.0 or 1.1.1.

FIXED IN V1.1.1
- With the video setting "Improved Transparency" turned on, lighting the Cherry Aegis-X's afterburner crashed the game.
  It no longer does, and the shock diamonds still show through the canopy from the cockpit.

REQUIREMENTS
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

INSTALL (client and server)
1. Put both jars from this zip's mods/ folder into your Minecraft mods folder:
   - cherry-1.2.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar (GeckoLib, MIT licence, bundled unmodified)
2. Put Fabric API in the mods folder as well.
3. Start the game. No world settings need to change.

GETTING TO THE MOON
1. Place a Launch Pad (it needs a clear 3x3 area). Use the Cherry Apex-1 on the pad and it stands docked.
2. Right-click the rocket holding a Propellant Canister (250) or Perchlorate Propellant (750) to refuel; 1000 when full. Each
   route costs: Earth to the Moon 600, Earth to Mars 900, the Moon to Earth 300, the Moon to Mars 600, Mars to Earth or the Moon 450.
3. Right-click to board, then press Jump: the Stellar Navigation console opens. Choose a destination with A/D (the arrow
   keys) or a click, and Space, Enter or Launch starts the T-5 countdown; Esc or Cancel closes it. A destination you do not
   have the fuel for cannot be launched to.
4. Between Y300 and Y800 during the ascent is the alignment window. Keep the cross in the centre of the correction circle with W/A/S/D: the better you hold it, the faster you climb, and holding it perfectly halves the time from Y300 to Y1000.
5. At Y1000 you enter your destination's world. During the descent W/A/S/D steers the landing (on Mars the thin air burns red
   round the hull).
6. To return, board the landed rocket, press Jump and choose on the console. If you land near the pad you launched from,
   you settle back onto it.
7. Sneak to leave the cockpit while docked or landed (you cannot leave in flight).
8. To pick the rocket up, sneak and right-click it with an empty hand (it keeps its fuel and its home pad).

ON THE MOON
- Gravity and fall damage are 1/6 of vanilla.
- There is no air. Unless you wear all four Pressure Suit pieces, stand within 12 blocks of a Pressure Field Projector, or ride the rocket, vacuum takes 15% of your maximum health every second.
- Only low sounds carry (your breathing in the helmet, footsteps felt through the suit and radio noise stay clear).
- Three materials:
  - Lunar Regolith Core: deposits sleep beneath the floors of deep craters. Hold an Ultrasonic Cutter on the deposit and release while the needle sits in the resonance band (a pickaxe only shatters it).
  - Cosmic Helium-3 Cell: Helium-3 geysers stand on the maria (the dark plains). Use a Cryo Canister while one is erupting.
  - Void Quartz: while you are on the Moon a micrometeorite strikes nearby every 5 to 10 minutes and leaves a crystal at the crater's centre.

LIFE ON THE MOON (V1.2.0)
- Selenite Stalker: hides under the regolith and, feeling anyone who walks without sneaking within 16 blocks, bursts out and
  leaps at them. Its bite leaves a pressure suit unable to keep out the vacuum for 10 seconds. Sneak and it never notices
  you. Drops Void Quartz Fragments.
- Void Drifter: drifts in flocks 12 to 20 blocks above the ground and comes down on a player it sees. Every 10 seconds it
  releases an EMP that blanks the sights, counters and ammo readouts of guns within 16 blocks for 10 seconds. Drops Cosmic
  Helium-3 Cells.
- Regolith Devourer: slams the ground, flinging everyone within 8 blocks high into the sky, and hurls molten meteors. Drops
  Lunar Regolith Cores.

LUNARIS PRIME (V1.2.0)
- Beyond 8,000 blocks from the Moon's origin a giant crater holds the Astraea Shackle (/locate structure
  cherry:astraea_shackle finds it). An Astral Catalyst in its seal console wakes the boss, and the sky turns crimson.
- Phase one: six gravity shield bits turn aside anything fired at it. Leap from the arena's gravity wells and strike the weak
  core on its crown in melee to break the bits away; with none left, for a short while everything hurts it.
- Phase two (half health and below): its armour bursts off and it moves three times as fast, with cross-shaped slash waves
  and orbital rays from the sky. Every minute the arena's gravity turns heavy or to zero g.
- Its relics (never crafted): the Coreshard of Lunaris (carried anywhere, it doubles Overdrive's repair and cosmic energy and
  makes the Dimensional Cleave 1.5 times as strong), the Graviton Siphon (its shot opens a black hole) and the Crown of Selene
  (worn, you never run out of air in any world, take no vacuum or fall damage, and use the Astral Lift without an overdriven
  chestplate; it never breaks).

MARS (V1.2.0)
- Gravity and fall damage are 0.38 times vanilla's.
- No air (carbon dioxide) and -60 C. The four Pressure Suit pieces keep out the air, not the cold. A Thermal Lining (two from
  white wool, blaze powder and iron at the crafting table) is a smithing template: at the smithing table it lines one suit
  piece (its enchantments and damage stay). Unless all four pieces are lined, you ride the rocket or you stand in a Pressure
  Field, the cold deals one heart a second and frost creeps over the edges of the screen.
- Dust storms: about every 20 minutes, for about 3 minutes. The fog closes in to a few blocks and turns rust-red, and static
  crosses Cherry's instruments (guns, rocket and aircraft).
- Martian Ferrite Ore (near the surface, an iron pickaxe or better) gives Raw Martian Ferrite, smelted or blasted into
  ingots (the base of the Titanium-Carbon Plate).
- Perchlorate Salt Ore (deep underground, an iron pickaxe or better) gives Perchlorate Energy Salt. Four salts round a
  Propellant Canister make Perchlorate Propellant, worth three canisters.

GUNS (V1.2.0)
- CR-14 (rifle, 30-round magazine, full auto), CP-9 (sub-machine gun, 40 rounds, 20 a second, barely climbs), CS-50 (rail
  sniper, 5 rounds, bolt action, pierces rock and several foes), CX-12 (magpulse shotgun, 8 rounds, pump, a fan of 9;
  fired in mid-air under low gravity, the recoil blows you back) and C-Pistol (12 rounds, suppressed, laser sight).
- Left click fires. Right click aims (at a door, chest or machine the block comes first). R reloads; F inspects (while you
  hold a gun, F does not swap hands).
- Aiming softly blurs the world nearer and farther than what you aim at. The CS-50's scope magnifies 6 times inside the lens
  only, in thermal colours: living creatures glow hot, never through a wall.
- While you hold the C-Pistol, a red dot marks where it points, with a red beam from the pistol to it (other players see
  theirs too).
- In survival a reload uses one of that gun's magazines (creative needs none). The Fabricator makes guns and magazines.
- Rounds count the magazine plus the one in the chamber (a full CR-14 shows 31).

THE FABRICATOR (V1.2.0)
- The Advanced Cherry Fabricator is made at the crafting table (two Void Quartz Fragments, a Cherry Core, five iron blocks
  and a smithing table). Place it and right-click to open it.
- Pick a recipe from the list and fill its six ingredient slots; it makes the item in its time (no power). Hoppers can feed
  it from the top and sides and empty it from below.
- It makes: the five guns and their magazines, the Titanium-Carbon Plate (armour plating for guns and vehicles), the
  Precision Barrel Component, Propellant Canisters, Perchlorate Propellant, the Thermal Lining, Guided Missiles, the Launch
  Pad, the Apex-1 Booster, the Railgun Barrel, the Apex-1 (from two boosters), the Stratos-900, the Aegis-X, the Leviathan
  and the Dreadnought (from two railgun barrels). The boosters and barrels are made from Moon materials (Cosmic Helium-3
  Cells and Lunar Regolith Cores).
- Regolith Powder (for magazines): two from a lunar regolith block at the crafting table.

RESONANCE CRUCIBLE AND OVERDRIVE
- There is no screen. Right-click with materials and the crucible takes exactly as many as the recipe still needs. Right-click with an empty hand to take the result (or, without one, the last thing you put in).
- Lunar Regolith Core x2 + Cosmic Helium-3 Cell x4 + Void Quartz Fragment x2 + Cherry Core x1 -> Astral Catalyst
- Astral Catalyst + one weapon, tool or armour piece -> Overdrive
  Attack damage, mining speed, armour and armour toughness x3, knockback resistance +25% per piece, and 2 durability repaired every second under open sky.
- Astral Lift: wearing an overdriven chestplate, press Jump twice and hold the second press. You leave gravity behind and slide through the air keeping your momentum (W/S along your view, A/D sideways). Uses 5 cosmic energy per second.
- Dimensional Cleave: with an overdriven sword, axe, mace, trident or spear, hold Use for at least one second, then release. The space ahead is cut in a cross for 25 blocks, dealing 300% of your attack damage to enemies through armour (100 cosmic energy, 3-second cooldown).

OPERATOR COMMANDS
- /cherry meteor: strike a meteor near you (Moon only)
- /cherry moon, /cherry earth, /cherry mars: move to the surface at the same coordinates
- /cherry storm start, /cherry storm clear: start or clear a dust storm on Mars
- /cherry overdrive: overdrive the item in your main hand

AIRCRAFT (V1.1.0, controls rebuilt in V1.1.3)
- Two of them: the Cherry Stratos-900 (a very large passenger and freight aircraft) and the Cherry Aegis-X (a stealth fighter).
- Use the item on level ground and it parks facing the way you look. Right-click to board, sneak to leave (not in the air).
- Parked and empty, sneak and right-click with an empty hand to recover it (it keeps its health, fuel and missiles).
- Refuel with Propellant Canisters and rearm with Guided Missiles while it is on the ground.
- Flying: look where you want to go, and she banks, turns, climbs and dives towards it by herself. W / S set the throttle
  (it stays where you leave it; full throttle lights the Aegis-X afterburner; on the ground, S at zero holds her on the
  brakes). Hold Left Alt to look around while she keeps her course. On the Aegis-X, left-click fires a missile at the
  target the radar picks by itself.
- Flaps, gear, brakes, reverse thrust, afterburner, canopy and rear ramp, and the tail hook all work by themselves.
- Take-off: full throttle, and look a little above the horizon; she lifts off at take-off speed. Landing: look at the
  runway a little below the horizon; she lowers her gear, holds her approach speed and flares. Once down, hold S to bring
  the throttle to zero.
- The view is yours (it never locks to first person or tilts with the aircraft, and F5 works at any time). The
  instruments (speed, altitude, heading, the nose and flight-path markers, the missile reticle) show in every view, with a
  short guide to the keys when you board and while she is parked.

AIRPORT (V1.1.0)
- PAPI lights: set four in a row to the left of the runway, facing the approach. On the correct 3 degree path you see
  three white and one red; more red means too low, all white means too high.
- Electromagnetic catapult track: lay it along the runway. It pushes an aircraft whose nose wheel is on it to 75 m/s at
  about 3 G, only above 90% throttle and with the brake released.
- Arresting wire: strung across the runway, it catches a LOWERED tail hook passing over it faster than 5 m/s and stops
  the aircraft at about 3.5 G.
- Control radar dome and holographic console: the dome tracks every Cherry aircraft within 2,048 blocks, and a console
  within 32 blocks projects a 1:1024 map of the airspace above the desk.

SHIPS (V1.1.0, finished in V1.1.2)
- Two of them: the Cherry Leviathan-Class (a 48 m ocean car ferry with a vehicle deck, lounge, observation deck and
  bridge; unarmed) and the Cherry Dreadnought-Class (a 64 m guided missile destroyer with a bridge, CIC and hangar).
- Look at the water from the shore or a boat and use the item: she floats with her stern just past the spot you look at
  and her bow the way you look (V1.1.3). She needs water deeper than her draught along her whole length, and is refused
  where it is shallower.
- Walk her decks and interiors. Standing at a station shows the key that takes it: press the station key (H by default),
  and again to leave.
- The wheel (V1.1.3): W for the engine ahead, S back towards stop (held from ahead it stops at zero; press it again to go
  astern). A for port, D for starboard, only while held: let go and the wheel centres and she holds her heading. Sneak
  leaves the wheel too. The instruments sit at the bottom of the screen, above the hotbar and health bar.
- The chart table: click to lay waypoints and she sails the route, keeping clear of shallows (a leg across land or
  shallow water is refused).
- The Leviathan-Class doors: stopped (slower than 0.3 m/s, engine at 0) and at the wheel, press the doors key (Y by default).
  The bow visor rises, then the bow ramp lowers, and the stern ramp lowers too; press again to close. The engine gives
  no thrust until the doors are shut, and you can walk up the lowered ramps.
- Only the Dreadnought-Class is armed. At the gunnery station in the CIC, both triple 406 mm railgun turrets train on
  the point you look at: left click fires a salvo, right click launches the VLS at the radar-locked target (once its hatch
  is fully open). The shells burst where they strike and damage creatures, ships and aircraft within 4 m (V1.1.3; they
  never break blocks). With nobody at the gunnery station, whoever has the wheel fires the guns the same way (V1.1.3; a
  gunner who takes the station takes the guns over). The sonar station in the CIC shows ships and submerged contacts on a
  sweeping scope. The Leviathan-Class has no gunnery station.
- Stopped and with nobody else aboard, stand amidships (on the Dreadnought-Class, in the CIC), sneak and right-click at
  your feet with an empty hand to recover her. She remembers the damage she took, so putting her back on the water does
  not mend her.

ON A MOVING DECK (V1.1.0)
- Run and jump about on a ship under way or an aircraft in flight. The deck under you carries you with it.

LICENCES
Cherry is MIT licensed (LICENSES/Cherry_MIT.txt).
GeckoLib is MIT licensed and bundled unmodified (LICENSES/GeckoLib_MIT.txt).
