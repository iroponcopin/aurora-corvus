# Changelog / 変更履歴

Versions are chosen by content and never reused. 版番号は内容で決め、使い回しません。

## 1.0.0 (first release / 最初の版)

**Status / 状態:** released on the owner's decision **without a live-server test**; verified offline only. If something in [UNVERIFIED.md](UNVERIFIED.md) fails on your server, please report the log lines (see [docs/LIVE_TEST_PLAN.md](docs/LIVE_TEST_PLAN.md)). 所有者の判断で、**実機の確認をしないまま**出した版です。オフラインでの検証だけです。UNVERIFIED.md の項目があなたのサーバーで動かなかったときは、ログの行を知らせてください。

Target / 対象: Palworld 1.0 dedicated server (Windows build; a Linux host runs it under Wine/Proton) with the Palworld build of UE4SS (Lua 5.4). Players install nothing. プレイヤーは何も入れません。

### Players / プレイヤー
- `/help /home /tpa /tpaccept /tpdeny /tpcancel /stats /lang /kit starter /unstuck` (`!` works as well as `/`). Replies in Japanese (primary) and English.
- Teleports go only to ground proven by a line trace with head clearance; warm-up, cool-down, damage and movement cancel, arrival is confirmed.

### Admins / 管理者
- `/noctua health|base|raid|backup|reload|version`; one settings file, `config/noctua_settings.json`, written with defaults on first start and never overwritten. Every feature that changes a game rule is **off by default**.
- Base worker-Pal cap and structure decay, egg hatch time, incubator temperature, passive-inheritance weights, Lucky/Predator odds, raid tuning, autosave interval (all through the game's own settings, read back to verify).
- Verified scheduled backups: a separate process copies, the copy is size-checked before and after and renamed only when whole, and only then are old Noctua backups pruned.
- Opt-in automatic stuck check (`off` / `log` / `rescue`); start with `log`.

### Safety / 安全
- Every chat line is treated as hostile input (linear-time trim, per-player queue, rate limits, look-alike names shown with `#tag`). A Lua error cannot take the server or another feature down; a boot health check switches off only the features whose game symbols are missing.

### Not built, with reasons / 作っていないもの
Spawning apex Pals, custom raid compositions, stuck-Pal rescue, differential backups, slope/rock placement, 50 workers (the game's level table stops at 30). See [docs/SERVER_SETUP_GUIDE.md](docs/SERVER_SETUP_GUIDE.md).

### Known limits / 既知の限界
- A Lua hook cannot hide a `/` line from the game: other players do not see it, but the sender also gets the game's "Unknown command.". `!` lines are ordinary chat and visible to everyone.
- The first live test decides Phase 3b (the level table) and everything in UNVERIFIED.md.

### Verification behind this build / この版の検証
299 offline tests (run twice), 93 planted defects each caught at its own test (run twice), the package verified entry by entry and against six kinds of damage, and the unpacked zip booted against the mock with 19/19 features.
