Noctua creates noctua_settings.json here the first time it starts, with every setting at its default.
Edit that file (never this folder's example file), then restart the server or run /noctua reload as an admin.
noctua_settings.example.json is the list of defaults for reference. An update never touches noctua_settings.json.

Noctua は初回の起動時に、このフォルダーへ noctua_settings.json を作ります（すべて既定値です）。
書き換えるのはそのファイルです（見本の noctua_settings.example.json ではありません）。書き換えたら、サーバーを再起動するか、管理者が /noctua reload を実行してください。
noctua_settings.example.json は既定値の一覧です。更新しても、noctua_settings.json は書き換わりません。
