Noctua keeps what players choose in game here (for now: each player's /lang choice, in players.json).
The folder ships with the mod because a UE4SS Lua mod cannot create folders.
Keep this folder when you update Noctua.

Noctua はゲーム内でプレイヤーが選んだ設定をここに保存します（現在は /lang の言語選択のみ、players.json）。
UE4SS の Lua MOD はフォルダーを作れないため、このフォルダーを同梱しています。
Noctua を更新するときも、このフォルダーは残してください。
