-- Noctua: chat commands (NOCTUA_INIT.md module C, NoctuaCommandCore).
--
-- The game has no custom UI for a server mod, so chat is the UI: a player types
-- /home, /tpa <name>, /stats ... and Noctua answers that player only.
--
-- Engine-free: everything the game does goes through `services.api`
-- (scripts/noctua/pal_api.lua on a server, a fake world in tests/).
--
-- Only Noctua's own command names are consumed. Any other line, including the
-- game's own admin commands (/AdminPassword, /Broadcast ...), is left alone and is
-- never written to a log.

local i18n = require("noctua.i18n")
local tpa_book = require("noctua.tpa")
local ratelimit = require("noctua.ratelimit")
local landing = require("noctua.landing")
local teleport = require("noctua.teleport")
local stuck_mod = require("noctua.stuck")

local handler = {}

---------------------------------------------------------------------------
-- Parsing
---------------------------------------------------------------------------

-- Linear in the length of the string. (A "^%s+" / "%s+$" gsub pair is quadratic on a line of
-- thousands of spaces, and a chat line is attacker-controlled.)
local function trim(s)
  local first = s:find("%S")
  if not first then return "" end
  local last = #s
  while last > first do
    local b = s:byte(last)
    if b == 32 or (b >= 9 and b <= 13) then last = last - 1 else break end
  end
  return s:sub(first, last)
end

--- The command name at the start of a chat line, looking only at its first 200 bytes, so a
-- huge line costs nothing. Returns the lower-case name, or nil for ordinary chat.
function handler.command_name(line, prefixes)
  if type(line) ~= "string" then return nil end
  local head = line:sub(1, 200)
  local first = head:find("%S")
  if not first then return nil end
  local prefix = head:sub(first, first)
  local is_prefix = false
  for _, p in ipairs(prefixes) do
    if p == prefix then is_prefix = true break end
  end
  if not is_prefix then return nil end
  local name, after = head:match("^%s*.([%a][%w_]*)(.*)$", 1)
  if not name then return nil end
  if after == "" then
    -- the name ends the head: only a real end of line makes it a command
    if #line > #head then return nil end
  elseif not after:match("^%s") then
    return nil
  end
  return name:lower()
end

--- Splits a chat line into a command. Returns nil for ordinary chat.
-- { name = "tpa", rest = "Iroha Hokazono", args = {"Iroha", "Hokazono"}, bytes = n }
function handler.parse(line, prefixes)
  if type(line) ~= "string" then return nil end
  local text = trim(line)
  if #text < 2 then return nil end
  local first = text:sub(1, 1)
  local is_prefix = false
  for _, p in ipairs(prefixes) do
    if p == first then is_prefix = true break end
  end
  if not is_prefix then return nil end
  local name, after = text:match("^.([%a][%w_]*)(.*)$")
  if not name then return nil end
  -- "/home!" or "/tpa:x" are not commands; a name must end at a space or the line end.
  if after ~= "" and not after:match("^%s") then return nil end
  local rest = trim(after)
  local args = {}
  for word in rest:gmatch("%S+") do args[#args + 1] = word end
  return { name = name:lower(), rest = rest, args = args, bytes = #text }
end

-- Characters that draw nothing (zero-width, direction marks, joiners, soft hyphen, variation selectors,
-- tag characters): two names that differ only by them look identical to a person.
local function invisible(cp)
  return (cp >= 0x200B and cp <= 0x200F) or (cp >= 0x2028 and cp <= 0x202E) or (cp >= 0x2060 and cp <= 0x206F)
    or cp == 0xFEFF or cp == 0x00AD or cp == 0x180E or cp == 0x061C or cp == 0x034F
    or (cp >= 0xFE00 and cp <= 0xFE0F) or (cp >= 0xE0000 and cp <= 0xE007F)
end

-- Control and invisible characters and over-long names never reach a chat message.
local function display_name(name)
  name = tostring(name or "?"):gsub("%c", "")
  if utf8.len(name) == nil then
    name = name:gsub("[\128-\255]", "?")
  end
  do
    local kept = {}
    for _, cp in utf8.codes(name) do
      if not invisible(cp) then kept[#kept + 1] = utf8.char(cp) end
    end
    name = table.concat(kept)
  end
  if utf8.len(name) > 32 then
    name = name:sub(1, utf8.offset(name, 33) - 1)
  end
  if name == "" then name = "?" end
  return name
end
handler.display_name = display_name

-- ASCII-only case folding: Palworld names are often Japanese, and Lua has no
-- Unicode tables. Non-ASCII characters must match exactly.
local function fold(s)
  return (s:gsub("%u", string.lower))
end

--- Resolves a typed name to one online player.
-- Accepts an exact name, a unique beginning of a name, or "name#abcd" where abcd
-- ends the player's id (shown when two players share a name).
-- Returns player  or  nil, "not_found" | "ambiguous", candidates
function handler.find_player(roster_list, typed)
  typed = trim(typed or "")
  if typed == "" then return nil, "not_found", {} end
  local want, tag = typed, nil
  local base, suffix = typed:match("^(.-)#(%x%x%x%x)$")
  if base and base ~= "" then want, tag = base, suffix:upper() end
  local want_f = fold(want)

  local function pick(want_folded, wanted_tag)
    local exact, prefix = {}, {}
    for _, p in ipairs(roster_list) do
      local nf = fold(display_name(p.name))
      local tag_ok = (wanted_tag == nil) or (p.uid:upper():sub(-4) == wanted_tag)
      if tag_ok then
        if nf == want_folded then
          exact[#exact + 1] = p
        elseif nf:sub(1, #want_folded) == want_folded then
          prefix[#prefix + 1] = p
        end
      end
    end
    return (#exact > 0) and exact or prefix
  end
  local pool = pick(want_f, tag)
  -- a player really named "Taro#1234" is found by typing that whole name
  if #pool == 0 and tag ~= nil then pool = pick(fold(typed), nil) end
  if #pool == 1 then return pool[1] end
  if #pool == 0 then return nil, "not_found", {} end
  table.sort(pool, function(a, b) return a.uid < b.uid end)
  return nil, "ambiguous", pool
end

--- How a player is written in a candidate list: the name, plus "#abcd" when
-- another online player carries the same name.
local function candidate_label(p, roster_list)
  local name = display_name(p.name)
  local twins = 0
  for _, q in ipairs(roster_list) do
    if fold(display_name(q.name)) == fold(name) then twins = twins + 1 end
  end
  if twins > 1 then
    return name .. "#" .. p.uid:upper():sub(-4)
  end
  return name
end

---------------------------------------------------------------------------
-- The handler object
---------------------------------------------------------------------------

local H = {}
H.__index = H

--- services: {
--   api      = { send, players, location, yaw, hp, is_alive, is_admin, guild_bases,
--                trace, teleport, max_players, stand_offset },
--   settings = function() -> settings table,
--   health   = { feature_ok(name) -> bool, reason(name) -> string, summary() -> {...} },
--   prefs    = { language(uid), set_language(uid, lang) },
--   sampler  = TPS sampler (noctua/stats.lua),
--   uptime   = function() -> seconds,
--   reload   = function() -> warnings_count,
--   version  = "x.y.z",
--   log      = noctua/log.lua,
-- }
function handler.new(services)
  local self = setmetatable({ s = services }, H)
  local st = services.settings()
  self.book = tpa_book.new(st.commands.tpa.request_timeout_seconds, st.commands.tpa.max_incoming)
  self.bucket = ratelimit.new_bucket(st.chat.rate_limit_burst, st.chat.rate_limit_refill_seconds)
  self.cooldowns = ratelimit.new_cooldowns()
  self.teleports = teleport.new(services.api, function()
    local t = services.settings().teleport
    return { cancel_move_distance_cm = t.cancel_move_distance_cm, cancel_on_damage = t.cancel_on_damage }
  end)
  self.stuck = stuck_mod.new({ confirm = st.guardian.unstuck_confirm_checks, interval = 5, cooldown = 60,
    max_per_hour = st.guardian.unstuck_max_per_hour })
  self.next_stuck_check = 0
  self.roster = {}      -- uid -> player (as of the last tick or command)
  self.names = {}       -- uid -> display name (kept for leave messages)
  self.pinned = {}      -- uid -> { player, expires }: heard in chat but not yet in the game's player list
  self.graveyard = {}   -- uid -> { hurt, expires }: a player who left keeps the "just hurt" lockout
  self.last_rescan = nil
  self.now = 0
  return self
end

--- Applies changed settings (after /noctua reload).
function H:reconfigure()
  local st = self.s.settings()
  self.book:configure(st.commands.tpa.request_timeout_seconds, st.commands.tpa.max_incoming)
  self.bucket:configure(st.chat.rate_limit_burst, st.chat.rate_limit_refill_seconds)
  self.stuck:configure({ confirm = st.guardian.unstuck_confirm_checks, interval = 5, cooldown = 60,
    max_per_hour = st.guardian.unstuck_max_per_hour })
end

function H:lang(uid)
  return self.s.prefs.language(uid) or i18n.default()
end

function H:text(uid, key, params)
  return i18n.t(self:lang(uid), key, params)
end

--- Sends one line to one player, with the Noctua prefix, in their language.
function H:tell(player, key, params)
  if player == nil then return end
  local lang = self:lang(player.uid)
  local line = i18n.t(lang, "prefix") .. i18n.t(lang, key, params)
  local ok, err = pcall(self.s.api.send, player, line)
  if not ok then
    self.s.log.warn("could not send a message to %s: %s", display_name(player.name), tostring(err))
  end
end

function H:tell_raw(player, line)
  local ok, err = pcall(self.s.api.send, player, line)
  if not ok then
    self.s.log.warn("could not send a message to %s: %s", display_name(player.name), tostring(err))
  end
end

function H:time_text(uid, seconds)
  return i18n.duration(self:lang(uid), math.ceil(seconds))
end

--- Refreshes the roster from the game. Returns the list.
function H:refresh_roster()
  local ok, list = pcall(self.s.api.players)
  if not ok or type(list) ~= "table" then
    self.s.log.warn("player list unavailable: %s", tostring(list))
    return {}
  end
  local roster = {}
  for _, p in ipairs(list) do
    if p.uid then
      roster[p.uid] = p
      self.names[p.uid] = display_name(p.name)
    end
  end
  -- a player heard in chat is connected even if the game's list has not caught up yet
  for uid, pin in pairs(self.pinned) do
    if roster[uid] ~= nil or pin.expires <= self.now then
      self.pinned[uid] = nil
    else
      roster[uid] = pin.player
    end
  end
  -- anyone who vanished since the last refresh has left
  for uid in pairs(self.roster) do
    if roster[uid] == nil then self:on_player_left(uid) end
  end
  for uid in pairs(roster) do
    if self.roster[uid] == nil then self:on_player_joined(uid) end
  end
  self.roster = roster
  return list
end

function H:roster_list()
  local list = {}
  for _, p in pairs(self.roster) do list[#list + 1] = p end
  table.sort(list, function(a, b) return a.uid < b.uid end)
  return list
end

function H:on_player_joined(uid)
  local g = self.graveyard[uid]
  self.graveyard[uid] = nil
  if g and g.expires > self.now then
    local have = self.teleports.last_hurt[uid]
    if have == nil or g.hurt > have then self.teleports.last_hurt[uid] = g.hurt end
  end
end

--- At most one forced full player scan per 10 s: it walks every game object.
function H:rescan_throttled()
  if not self.s.api.rescan then return false end
  if self.last_rescan ~= nil and self.now - self.last_rescan < 10 then return false end
  self.last_rescan = self.now
  pcall(self.s.api.rescan)
  return true
end

--- A player who sent a command must be in the roster, or their warmups would be dropped as
-- "left the server". Ask the game again (throttled), and otherwise trust the chat for 35 s.
function H:ensure_known(player)
  if self.roster[player.uid] ~= nil then return end
  if self:rescan_throttled() then self:refresh_roster() end
  if self.roster[player.uid] ~= nil then return end
  self.pinned[player.uid] = { player = player, expires = self.now + 35 }
  self.roster[player.uid] = player
  self:on_player_joined(player.uid)
end

--- How a player is named in a notice: the name, plus "#abcd" when another player online has
-- the same name, so a look-alike cannot pass for a friend.
function H:label(uid)
  local p = self.roster[uid]
  if p then return candidate_label(p, self:roster_list()) end
  return self.names[uid] or "?"
end

function H:on_player_left(uid)
  local name = self.names[uid] or "?"
  local hurt = self.teleports.last_hurt[uid]
  if hurt then self.graveyard[uid] = { hurt = hurt, expires = self.now + 600 } end
  for _, req in ipairs(self.book:drop_player(uid)) do
    local other = (req.requester == uid) and req.target or req.requester
    local p = self.roster[other]
    if p then self:tell(p, "tpa_left", { name = name }) end
  end
  self.teleports:forget(uid)
  self.bucket:forget(uid)
  self.stuck:forget(uid)
  self.names[uid] = nil -- nothing refers to a player who left; keeping the name would grow forever
end

---------------------------------------------------------------------------
-- Commands
---------------------------------------------------------------------------

local COMMANDS = {}
local ORDER = {}

local function command(def)
  COMMANDS[def.name] = def
  ORDER[#ORDER + 1] = def.name
end

--- Is the command switched on in the settings and are its game functions present?
function H:available(def)
  local st = self.s.settings()
  if def.setting and not def.setting(st) then return false, "command_disabled" end
  if def.feature and not self.s.health.feature_ok(def.feature) then return false, "feature_unavailable" end
  return true
end

function H:cooldown_check(player, def_name, label)
  local left = self.cooldowns:remaining(player.uid, def_name, self.now)
  if left > 0 then
    self:tell(player, "cooldown", { command = label, time = self:time_text(player.uid, left) })
    return false
  end
  return true
end

function H:hurt_check(player, lockout)
  local left = self.teleports:hurt_remaining(player.uid, lockout, self.now)
  if left > 0 then
    self:tell(player, "tp_in_combat", { time = self:time_text(player.uid, left) })
    return false
  end
  return true
end

-- Ignore list for traces: the players involved never count as ground or walls.
local function landing_options(st, extra)
  local o = {
    radius = st.teleport.landing_search_radius_cm,
    headroom = st.teleport.headroom_cm,
  }
  for k, v in pairs(extra or {}) do o[k] = v end
  return o
end

--- Finds where `player` can stand near `center`. `ignore` lists what traces skip
-- (the players involved, the palbox).
function H:find_spot(player, center, extra, ignore)
  local st = self.s.settings()
  local api = self.s.api
  local opts = landing_options(st, extra)
  if api.stand_offset then
    local ok, offset = pcall(api.stand_offset, player)
    if ok and type(offset) == "number" and offset > 0 then opts.stand_offset = offset + 10 end
  end
  return landing.find(center, opts, function(a, b) return api.trace(a, b, ignore) end)
end

local function yaw_towards(from, to)
  return math.deg(math.atan(to.y - from.y, to.x - from.x))
end

command {
  name = "help",
  run = function(self, player)
    self:tell(player, "help_header")
    for _, name in ipairs(ORDER) do
      local def = COMMANDS[name]
      if def.help and self:available(def) then
        if not def.admin or self:is_admin(player) then
          self:tell_raw(player, "  " .. self:text(player.uid, def.help))
        end
      end
    end
  end,
}

command {
  name = "home",
  help = "help_home",
  feature = "home",
  setting = function(st) return st.commands.home.enabled end,
  run = function(self, player, cmd)
    local st = self.s.settings()
    local conf = st.commands.home
    local api = self.s.api

    local ok_bases, bases, why = pcall(api.guild_bases, player)
    if not ok_bases then
      self.s.log.warn("guild_bases failed: %s", tostring(bases))
      return self:tell(player, "tp_failed")
    end
    if bases == nil then
      return self:tell(player, why == "no_guild" and "home_no_guild" or "tp_failed")
    end
    if #bases == 0 then
      return self:tell(player, "home_no_base")
    end
    table.sort(bases, function(a, b) return tostring(a.id) < tostring(b.id) end)

    local arg = cmd.args[1]
    if arg and arg:lower() == "list" then
      local here = api.location(player)
      self:tell(player, "home_list_header", { count = #bases })
      for i, base in ipairs(bases) do
        local dist = here and landing.distance(here, base.location) or 0
        self:tell_raw(player, self:text(player.uid, "home_list_entry",
          { index = i, distance = i18n.distance(self:lang(player.uid), dist) }))
      end
      return
    end

    local index = 1
    if arg then
      index = math.tointeger(tonumber(arg))
      if index == nil or index < 1 or index > #bases or #cmd.args > 1 then
        return self:tell(player, "home_bad_index", { count = #bases })
      end
    end

    if self.teleports:pending(player.uid) then return self:tell(player, "tp_already_pending") end
    if not self:cooldown_check(player, "home", "/home") then return end
    if not self:hurt_check(player, conf.combat_lockout_seconds) then return end

    local base_id = bases[index].id
    local resolve = function(p)
      -- The base may have moved or gone during the warmup: look it up again.
      local ok2, fresh = pcall(api.guild_bases, p)
      if not ok2 or type(fresh) ~= "table" then return nil, "tp_failed" end
      local target
      for _, b in ipairs(fresh) do if b.id == base_id then target = b break end end
      if target == nil then return nil, "home_no_base" end
      local spot = self:find_spot(p, target.location, { first_ring = 250 }, { p, target })
      if spot == nil then return nil, "home_no_safe_spot" end
      return spot, yaw_towards(spot, target.location), { index = index }
    end
    local done = function(ok, key, params)
      if ok then
        self.cooldowns:start(player.uid, "home", conf.cooldown_seconds, self.now)
        self.s.log.info("home: %s teleported to base %d", display_name(player.name), index)
        self:tell(player, "home_arrived", params or { index = index })
      else
        self:tell(player, key, params)
      end
    end
    local started, err = self.teleports:begin(player, "home", conf.warmup_seconds, self.now, resolve, done)
    if not started then return self:tell(player, err) end
    if conf.warmup_seconds > 0 then
      self:tell(player, "tp_warmup", { seconds = conf.warmup_seconds })
    end
  end,
}

command {
  name = "tpa",
  help = "help_tpa",
  feature = "tpa",
  setting = function(st) return st.commands.tpa.enabled end,
  run = function(self, player, cmd)
    local conf = self.s.settings().commands.tpa
    if cmd.rest == "" then return self:tell(player, "tpa_usage") end
    self:refresh_roster()
    local list = self:roster_list()
    local target, why, candidates = handler.find_player(list, cmd.rest)
    if target == nil and why == "not_found" and self:rescan_throttled() then
      -- someone who joined moments ago may not be in the cached roster yet
      self:refresh_roster()
      list = self:roster_list()
      target, why, candidates = handler.find_player(list, cmd.rest)
    end
    if target == nil then
      if why == "ambiguous" then
        local labels = {}
        for i, c in ipairs(candidates) do
          if i > 5 then break end
          labels[#labels + 1] = candidate_label(c, list)
        end
        return self:tell(player, "tpa_ambiguous",
          { name = display_name(cmd.rest), candidates = i18n.join(self:lang(player.uid), labels) })
      end
      return self:tell(player, "tpa_not_found", { name = display_name(cmd.rest) })
    end
    if target.uid == player.uid then return self:tell(player, "tpa_self") end
    if not self:hurt_check(player, conf.combat_lockout_seconds) then return end
    if not self:cooldown_check(player, "tpa", "/tpa") then return end

    local ok, result, replaced = self.book:send(player.uid, target.uid, self.now)
    local target_name = self:label(target.uid)
    if not ok then
      if result == "duplicate" then
        return self:tell(player, "tpa_sent", { target = target_name, seconds = conf.request_timeout_seconds })
      elseif result == "target_busy" then
        return self:tell(player, "tpa_target_busy", { target = target_name })
      end
      return self:tell(player, "tpa_self")
    end
    if replaced then
      local old = self.roster[replaced.target]
      self:tell(player, "tpa_replaced", { target = self:label(replaced.target) })
      if old then self:tell(old, "tpa_cancelled_target", { requester = self:label(player.uid) }) end
    end
    self:tell(player, "tpa_sent", { target = target_name, seconds = conf.request_timeout_seconds })
    self:tell(target, "tpa_received", { requester = self:label(player.uid), seconds = conf.request_timeout_seconds })
  end,
}

-- Picks the request a /tpaccept or /tpdeny refers to. Returns request or nil (already told).
function H:pick_request(player, cmd)
  local requester_uid = nil
  if cmd.rest ~= "" then
    local incoming = self.book:incoming(player.uid, self.now)
    local pool = {}
    for _, req in ipairs(incoming) do
      local p = self.roster[req.requester]
      if p then pool[#pool + 1] = p end
    end
    local p, why = handler.find_player(pool, cmd.rest)
    if p == nil then
      if #incoming == 0 then
        self:tell(player, "tpa_none_pending")
      elseif why == "ambiguous" then
        self:tell(player, "tpa_which", { candidates = self:requester_labels(player.uid) })
      else
        self:tell(player, "tpa_not_found", { name = display_name(cmd.rest) })
      end
      return nil
    end
    requester_uid = p.uid
  end
  local req, why = self.book:take(player.uid, requester_uid, self.now)
  if req == nil then
    if why == "ambiguous" then
      self:tell(player, "tpa_which", { candidates = self:requester_labels(player.uid) })
    else
      self:tell(player, "tpa_none_pending")
    end
    return nil
  end
  return req
end

function H:requester_labels(uid)
  local list = self:roster_list()
  local labels = {}
  for _, req in ipairs(self.book:incoming(uid, self.now)) do
    local p = self.roster[req.requester]
    if p then labels[#labels + 1] = candidate_label(p, list) end
  end
  return i18n.join(self:lang(uid), labels)
end

command {
  name = "tpaccept",
  help = "help_tpaccept",
  feature = "tpa",
  setting = function(st) return st.commands.tpa.enabled end,
  run = function(self, player, cmd)
    local conf = self.s.settings().commands.tpa
    self:refresh_roster()
    local req = self:pick_request(player, cmd)
    if req == nil then return end
    local requester = self.roster[req.requester]
    local requester_name = self:label(req.requester)
    if requester == nil then
      return self:tell(player, "tpa_left", { name = requester_name })
    end
    local target_uid, target_name = player.uid, self:label(player.uid)

    -- the cooldown starts on arrival, so a second request sent during a warmup must be
    -- stopped here, where it would otherwise slip through
    local cd = self.cooldowns:remaining(requester.uid, "tpa", self.now)
    if cd > 0 then
      self:tell(player, "tpa_requester_cooldown", { requester = requester_name, time = self:time_text(player.uid, cd) })
      return self:tell(requester, "cooldown", { command = "/tpa", time = self:time_text(requester.uid, cd) })
    end

    if self.teleports:pending(requester.uid)
        or self.teleports:hurt_remaining(requester.uid, conf.combat_lockout_seconds, self.now) > 0 then
      self:tell(player, "tpa_requester_busy", { requester = requester_name })
      if self.teleports:pending(requester.uid) then
        self:tell(requester, "tp_already_pending")
      else
        self:hurt_check(requester, conf.combat_lockout_seconds)
      end
      return
    end

    local api = self.s.api
    local resolve = function(p)
      local target = self.roster[target_uid]
      if target == nil then return nil, "tpa_left", { name = target_name } end
      local loc = api.location(target)
      if loc == nil then return nil, "tp_failed" end
      local spot = self:find_spot(p, loc, { allow_center = true }, { p, target })
      if spot == nil then return nil, "tpa_no_safe_spot", { target = target_name } end
      return spot, yaw_towards(spot, loc), { target = target_name }
    end
    local done = function(ok, key, params)
      if ok then
        self.cooldowns:start(requester.uid, "tpa", conf.cooldown_seconds, self.now)
        self.s.log.info("tpa: %s teleported to %s", requester_name, target_name)
        self:tell(requester, "tpa_arrived", { target = target_name })
      else
        self:tell(requester, key, params)
      end
    end
    local started, err = self.teleports:begin(requester, "tpa", conf.warmup_seconds, self.now, resolve, done)
    if not started then
      self:tell(player, "tpa_requester_busy", { requester = requester_name })
      return self:tell(requester, err)
    end
    self:tell(player, "tpa_accepted_target", { requester = requester_name })
    self:tell(requester, "tpa_accepted_requester", { target = target_name })
    if conf.warmup_seconds > 0 then
      self:tell(requester, "tp_warmup", { seconds = conf.warmup_seconds })
    end
  end,
}

command {
  name = "tpdeny",
  feature = "tpa",
  setting = function(st) return st.commands.tpa.enabled end,
  run = function(self, player, cmd)
    self:refresh_roster()
    local req = self:pick_request(player, cmd)
    if req == nil then return end
    local requester_name = self:label(req.requester)
    self:tell(player, "tpa_denied_target", { requester = requester_name })
    local requester = self.roster[req.requester]
    if requester then
      self:tell(requester, "tpa_denied_requester", { target = self:label(player.uid) })
    end
  end,
}

command {
  name = "tpcancel",
  help = "help_tpcancel",
  feature = "tpa",
  setting = function(st) return st.commands.tpa.enabled end,
  run = function(self, player)
    local req = self.book:cancel(player.uid)
    if req == nil then return self:tell(player, "tpa_no_outgoing") end
    self:tell(player, "tpa_cancelled_requester", { target = self:label(req.target) })
    local target = self.roster[req.target]
    if target then
      self:tell(target, "tpa_cancelled_target", { requester = self:label(player.uid) })
    end
  end,
}

command {
  name = "stats",
  help = "help_stats",
  feature = "stats",
  setting = function(st) return st.commands.stats.enabled end,
  run = function(self, player)
    local conf = self.s.settings().commands.stats
    if not self:cooldown_check(player, "stats", "/stats") then return end
    self.cooldowns:start(player.uid, "stats", conf.cooldown_seconds, self.now)
    local list = self:refresh_roster()
    local uid = player.uid
    local lang = self:lang(uid)
    self:tell(player, "stats_header")
    self:tell_raw(player, "  " .. i18n.t(lang, "stats_uptime", { uptime = i18n.duration(lang, self.s.uptime()) }))
    local ok_max, max = pcall(self.s.api.max_players)
    if ok_max and type(max) == "number" and max > 0 then
      self:tell_raw(player, "  " .. i18n.t(lang, "stats_players", { count = #list, max = math.floor(max) }))
    else
      self:tell_raw(player, "  " .. i18n.t(lang, "stats_players_nomax", { count = #list }))
    end
    local tps = self.s.sampler:tps()
    if tps then
      local window = math.floor(self.s.sampler:span() + 0.5)
      self:tell_raw(player, "  " .. i18n.t(lang, "stats_tps", { tps = string.format("%.1f", tps), window = window }))
    else
      self:tell_raw(player, "  " .. i18n.t(lang, "stats_tps_unknown"))
    end
    self:tell_raw(player, "  " .. i18n.t(lang, "stats_version", { version = self.s.version }))
  end,
}

-- EPalItemOperationResult values that matter here (Palworld 1.0 header, declaration order)
local ITEM_OK, ITEM_UNKNOWN_ID = 0, 15

local function parse_item(spec)
  local id, count = spec:match("^([A-Za-z][A-Za-z0-9_]*):([1-9]%d*)$")
  return id, math.tointeger(tonumber(count))
end

command {
  name = "kit",
  help = "help_kit",
  feature = "kit",
  setting = function(st) return st.commands.kit.enabled end,
  run = function(self, player, cmd)
    if #cmd.args ~= 1 then return self:tell(player, "kit_usage") end
    if cmd.args[1]:lower() ~= "starter" then
      return self:tell(player, "kit_unknown", { name = display_name(cmd.args[1]) })
    end
    local uid = player.uid
    local prefs = self.s.prefs
    -- A kit is handed out only if the fact that it was can be kept: not while the saved file is
    -- unreadable or damaged, not while an earlier save failed, and not unless a save works right now.
    if prefs.writable and not prefs.writable() then return self:tell(player, "kit_unsaved") end
    if prefs.probe and not prefs.probe() then return self:tell(player, "kit_unsaved") end

    -- An ITEM is given once per player, whatever count the list says later (an admin who changes
    -- PalSphere:10 to PalSphere:15 does not give everyone another 15); an item added to the list
    -- later is given to players who already claimed the rest.
    local delivered_ids = {}
    for spec in pairs(prefs.kit_delivered(uid, "starter")) do
      local id = spec:match("^([^:]+):")
      if id then delivered_ids[id] = true end
    end
    local pending = {}
    for _, spec in ipairs(self.s.settings().commands.kit.starter_items) do
      local id, count = parse_item(spec)
      if id and not delivered_ids[id] then pending[#pending + 1] = { spec = spec, id = id, count = count } end
    end
    if #pending == 0 then return self:tell(player, "kit_already") end

    local partial = prefs.kit_partial(uid, "starter")
    local received, bad, stopped_short, unverified = 0, 0, false, false
    local name = display_name(player.name)
    local function done(item)
      prefs.kit_mark(uid, "starter", { item.spec })
      prefs.kit_partial_set(uid, "starter", item.id, nil)
      partial[item.id] = nil
      received = received + 1
    end
    for _, item in ipairs(pending) do
      local need = item.count - (partial[item.id] or 0)
      if need <= 0 then
        -- the list was lowered below what already arrived: nothing is missing any more
        done(item)
      else
        local ok, res, why = pcall(self.s.api.give_item, player, item.id, need)
        if not ok or res == nil then
          self.s.log.warn("kit: giving %s to %s failed: %s", item.spec, name, tostring(ok and why or res))
          stopped_short = true
          break
        end
        local given, code = res.given, res.code
        if code == ITEM_UNKNOWN_ID then
          bad = bad + 1
          self.s.log.warn("kit: the game does not know the item id %q (in commands.kit.starter_items); it was skipped", item.id)
        elseif code == ITEM_OK and given == 0 then
          -- the game said "success" but nothing arrived: never mark it as delivered
          unverified = true
          self.s.log.warn("kit: the game answered success for %s but %s's inventory did not grow", item.spec, name)
          break
        elseif (given ~= nil and given >= need) or (given == nil and code == ITEM_OK) then
          done(item)
        elseif given ~= nil and given > 0 then
          partial[item.id] = (partial[item.id] or 0) + given
          if not prefs.kit_partial_set(uid, "starter", item.id, partial[item.id]) then
            self.s.log.error("kit: %d of %s reached %s but the record could not be saved", given, item.id, name)
          end
          stopped_short = true
          break
        else
          stopped_short = true -- nothing arrived: most likely a full inventory
          break
        end
      end
    end

    if unverified then return self:tell(player, "kit_unverified") end
    if stopped_short then
      self.s.log.info("kit: %s got %d item(s) of the starter kit before it stopped short", name, received)
      return self:tell(player, (received > 0 or next(partial) ~= nil) and "kit_partial" or "kit_none")
    end
    if received > 0 then
      self.s.log.info("kit: %s received the starter kit (%d item types)", name, received)
      self:tell(player, "kit_done", { count = received })
    end
    if bad > 0 then self:tell(player, "kit_bad_items", { count = bad }) end
    if received == 0 and bad == 0 then self:tell(player, "kit_already") end
  end,
}

command {
  name = "unstuck",
  help = "help_unstuck",
  feature = "unstuck",
  setting = function(st) return st.commands.unstuck.enabled end,
  run = function(self, player)
    local conf = self.s.settings().commands.unstuck
    if self.teleports:pending(player.uid) then return self:tell(player, "tp_already_pending") end
    if not self:cooldown_check(player, "unstuck", "/unstuck") then return end
    if not self:hurt_check(player, conf.combat_lockout_seconds) then return end
    local ok_call, moved, why = pcall(self.s.api.unstuck, player)
    if ok_call and moved == true then
      self.cooldowns:start(player.uid, "unstuck", conf.cooldown_seconds, self.now)
      self.s.log.info("unstuck: %s asked the game to move them to a safe point", display_name(player.name))
      self:tell(player, "unstuck_sent")
    else
      self.s.log.warn("unstuck failed for %s: %s", display_name(player.name), tostring(ok_call and why or moved))
      self:tell(player, "unstuck_failed")
    end
  end,
}

command {
  name = "lang",
  help = "help_lang",
  setting = function(st) return st.commands.lang.enabled end,
  run = function(self, player, cmd)
    local want = cmd.args[1] and cmd.args[1]:lower()
    if not want or #cmd.args > 1 or not i18n.is_language(want) then
      return self:tell(player, "lang_usage")
    end
    self.s.prefs.set_language(player.uid, want)
    self:tell(player, "lang_set")
  end,
}

-- How a setting's state is worded for the admin.
local STATE_KEYS = {
  ok = "ws_state_ok", off = "ws_state_off", failed = "ws_state_failed", unavailable = "ws_state_unavailable",
  missing = "ws_state_missing",
}

-- The settings that always get a line in /noctua base (with a friendly name); the others only
-- when Noctua manages them.
local BASE_LINES = {
  BaseCampWorkerMaxNum = "admin_base_workers",
  BuildObjectDeteriorationDamageRate = "admin_base_decay",
  PalEggDefaultHatchingTime = "admin_base_eggs",
  autoSaveSpan = "admin_base_autosave",
  Combi_PassiveInheritNum = "admin_base_passives",
}

local function show_value(v)
  if v == nil then return "?" end
  if type(v) == "table" then
    local parts = {}
    for i, x in ipairs(v) do parts[i] = show_value(x) end
    return "[" .. table.concat(parts, ", ") .. "]"
  end
  if math.type(v) == "integer" then return string.format("%d", v) end
  if type(v) == "number" then return string.format("%g", v) end
  return tostring(v)
end

--- /noctua base: what the game uses now for the settings Noctua manages, and the
-- worker cap the game itself computes for the admin's own guild.
function H:admin_base(player)
  local lang = self:lang(player.uid)
  self:tell(player, "admin_base_header")
  if not self.s.health.feature_ok("worldsettings") then
    self:tell_raw(player, i18n.t(lang, "admin_base_unreadable", { reason = self.s.health.reason("worldsettings") or "?" }))
  else
    for _, f in ipairs(self.s.world.status().fields) do
      local key = BASE_LINES[f.name]
      if key or f.desired ~= nil then
        local target = (f.desired ~= nil) and show_value(f.desired) or i18n.t(lang, "admin_target_none")
        local state = i18n.t(lang, STATE_KEYS[f.state] or "ws_state_unavailable")
        if key then
          self:tell_raw(player, i18n.t(lang, key, { actual = show_value(f.actual), target = target, state = state }))
        else
          self:tell_raw(player, i18n.t(lang, "admin_setting_line",
            { name = f.name, actual = show_value(f.actual), target = target, state = state }))
        end
      end
    end
  end
  if not self.s.health.feature_ok("basecap") then
    self:tell_raw(player, i18n.t(lang, "admin_base_guild_unknown", { reason = self.s.health.reason("basecap") or "?" }))
    return
  end
  local ok, level, cap = pcall(self.s.api.worker_capacity, player)
  if ok and level ~= nil and cap ~= nil then
    self:tell_raw(player, i18n.t(lang, "admin_base_guild", { level = show_value(level), cap = show_value(cap) }))
  else
    self:tell_raw(player, i18n.t(lang, "admin_base_guild_unknown", { reason = tostring(ok and cap or level) }))
  end
end

local BACKUP_PHASE_KEYS = {
  idle = "backup_phase_idle", settling = "backup_phase_settling", copying = "backup_phase_copying",
  cleaning = "backup_phase_cleaning",
}

--- /noctua backup: the state of the scheduled backups.
function H:admin_backup(player)
  local lang = self:lang(player.uid)
  local ok, st = pcall(self.s.backup.status, self.now)
  if not ok or type(st) ~= "table" then
    return self:tell(player, "internal_error")
  end
  if not st.enabled then return self:tell(player, "admin_backup_off") end
  local nxt = st.seconds_to_next and i18n.duration(lang, st.seconds_to_next) or "?"
  self:tell(player, "admin_backup_line", {
    phase = i18n.t(lang, BACKUP_PHASE_KEYS[st.phase] or "backup_phase_idle"), ok = st.ok_count,
    discarded = st.discarded, next = nxt,
  })
  if st.last_ok then
    self:tell_raw(player, i18n.t(lang, "admin_backup_last", { name = st.last_ok.name, bytes = st.last_ok.bytes }))
  end
  if st.last_error then
    self:tell_raw(player, i18n.t(lang, "admin_backup_error", { error = st.last_error }))
  end
end

local RAID_MAX_DISTANCE_CM = 30000 -- an admin must be within 300 m of the base to raid it

--- /noctua raid: asks the game to march a raid on the base nearest to the admin.
function H:admin_raid(player)
  if not self.s.health.feature_ok("raid") then
    return self:tell(player, "admin_raid_unavailable", { reason = self.s.health.reason("raid") or "?" })
  end
  local ok, base, why = pcall(self.s.api.nearest_base, player)
  if not ok or base == nil then
    return self:tell(player, "admin_raid_no_base", { reason = tostring(ok and why or base) })
  end
  local lang = self:lang(player.uid)
  if base.distance > RAID_MAX_DISTANCE_CM then
    return self:tell(player, "admin_raid_too_far", { distance = i18n.distance(lang, base.distance) })
  end
  local ok_call, started, why = pcall(self.s.api.start_raid, base.guid)
  if ok_call and started == true then
    self.s.log.info("raid: %s started a raid on the base %s (%s away)", display_name(player.name), base.id,
      i18n.distance("en", base.distance))
    self:tell(player, "admin_raid_started", { distance = i18n.distance(lang, base.distance) })
  else
    local reason = ok_call and why or started
    self.s.log.warn("raid: could not start a raid on the base %s: %s", base.id, tostring(reason))
    self:tell(player, "admin_raid_failed", { reason = tostring(reason) })
  end
end

function H:is_admin(player)
  if not self.s.health.feature_ok("admin") then return false end
  local ok, admin = pcall(self.s.api.is_admin, player)
  return ok and admin == true
end

command {
  name = "noctua",
  help = "help_admin",
  admin = true,
  run = function(self, player, cmd)
    local sub = cmd.args[1] and cmd.args[1]:lower()
    local lang = self:lang(player.uid)
    if sub == "health" then
      local sum = self.s.health.summary()
      self:tell(player, "admin_health_header", { ok = sum.ok, missing = sum.missing })
      for i, symbol in ipairs(sum.missing_symbols) do
        if i > 6 then break end
        self:tell_raw(player, i18n.t(lang, "admin_health_symbol", { symbol = symbol }))
      end
      for _, f in ipairs(sum.features) do
        local state = f.ok and i18n.t(lang, "admin_state_on")
          or i18n.t(lang, "admin_state_off", { reason = f.reason or "?" })
        self:tell_raw(player, i18n.t(lang, "admin_health_feature", { feature = f.name, state = state }))
      end
    elseif sub == "base" then
      self:admin_base(player)
    elseif sub == "raid" then
      self:admin_raid(player)
    elseif sub == "backup" then
      self:admin_backup(player)
    elseif sub == "reload" then
      if not self.s.settings().admin.reload_enabled then
        return self:tell(player, "command_disabled")
      end
      local warnings = self.s.reload()
      self:reconfigure()
      self.s.log.info("config reloaded in game by %s", display_name(player.name))
      self:tell(player, "admin_reload_ok", { warnings = warnings })
    elseif sub == "version" then
      self:tell(player, "admin_version", { version = self.s.version, lua = _VERSION })
    else
      self:tell(player, "admin_usage")
    end
  end,
}

--- Handles one chat line. Returns true when the line was a Noctua command.
function H:handle(player, line, now)
  if type(player) ~= "table" or player.uid == nil then return false end
  local st = self.s.settings()
  local name = handler.command_name(line, st.chat.command_prefixes)
  if name == nil then return false end
  local def = COMMANDS[name]
  if def == nil then return false end -- not ours: leave it to the game, log nothing

  self.now = now
  self.names[player.uid] = display_name(player.name)
  self:ensure_known(player)

  local allowed, first = self.bucket:take(player.uid, now)
  if not allowed then
    if first then self:tell(player, "rate_limited") end
    return true
  end
  -- before any splitting: a huge line costs one comparison
  if #line > st.chat.max_line_bytes then
    self:tell(player, "line_too_long")
    return true
  end
  local cmd = handler.parse(line, st.chat.command_prefixes)
  if cmd == nil then return false end
  if def.admin and not self:is_admin(player) then
    self:tell(player, "admin_only")
    return true
  end
  local ok_avail, why = self:available(def)
  if not ok_avail then
    self:tell(player, why)
    return true
  end

  local ok, err = pcall(def.run, self, player, cmd)
  if not ok then
    self.s.log.error("/%s failed: %s", cmd.name, tostring(err))
    self:tell(player, "internal_error")
  end
  return true
end

--- Looks for players embedded in the terrain every 5 s: mode "log" only writes it down,
-- "rescue" also asks the game to move them (see noctua/stuck.lua for the safeguards).
function H:unstuck_tick(now)
  local st = self.s.settings()
  local mode = st.guardian.unstuck_auto
  if mode == "off" or now < self.next_stuck_check then return end
  if not self.s.health.feature_ok("embedded") then return end
  if mode == "rescue" and not self.s.health.feature_ok("unstuck") then return end
  self.next_stuck_check = now + 5
  local api = self.s.api
  for uid, p in pairs(self.roster) do
    local ok_alive, alive = pcall(api.is_alive, p)
    if ok_alive and alive == false then
      self.stuck:observe(uid, nil, now)
    elseif self.teleports:pending(uid) then
      self.stuck:observe(uid, nil, now)
    else
      local ok, embedded = pcall(api.embedded, p)
      -- true = embedded, false = free (clears the count), nil = the check could not be made
      local reading = nil
      if ok then reading = embedded end
      local verdict = self.stuck:observe(uid, reading, now)
      local name = display_name(p.name)
      if verdict == "rescue" then
        if mode == "log" then
          self.s.log.warn("stuck check (log only): %s has looked embedded in the terrain for %d checks in a row; "
            .. "with guardian.unstuck_auto = rescue they would be moved", name, st.guardian.unstuck_confirm_checks)
          self.stuck:rescued(uid, true, now)
        else
          local ok_call, moved, why = pcall(api.unstuck, p)
          local success = ok_call and moved == true
          self.stuck:rescued(uid, success, now)
          if success then
            self.s.log.warn("stuck check: %s looked embedded in the terrain; the game was asked to move them", name)
            self:tell(p, "unstuck_auto_moved")
          else
            self.s.log.warn("stuck check: could not move %s: %s", name, tostring(ok_call and why or moved))
          end
        end
      elseif verdict == "blocked" and self.stuck:mark_blocked_reported(uid) then
        self.s.log.warn("stuck check: %s still looks embedded, but the limit of %d automatic rescues per hour is reached; "
          .. "a wrong detection must never move someone in a loop", name, st.guardian.unstuck_max_per_hour)
      end
    end
  end
end

--- Periodic work on the game thread: roster, HP samples, warmups, expiries.
function H:tick(now)
  self.now = now
  self:refresh_roster()
  local api = self.s.api
  for uid, p in pairs(self.roster) do
    local ok, hp = pcall(api.hp, p)
    if ok then self.teleports:observe_hp(uid, hp, now) end
  end
  for _, err in ipairs(self.teleports:tick(now, self.roster)) do
    self.s.log.warn("teleport: %s", tostring(err))
  end
  self:unstuck_tick(now)
  for _, req in ipairs(self.book:expire(now)) do
    local requester, target = self.roster[req.requester], self.roster[req.target]
    if requester then
      self:tell(requester, "tpa_expired_requester", { target = self:label(req.target) })
    end
    if target then
      self:tell(target, "tpa_expired_target", { requester = self:label(req.requester) })
    end
  end
  self.cooldowns:sweep(now)
  for uid, g in pairs(self.graveyard) do
    if g.expires <= now then self.graveyard[uid] = nil end
  end
end

--- Names of every command, in help order (for docs and tests).
function handler.command_names()
  local out = {}
  for i, n in ipairs(ORDER) do out[i] = n end
  return out
end

handler.COMMANDS = COMMANDS

return handler
