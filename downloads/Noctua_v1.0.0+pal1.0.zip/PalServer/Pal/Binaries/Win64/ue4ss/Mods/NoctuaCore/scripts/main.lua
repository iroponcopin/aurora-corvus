-- main.lua (Noctua Core Bootstrap)
--
-- Runs once when UE4SS starts the mod on the dedicated server:
--   1. finds its own folder and loads config/noctua_settings.json;
--   2. checks that every game function it needs exists (the health check) and
--      switches off only what depends on a missing one;
--   3. hooks the chat RPC. The hook only queues lines that start with a command
--      prefix; the work happens on the game thread in the ticker, which also puts
--      Noctua's reply after anything the game itself prints for the same line;
--   4. starts the ticker (warmups, request expiry, TPS samples, roster).
-- Nothing here stops the server: a failure is logged and the vanilla game goes on.

local NOCTUA_VERSION = "1.0.0"
local TICK_MS = 250
local QUEUE_LIMIT = 64
local HEALTH_RETRY_SECONDS = { 10, 30, 90, 300 }

local function boot_print(line)
  print("[NOCTUA] " .. line .. "\n")
end

-- 1. Where am I? UE4SS loads main.lua under the chunk name "@<full path>".
local function locate()
  -- Level 1 must be a function defined in this file: pcall(debug.getinfo, 1) would
  -- describe pcall itself (a C function) and never find the folder.
  local ok, info = pcall(function() return debug.getinfo(1, "S") end)
  local source = ok and info and info.source or ""
  local scripts = source:match("^@(.*)[/\\][^/\\]+$")
  if scripts then
    scripts = scripts:gsub("\\", "/")
    return scripts, scripts:match("^(.*)/[^/]+$")
  end
  -- Fallback: the process runs in Pal/Binaries/Win64; try both UE4SS layouts.
  for _, root in ipairs({ "ue4ss/Mods/NoctuaCore", "Mods/NoctuaCore" }) do
    for _, dir in ipairs({ "scripts", "Scripts" }) do
      local h = io.open(root .. "/" .. dir .. "/main.lua", "rb")
      if h then
        h:close()
        return root .. "/" .. dir, root
      end
    end
  end
  return nil, nil
end

local SCRIPTS, MOD_ROOT = locate()
if SCRIPTS then
  package.path = SCRIPTS .. "/?.lua;" .. package.path
end

local function boot()
  local log = require("noctua.log")
  log.set_sink(function(line) print(line .. "\n") end)
  log.info("Initializing Noctua %s (%s) ...", NOCTUA_VERSION, _VERSION)
  if not MOD_ROOT then
    log.error("could not find the NoctuaCore folder; Noctua is not starting (vanilla chat is unaffected)")
    return
  end

  local fs = require("noctua.fs")
  local config = require("noctua.config")
  local i18n = require("noctua.i18n")
  local health_mod = require("noctua.health")
  local prefs_mod = require("noctua.prefs")
  local stats = require("noctua.stats")
  local world_settings = require("noctua.world_settings")
  local backup_mod = require("noctua.backup")
  local shell_mod = require("noctua.shell")
  local pal_api = require("noctua.pal_api")
  local handler_mod = require("command_handler")

  local config_path = fs.join(MOD_ROOT, "config", config.FILE_NAME)
  local settings

  local function apply_report(report)
    local warnings = 0
    for _, r in ipairs(report) do
      if r.level == "error" then
        log.error("%s", r.message)
        warnings = warnings + 1
      elseif r.level == "warn" then
        log.warn("%s", r.message)
        warnings = warnings + 1
      else
        log.debug("%s", r.message)
      end
    end
    return warnings
  end

  local function load_settings()
    local loaded, report, created = config.load(fs, config_path)
    settings = loaded
    log.set_level(settings.log_level)
    i18n.set_default(settings.language)
    local warnings = apply_report(report)
    if created then log.info("created %s with the defaults", config_path) end
    log.info("settings: %s (%d warnings)", config_path, warnings)
    return warnings
  end
  load_settings()

  local prefs = prefs_mod.new(fs, fs.join(MOD_ROOT, "data", "players.json"), log)
  prefs:load()
  local prefs_retry_at, prefs_flush_at = nil, nil

  -- 2. health check
  pal_api.init(_G, log)
  local health = health_mod.new(pal_api.REQUIREMENTS)
  health:run(pal_api.symbol_exists)
  health:report(log)
  if not health:feature_ok("vitals") then
    log.warn("HP cannot be read: the combat lockout and cancel-on-damage are inactive until it can")
  end

  -- a monotonic clock in seconds: engine real time when available, else os.time()
  local clock = { t = 0, last_real = nil, last_os = os.time() }
  local function advance_clock()
    local real, os_now = pal_api.real_time(), os.time()
    local step
    if real and clock.last_real and real >= clock.last_real then
      step = real - clock.last_real
    else
      step = os_now - clock.last_os
    end
    if step < 0 or step > 3600 then step = 0 end
    clock.t = clock.t + step
    clock.last_real, clock.last_os = real, os_now
  end
  local started_os = os.time()

  local sampler = stats.new_sampler(settings.commands.stats.tps_window_seconds)

  -- eggs: hook the incubator only when the admin asked for it, once; the callback asks the live
  -- setting each time, so switching it off (or on) needs no restart
  local egg_hook = { registered = false, reported = false, warned_missing = false, failed_reported = false, next_try = 0 }
  local function sync_egg_hook()
    if egg_hook.registered or not settings.breeding.optimal_temperature then return end
    if not health:feature_ok("eggtemp") then
      if not egg_hook.warned_missing then
        egg_hook.warned_missing = true
        log.warn("breeding.optimal_temperature is on, but the game function SetTemperatureDiff was not found")
      end
      return
    end
    if clock.t < egg_hook.next_try then return end
    local ok, ids = pal_api.register_optimal_temperature(
      function() return settings.breeding.optimal_temperature end,
      function(reached, set_ok, value)
        if egg_hook.reported then return end
        egg_hook.reported = true
        if reached then
          log.info("incubator temperature: the first SetTemperatureDiff call was set to 0 (the best band)")
        else
          log.warn("incubator temperature: the hook fired but the parameter could not be set to 0 (set ok: %s, value read back: %s)",
            tostring(set_ok), tostring(value))
        end
      end)
    if ok then
      egg_hook.registered = true
      log.info("hooked %s (optimal incubator temperature)", pal_api.SYMBOLS.SET_TEMP_DIFF)
    else
      egg_hook.next_try = clock.t + 60 -- look again in a minute, and say it only once
      if not egg_hook.failed_reported then
        egg_hook.failed_reported = true
        log.error("could not hook SetTemperatureDiff: %s (trying again every minute)", tostring(ids))
      end
    end
  end

  local api = {
    send = pal_api.send,
    players = function() return pal_api.players(clock.t, 30) end,
    location = pal_api.location,
    hp = pal_api.hp,
    is_alive = pal_api.is_alive,
    is_admin = pal_api.is_admin,
    guild_bases = function(p) return pal_api.guild_bases(p, clock.t) end,
    trace = pal_api.trace,
    teleport = pal_api.teleport,
    max_players = pal_api.max_players,
    stand_offset = pal_api.stand_offset,
    rescan = pal_api.force_rescan,
    worker_capacity = pal_api.worker_capacity,
    give_item = pal_api.give_item,
    unstuck = pal_api.unstuck,
    embedded = pal_api.embedded,
    nearest_base = function(p) return pal_api.nearest_base(p, clock.t) end,
    start_raid = pal_api.start_raid,
  }

  local world = world_settings.new(
    {
      world = { read = pal_api.world_setting_read, write = pal_api.world_setting_write },
      game = { read = pal_api.game_setting_read, write = pal_api.game_setting_write },
    },
    function() return settings end, log,
    function(source) return health:feature_ok(source == "world" and "worldsettings" or "gamesetting") end)

  local backup = backup_mod.new({
    settings = function() return settings end,
    log = log,
    api = {
      world_folder = function()
        if not health:feature_ok("backup") then return nil, "the game functions for finding the world folder are missing" end
        return pal_api.world_folder()
      end,
      is_saving = pal_api.is_saving,
      file_size = pal_api.file_size,
    },
    sys = backup_mod.system(shell_mod.new()),
    stamp = function() return os.date("!%Y%m%d-%H%M%S") end, -- UTC: names must sort in time order even across a clock change
  })

  local handler = handler_mod.new({
    api = api,
    settings = function() return settings end,
    health = {
      feature_ok = function(name) return health:feature_ok(name) end,
      reason = function(name) return health:reason(name) end,
      summary = function() return health:summary() end,
    },
    prefs = {
      language = function(uid) return prefs:language(uid) end,
      set_language = function(uid, lang) return prefs:set_language(uid, lang) end,
      kit_delivered = function(uid, kit) return prefs:kit_delivered(uid, kit) end,
      kit_mark = function(uid, kit, items) return prefs:kit_mark(uid, kit, items) end,
      kit_partial = function(uid, kit) return prefs:kit_partial(uid, kit) end,
      kit_partial_set = function(uid, kit, id, n) return prefs:kit_partial_set(uid, kit, id, n) end,
      writable = function() return prefs:writable() end,
      probe = function() return prefs:probe() end,
    },
    sampler = sampler,
    world = { status = function() return world:status() end },
    backup = { status = function(now) return backup:status(now) end },
    uptime = function() return os.time() - started_os end,
    reload = function()
      local warnings = load_settings()
      prefs:load() -- an admin who fixed or removed a damaged players.json gets it read again at once
      sampler:set_window(settings.commands.stats.tps_window_seconds)
      world:recheck()
      sync_egg_hook()
      return warnings
    end,
    version = NOCTUA_VERSION,
    log = log,
  })

  -- 3. chat hook: queue only
  local PER_PLAYER_LIMIT = 8 -- queued command lines per player per tick: one flooder must not crowd out the rest
  local queue, per_player, last_drop_warn = {}, {}, nil
  local function starts_with_prefix(text)
    local first = text:match("^%s*(.)")
    if not first then return false end
    for _, p in ipairs(settings.chat.command_prefixes) do
      if p == first then return true end
    end
    return false
  end
  local function on_chat(pc, text)
    if not starts_with_prefix(text) then return end
    local key = pal_api.controller_key(pc)
    local mine = (per_player[key] or 0) + 1
    if #queue >= QUEUE_LIMIT or mine > PER_PLAYER_LIMIT then
      -- at most one warning a minute, however long a flood lasts
      local now_s = os.time()
      if last_drop_warn == nil or now_s - last_drop_warn >= 60 then
        last_drop_warn = now_s
        log.warn("command lines are being dropped (queue of %d, or more than %d from one player in a tick)",
          QUEUE_LIMIT, PER_PLAYER_LIMIT)
      end
      return
    end
    per_player[key] = mine
    -- keep memory bounded: anything longer than the limit is refused as too long anyway
    local limit = settings.chat.max_line_bytes + 1
    if #text > limit then text = text:sub(1, limit) end
    queue[#queue + 1] = { pc = pc, text = text }
  end
  local function suppress(text)
    if not settings.chat.hide_commands_experimental then return false end
    local cmd = handler_mod.parse(text, settings.chat.command_prefixes)
    return cmd ~= nil and handler_mod.COMMANDS[cmd.name] ~= nil
  end

  local hooked = false
  local function try_hook()
    if hooked or not health:feature_ok("chat") then return end
    local ok, err = pal_api.register_chat(on_chat, suppress)
    if ok then
      hooked = true
      log.info("chat hook registered on %s", pal_api.SYMBOLS.CHAT_RPC)
    else
      log.error("chat hook could not be registered: %s", tostring(err))
    end
  end
  try_hook()
  sync_egg_hook()
  if pal_api.watch_players() then
    log.debug("watching for new player states")
  end

  -- Trace self-test: a downward trace under a player who stands on the ground must
  -- hit something. If it never does, the trace settings do not match this game
  -- version and every landing search will refuse (safely) to put anyone down.
  local selftest = { done = false, tries = 0, next_at = 5 }
  local function trace_selftest(now)
    if selftest.done or now < selftest.next_at or not health:feature_ok("trace") then return end
    selftest.next_at = now + 5
    for _, p in ipairs(api.players()) do
      local loc = pal_api.location(p)
      if loc then
        selftest.tries = selftest.tries + 1
        local ok, hit = pcall(pal_api.trace, { x = loc.x, y = loc.y, z = loc.z + 50 },
          { x = loc.x, y = loc.y, z = loc.z - 600 }, { p })
        if ok and hit then
          selftest.done = true
          log.info("trace self-test: ground found %.0f cm below a player's position", loc.z - hit.location.z)
        elseif not ok then
          log.warn("trace self-test: the trace call failed: %s", tostring(hit))
        end
        break
      end
    end
    if not selftest.done and selftest.tries >= 10 then
      selftest.done = true
      log.warn("trace self-test: no ground found under players in 10 tries; /home and /tpa will refuse to land anyone "
        .. "(/tpa still lands exactly on the target). The trace object types may not match this game version.")
    end
  end

  -- Phase 3b fact-finder: once, 30 s after start, write down what the base-level data
  -- table looks like (it holds the per-level worker cap). Read-only.
  local level_probe = { done = false }
  local function probe_level_table(now)
    if level_probe.done or now < 30 then return end
    level_probe.done = true
    local ok, info, why = pcall(pal_api.probe_level_table)
    if not ok then
      log.warn("base-level table probe failed: %s", tostring(info))
    elseif info == nil then
      log.warn("base-level table probe: %s", tostring(why))
    else
      log.info("base-level table probe: %s, %d rows%s", info.name, info.rows,
        info.fields and (", fields: " .. table.concat(info.fields, ", ")) or ", field names not listable")
      for _, s in ipairs(info.samples) do
        local parts = {}
        for k, v in pairs(s.values) do parts[#parts + 1] = k .. "=" .. tostring(v) end
        table.sort(parts)
        log.info("base-level table probe: row %s: %s", s.row, #parts > 0 and table.concat(parts, ", ") or "(no known field readable)")
      end
    end
  end

  -- 4. ticker
  local retry_index = 1
  local next_health = HEALTH_RETRY_SECONDS[1]
  local function tick()
    advance_clock()
    local now = clock.t

    if not health:all_ok() and now >= next_health then
      health:run(pal_api.symbol_exists)
      health:report(log)
      try_hook()
      retry_index = math.min(retry_index + 1, #HEALTH_RETRY_SECONDS)
      next_health = now + HEALTH_RETRY_SECONDS[retry_index]
    end

    sampler:add_frame_count(now, pal_api.frame_count())
    sampler:add_delta(now, pal_api.world_delta())

    if #queue > 0 then
      local batch = queue
      queue, per_player = {}, {}
      for _, item in ipairs(batch) do
        local player = pal_api.player_from_controller(item.pc)
        if player then
          handler:handle(player, item.text, now)
        end
      end
    end

    handler:tick(now)
    trace_selftest(now)
    world:tick(now)
    sync_egg_hook()
    local ok_backup, err_backup = pcall(backup.tick, backup, now)
    if not ok_backup then log.error("backup: %s", tostring(err_backup)) end
    if prefs.locked and now >= (prefs_retry_at or 0) then
      prefs_retry_at = now + 300 -- the saved-choices file could not be read: look again every 5 minutes
      if prefs:load() then log.info("the saved player choices can be read again") end
    end
    if prefs.dirty and now >= (prefs_flush_at or 0) then
      prefs_flush_at = now + 60
      if prefs:flush() then log.info("the saved player choices were written after all") end
    end
    probe_level_table(now)
  end

  -- A tick that keeps failing must not write four lines a second to UE4SS.log.
  local tick_errors = { count = 0, last_report = nil }
  local function guarded_tick()
    local ok, err = pcall(tick)
    if not ok then
      tick_errors.count = tick_errors.count + 1
      if tick_errors.last_report == nil or clock.t - tick_errors.last_report >= 60 then
        log.error("tick failed (%d time(s) since the last report): %s", tick_errors.count, tostring(err))
        tick_errors.count = 0
        tick_errors.last_report = clock.t
      end
    end
  end

  local method = pal_api.start_ticker(TICK_MS, guarded_tick)
  log.info("ticker started every %d ms (%s)", TICK_MS, method)
  local sum = health:summary()
  local on = {}
  for _, f in ipairs(sum.features) do if f.ok then on[#on + 1] = f.name end end
  log.info("Noctua %s ready: %d/%d features on (%s)", NOCTUA_VERSION, #on, #sum.features, table.concat(on, ", "))
end

local ok, err = pcall(boot)
if not ok then
  boot_print("[ERROR] boot failed, Noctua is not running (the vanilla game is unaffected): " .. tostring(err))
end
