-- Noctua: scheduled backups of the world's save folder (NOCTUA_INIT.md module E).
--
-- What it does, in order, every backup.interval_minutes:
--   1. waits until no game save is running and Level.sav / LevelMeta.sav keep the same size for
--      backup.settle_seconds (a copy taken while the game writes can look fine and refuse to load);
--   2. writes a small job script (a NEW file name for every job) and starts it as a SEPARATE
--      process, so a copy of hundreds of megabytes never stops the game thread. The script only
--      copies the folder to "noctua-backup-<UTC stamp>.partial" and writes "ok" or "fail" to that
--      job's own result file, which this module polls;
--   3. checks the .partial copy: same size as the original was before AND after the copy. If the
--      original changed while it was copied, the copy is discarded. It never had a finished name,
--      so it can never be mistaken for a good backup, even if removing it fails;
--   4. only a verified copy is renamed (by Lua, at once) to "noctua-backup-<UTC stamp>";
--   5. then the oldest finished backups beyond backup.keep, and leftovers of interrupted copies,
--      are removed with a second job script. Only folders Noctua made are ever removed
--      (backup_plan.lua), and the backup just made is never among them.
--
-- A job that never answers (timeout) or is cut off (backups switched off) is ABANDONED: no new
-- job starts until its result file shows up, so two jobs never run over each other.
--
-- The game keeps its own rolling backups too (bIsUseBackupSaveData); this is an extra copy in a
-- folder of the admin's choosing. Every copy is complete and independent: the spec's
-- "differential" wording is not implemented, because a broken link in a chain of partial copies
-- is worse than the disk space.
--
-- Engine-free: the game and the operating system come in through `deps`.

local plan = require("noctua.backup_plan")

local backup = {}

backup.FIRST_DELAY = 120          -- seconds after start before the first backup
backup.RETRY_DELAY = 300          -- seconds before trying again after a configuration problem
backup.FAILURE_DELAY = 600        -- seconds before trying again after a failed backup
backup.SETTLE_TIMEOUT = 1800      -- give up waiting for a quiet moment after this long
backup.JOB_TIMEOUT = 3600         -- a copy that takes longer than this is abandoned (and reported)
backup.CLEANUP_TIMEOUT = 600
backup.ABANDON_LIMIT = 86400      -- after a day an abandoned job is assumed dead and no longer blocks
backup.KEY_FILES = { "Level.sav", "LevelMeta.sav" }

---------------------------------------------------------------------------
-- job scripts (pure text; tests read them, the real system runs them)
---------------------------------------------------------------------------

local function native(windows, path)
  if windows then return (path:gsub("/", "\\")) end
  return path
end

--- The script that copies `src` into `partial` and writes the result. It does not rename:
-- a copy has no finished name until Noctua has checked it.
-- copy_tool (Windows only): "robocopy" or "xcopy" (Wine has no robocopy).
function backup.copy_script(windows, copy_tool, src, partial, result)
  if windows then
    local lines = { "@echo off" }
    if copy_tool == "xcopy" then
      lines[#lines + 1] = string.format('xcopy "%s\\" "%s\\" /E /I /Y /Q /H >NUL 2>&1', native(true, src), native(true, partial))
      lines[#lines + 1] = "if errorlevel 1 goto fail"
    else
      lines[#lines + 1] = string.format('robocopy "%s" "%s" /E /R:1 /W:1 /NFL /NDL /NP /NJH /NJS >NUL 2>&1',
        native(true, src), native(true, partial))
      lines[#lines + 1] = "if errorlevel 8 goto fail"
    end
    lines[#lines + 1] = string.format('echo ok> "%s"', native(true, result))
    lines[#lines + 1] = "exit /b 0"
    lines[#lines + 1] = ":fail"
    lines[#lines + 1] = string.format('echo fail> "%s"', native(true, result))
    lines[#lines + 1] = "exit /b 1"
    return table.concat(lines, "\r\n") .. "\r\n"
  end
  return table.concat({
    "#!/bin/sh",
    string.format('mkdir -p "%s" && cp -a "%s/." "%s/" && echo ok > "%s" || echo fail > "%s"',
      partial, src, partial, result, result),
    "",
  }, "\n")
end

--- The script that removes the given folders (already checked by backup_plan) and writes "ok".
function backup.cleanup_script(windows, dirs, result)
  if windows then
    local lines = { "@echo off" }
    for _, dir in ipairs(dirs) do
      lines[#lines + 1] = string.format('rmdir /s /q "%s" >NUL 2>&1', native(true, dir))
    end
    lines[#lines + 1] = string.format('echo ok> "%s"', native(true, result))
    return table.concat(lines, "\r\n") .. "\r\n"
  end
  local lines = { "#!/bin/sh" }
  for _, dir in ipairs(dirs) do lines[#lines + 1] = string.format('rm -rf "%s"', dir) end
  lines[#lines + 1] = string.format('echo ok > "%s"', result)
  lines[#lines + 1] = ""
  return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- the module
---------------------------------------------------------------------------

local B = {}
B.__index = B

--- deps = {
---   settings = fn -> settings,  log = log,
---   api = { world_folder() -> path | nil, reason ; is_saving() -> bool | nil ; file_size(path) -> n | nil },
---   sys = { windows = bool,
---           write_file(path, text) -> ok, err ; read_file(path) -> text | nil ; remove_file(path) ;
---           launch(script_path) -> ok, note ; list_dirs(root) -> names | nil, why ; mkdir(dir) -> ok, why ;
---           rename(from, to) -> ok, why ; copy_tool() -> "robocopy" | "xcopy" },
---   stamp = fn -> "YYYYMMDD-HHMMSS" (UTC),
--- }
function backup.new(deps)
  return setmetatable({
    d = deps, phase = "idle", next_at = nil, job = nil, last_ok = nil, last_error = nil,
    warned = {}, started = 0, ok_count = 0, discarded = 0, seq = 0, abandoned = nil,
  }, B)
end

function B:_warn_once(key, fmt, ...)
  if self.warned[key] then return end
  self.warned[key] = true
  self.d.log.warn(fmt, ...)
end

function B:_error(text)
  self.last_error = text
  self.d.log.warn("backup: %s", text)
end

local function sizes_of(api, folder)
  local out = {}
  for _, name in ipairs(backup.KEY_FILES) do out[name] = api.file_size(folder .. "/" .. name) end
  return out
end

local function same_sizes(a, b)
  for _, name in ipairs(backup.KEY_FILES) do
    if a[name] ~= b[name] then return false end
  end
  return true
end

--- A fresh script and result path for one job: no two jobs ever share a file.
function B:_paths(root, kind)
  self.seq = self.seq + 1
  local tag = string.format("noctua-job-%s-%d-%s", self.job and self.job.stamp or "x", self.seq, kind)
  local ext = self.d.sys.windows and ".cmd" or ".sh"
  return root .. "/" .. tag .. ext, root .. "/" .. tag .. ".result"
end

function B:_drop_files(...)
  for _, path in ipairs({ ... }) do
    if path then self.d.sys.remove_file(path) end
  end
end

--- Gives up on the current job WITHOUT pretending it is over: if it was started, it may still be
-- running, so nothing new starts until it has written its result.
function B:_abandon(now, why)
  local job = self.job
  if job and job.launched and job.result and self.phase == "copying" then
    self.abandoned = { result = job.result, script = job.script, since = now }
  end
  self.job = nil
  self.phase = "idle"
  self.last_error = why
  self.d.log.warn("backup: %s", why)
end

--- Is an earlier job still possibly running?
function B:_blocked_by_abandoned(now)
  local a = self.abandoned
  if not a then return false end
  if self.d.sys.read_file(a.result) then
    self.d.log.info("backup: the abandoned earlier job has finished; its leftover .partial folder is removed at the next cleanup")
    self:_drop_files(a.result, a.script)
    self.abandoned = nil
    return false
  end
  if now - a.since > backup.ABANDON_LIMIT then
    self.d.log.warn("backup: the earlier job never answered in a day; assuming it is dead")
    self.abandoned = nil
    return false
  end
  return true
end

--- Checks the settings and starts waiting for a quiet moment. Returns true when a job was begun.
function B:_begin(now)
  local st = self.d.settings().backup
  if self:_blocked_by_abandoned(now) then
    self:_warn_once("blocked", "backup: not starting a new backup while the earlier job has not answered yet")
    return false
  end
  local root_ok, root = plan.safe_path(st.folder)
  if st.folder == "" then
    self:_warn_once("nofolder", "backup.enabled is true but backup.folder is empty: no backup can be made")
    return false
  elseif not root_ok then
    self:_warn_once("badfolder", "backup.folder %q cannot be used: %s", st.folder, root)
    return false
  end
  local world, why
  if st.world_folder ~= "" then
    local ok, p = plan.safe_path(st.world_folder)
    if not ok then
      self:_warn_once("badworld", "backup.world_folder %q cannot be used: %s", st.world_folder, p)
      return false
    end
    world = p
  else
    world, why = self.d.api.world_folder()
    if not world then
      self:_warn_once("noworld:" .. tostring(why), "backup: the world's save folder is not known yet (%s)", tostring(why))
      return false
    end
    local ok_w, w = plan.safe_path(world)
    if not ok_w then
      self:_warn_once("weirdworld", "backup: the world folder the game reported cannot be used: %s (%s)", tostring(world), w)
      return false
    end
    world = w
  end
  if plan.overlaps(root, world) then
    self:_warn_once("overlap", "backup.folder must not be inside the world's own folder or contain it (%s and %s)", root, world)
    return false
  end
  local first = sizes_of(self.d.api, world)
  if first["Level.sav"] == nil then
    self:_warn_once("nolevel", "backup: Level.sav was not found in %s", world)
    return false
  end
  self.job = { root = root, world = world, since = now, began = now, sizes = first }
  self.phase = "settling"
  return true
end

function B:_launch(now)
  local d, job = self.d, self.job
  local ok_mk, why_mk = d.sys.mkdir(job.root)
  if not ok_mk then return false, "could not create the backup folder: " .. tostring(why_mk) end
  local stamp = d.stamp()
  if not plan.is_stamp(stamp) then return false, "the clock gave an unusable time stamp" end
  local leaf = plan.name(stamp)
  local ok_f, final = plan.child(job.root, leaf)
  local ok_p, partial = plan.child(job.root, leaf .. ".partial")
  if not (ok_f and ok_p) then return false, "cannot build the backup folder name" end
  job.stamp, job.leaf, job.final, job.partial = stamp, leaf, final, partial
  job.script, job.result = self:_paths(job.root, "c")
  d.sys.remove_file(job.result)
  local text = backup.copy_script(d.sys.windows, d.sys.windows and d.sys.copy_tool() or nil, job.world, partial, job.result)
  local ok_w, why_w = d.sys.write_file(job.script, text)
  if not ok_w then return false, "could not write the job script: " .. tostring(why_w) end
  local ok_l, why_l = d.sys.launch(job.script)
  if not ok_l then
    self:_drop_files(job.script)
    return false, "could not start the job: " .. tostring(why_l)
  end
  job.launched = now
  job.sizes_before = sizes_of(d.api, job.world)
  self.phase = "copying"
  self.started = self.started + 1
  d.log.info("backup: copying %s to %s (started outside the game's thread)", job.world, partial)
  return true
end

function B:_finish(now, ok, text)
  local st = self.d.settings().backup
  local job = self.job
  local began = job and job.began or now
  if job then self:_drop_files(job.script, job.result, job.cleanup_script, job.cleanup_result) end
  self.job = nil
  self.phase = "idle"
  if ok then
    self.next_at = began + st.interval_minutes * 60
  else
    self:_error(text)
    self.next_at = now + backup.FAILURE_DELAY
  end
end

--- Starts a script that removes `dirs` (each already checked). Returns true when it was started.
function B:_start_removal(now, dirs, kind)
  local d, job = self.d, self.job
  local script, result = self:_paths(job.root, kind)
  d.sys.remove_file(result)
  if not d.sys.write_file(script, backup.cleanup_script(d.sys.windows, dirs, result)) then return false end
  if not d.sys.launch(script) then
    self:_drop_files(script)
    return false
  end
  job.cleanup_script, job.cleanup_result, job.cleanup_started = script, result, now
  return true
end

--- Removes what retention says (after the new backup was verified). Returns true when a job started.
function B:_cleanup(now)
  local d, job = self.d, self.job
  local names, why = d.sys.list_dirs(job.root)
  if not names then
    d.log.warn("backup: could not list %s to remove old backups (%s); nothing is removed", job.root, tostring(why))
    return false
  end
  local st = self.d.settings().backup
  local decision = plan.retention(names, st.keep)
  local dirs = {}
  local function add(name)
    if name == job.leaf then return end -- never the backup just made
    local ok, path = plan.child(job.root, name)
    if ok and plan.is_inside(job.root, path) then dirs[#dirs + 1] = path end
  end
  for _, name in ipairs(decision.delete) do add(name) end
  for _, name in ipairs(decision.partial) do add(name) end
  if #dirs == 0 then return false end
  if not self:_start_removal(now, dirs, "x") then return false end
  self.phase = "cleaning"
  d.log.info("backup: removing %d old backup folder(s) beyond backup.keep = %d", #dirs, st.keep)
  return true
end

--- Runs on the game thread from the ticker; does almost nothing unless something is due.
function B:tick(now)
  local st = self.d.settings().backup
  -- the small removal job of a discarded copy: tidy its files once it has answered (or a day has passed)
  local o = self.orphans
  if o and (self.d.sys.read_file(o.result) or now - o.since > backup.ABANDON_LIMIT) then
    self:_drop_files(o.script, o.result)
    self.orphans = nil
  end
  if not st.enabled then
    -- switched off in the middle of a job: cut it off cleanly, so that switching it on again later
    -- cannot judge an old copy against the world as it is by then
    if self.phase ~= "idle" then self:_abandon(now, "backups were switched off in the middle of a backup") end
    self.next_at = nil
    return
  end
  if self.next_at == nil then self.next_at = now + backup.FIRST_DELAY end

  if self.phase == "idle" then
    if now < self.next_at then return end
    if not self:_begin(now) then self.next_at = now + backup.RETRY_DELAY end

  elseif self.phase == "settling" then
    local job = self.job
    if now - job.began > backup.SETTLE_TIMEOUT then
      return self:_finish(now, false, "the save files never became quiet (a game save kept running or the files kept changing)")
    end
    local saving = self.d.api.is_saving()
    local sizes = sizes_of(self.d.api, job.world)
    if saving == true or not same_sizes(sizes, job.sizes) or sizes["Level.sav"] == nil then
      job.since, job.sizes = now, sizes
      return
    end
    if now - job.since < st.settle_seconds then return end
    local ok, why = self:_launch(now)
    if not ok then self:_finish(now, false, why) end

  elseif self.phase == "copying" then
    local job = self.job
    local text = self.d.sys.read_file(job.result)
    local verdict = text and text:match("^%s*(%a+)")
    if verdict == "ok" then
      local after = sizes_of(self.d.api, job.world)
      local copy = sizes_of(self.d.api, job.partial)
      local good = copy["Level.sav"] ~= nil and same_sizes(job.sizes_before, after) and same_sizes(copy, job.sizes_before)
      if good then
        -- only now does the copy get a finished name
        local ok_rn, why_rn = self.d.sys.rename(job.partial, job.final)
        if not ok_rn then
          return self:_finish(now, false, string.format("the copy is fine but could not be renamed to %s (%s); it stays a .partial folder",
            job.leaf, tostring(why_rn)))
        end
        self.ok_count = self.ok_count + 1
        self.last_ok = { name = job.leaf, at = now, bytes = copy["Level.sav"] }
        self.last_error = nil
        self.d.log.info("backup: %s is complete and verified (Level.sav %d bytes)", job.leaf, copy["Level.sav"])
        if self:_cleanup(now) then return end
        return self:_finish(now, true)
      end
      -- the world changed while it was being copied (or the copy is short): it may be torn.
      -- It still has the .partial name, so it is never counted, whatever happens to the removal.
      self.discarded = self.discarded + 1
      local removed = plan.is_inside(job.root, job.partial) and self:_start_removal(now, { job.partial }, "d")
      local msg = string.format(
        "%s was discarded: the copy's size (%s) did not match the world's before (%s) and after (%s) the copy%s",
        job.leaf, tostring(copy["Level.sav"]), tostring(job.sizes_before["Level.sav"]), tostring(after["Level.sav"]),
        removed and "" or " (its .partial folder could not be removed now; the next cleanup does it)")
      -- the removal job is fire-and-forget; drop the copy job's own files, keep the removal's until a later finish
      local removal_script, removal_result = job.cleanup_script, job.cleanup_result
      job.cleanup_script, job.cleanup_result = nil, nil
      self:_finish(now, false, msg)
      if removal_script then self.orphans = { script = removal_script, result = removal_result, since = now } end
      return
    elseif verdict == "fail" then
      return self:_finish(now, false, "the copy job reported a failure (" .. job.leaf .. ".partial is removed at the next cleanup)")
    elseif now - job.launched > backup.JOB_TIMEOUT then
      local why = "the copy job did not finish within " .. backup.JOB_TIMEOUT .. " s and is abandoned"
      self.next_at = now + backup.FAILURE_DELAY
      return self:_abandon(now, why)
    end

  elseif self.phase == "cleaning" then
    local job = self.job
    local text = self.d.sys.read_file(job.cleanup_result)
    if text and text:match("^%s*ok") then
      self.d.log.info("backup: old backups removed")
      return self:_finish(now, true)
    elseif now - job.cleanup_started > backup.CLEANUP_TIMEOUT then
      self.d.log.warn("backup: the cleanup job did not report back within %d s; carrying on", backup.CLEANUP_TIMEOUT)
      return self:_finish(now, true)
    end
  end

end

--- For /noctua backup.
function B:status(now)
  local st = self.d.settings().backup
  return {
    enabled = st.enabled, phase = self.phase, folder = st.folder, keep = st.keep,
    last_ok = self.last_ok, last_error = self.last_error, ok_count = self.ok_count, discarded = self.discarded,
    seconds_to_next = (self.next_at and now) and math.max(0, self.next_at - now) or nil,
  }
end

--- The real operating-system side, built on noctua/shell.lua and Lua's io library.
function backup.system(shell)
  local sys = { windows = shell.windows }
  function sys.write_file(path, text)
    local h, err = io.open(path, "wb")
    if not h then return false, err end
    local ok, werr = h:write(text)
    h:close()
    if not ok then return false, werr end
    return true
  end
  function sys.read_file(path)
    local h = io.open(path, "rb")
    if not h then return nil end
    local text = h:read("a")
    h:close()
    return text
  end
  function sys.remove_file(path) os.remove(path) end
  function sys.rename(from, to)
    local ok, err = os.rename(from, to)
    if ok then return true end
    return false, err
  end
  function sys.mkdir(dir) return shell:mkdir(dir) end
  function sys.list_dirs(root) return shell:list(root) end
  function sys.launch(script)
    local ok_s, s = plan.safe_path(script)
    if not ok_s then return false, s end
    local cmd
    if shell.windows then
      cmd = string.format('start "" /B "%s"', native(true, s))
    else
      cmd = string.format('sh "%s" >/dev/null 2>&1 &', s)
    end
    local ok, code, note = shell.run.execute(cmd)
    if ok then return true end
    -- `start` and a backgrounded `sh` return at once; a non-zero code here means it did not launch
    return false, code and ("exit code " .. code) or tostring(note)
  end
  local tool
  function sys.copy_tool()
    if tool then return tool end
    local ok = shell.run.execute("where robocopy >NUL 2>&1")
    tool = ok and "robocopy" or "xcopy"
    return tool
  end
  return sys
end

return backup
