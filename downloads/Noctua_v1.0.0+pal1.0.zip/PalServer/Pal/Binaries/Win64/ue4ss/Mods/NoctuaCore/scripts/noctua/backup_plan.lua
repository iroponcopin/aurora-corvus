-- Noctua: the pure rules of the backup feature (NOCTUA_INIT.md module E, NoctuaGuardianCore).
-- No file or shell access here: names in, decisions out, so every rule can be tested.
--
-- Safety rules this file enforces:
--   * Noctua only ever removes folders that IT created: "noctua-backup-YYYYMMDD-HHMMSS",
--     or the unfinished "....partial" of an interrupted copy. Any other name, in any
--     folder, is never touched.
--   * The newest finished backup is never removed, whatever `keep` says.
--   * A path that goes into a shell command must be absolute, free of shell
--     metacharacters, and free of ".." segments.

local plan = {}

plan.PREFIX = "noctua-backup-"

function plan.name(stamp)
  return plan.PREFIX .. stamp
end

function plan.is_stamp(stamp)
  return type(stamp) == "string" and stamp:match("^%d%d%d%d%d%d%d%d%-%d%d%d%d%d%d$") ~= nil
end

--- A finished backup Noctua made.
function plan.is_ours(name)
  return type(name) == "string" and name:match("^noctua%-backup%-%d%d%d%d%d%d%d%d%-%d%d%d%d%d%d$") ~= nil
end

--- The unfinished copy of an interrupted backup.
function plan.is_partial(name)
  return type(name) == "string" and name:match("^noctua%-backup%-%d%d%d%d%d%d%d%d%-%d%d%d%d%d%d%.partial$") ~= nil
end

--- What to do with the folders found in the backup folder.
-- @return { keep = {...}, delete = {...}, partial = {...}, foreign = n }
--   delete: finished backups beyond `keep`, oldest first (never the newest);
--   partial: leftovers of interrupted copies (safe to remove: they are unfinished by definition);
--   foreign: how many other entries were seen and left alone.
function plan.retention(names, keep)
  local ours, partial, foreign = {}, {}, 0
  for _, name in ipairs(names) do
    if plan.is_ours(name) then
      ours[#ours + 1] = name
    elseif plan.is_partial(name) then
      partial[#partial + 1] = name
    else
      foreign = foreign + 1
    end
  end
  table.sort(ours) -- the stamp sorts chronologically
  table.sort(partial)
  keep = math.max(1, math.floor(keep or 1))
  local result = { keep = {}, delete = {}, partial = partial, foreign = foreign }
  local excess = #ours - keep
  for i, name in ipairs(ours) do
    if i <= excess then
      result.delete[#result.delete + 1] = name
    else
      result.keep[#result.keep + 1] = name
    end
  end
  return result
end

-- Every path reaches a command or a script inside double quotes, where these are the characters that
-- still do something: a quote, cmd's %variable% and !delayed!, sh's $ and backtick, and the redirection
-- and separator characters, which are refused as well to stay far from any doubt. Parentheses,
-- brackets, braces, apostrophes, ~ and # are harmless there ("C:/Program Files (x86)/...").
local FORBIDDEN = '[%c&|<>^%%!"`;$*?]'

--- May this path be put inside a shell command?
-- @return true, normalised_path  or  false, reason
function plan.safe_path(path)
  if type(path) ~= "string" or path == "" then return false, "the path is empty" end
  if #path > 240 then return false, "the path is longer than 240 characters" end
  local bad = path:match(FORBIDDEN)
  if bad then
    return false, "the path contains a character that is not allowed in a command: " .. string.format("%q", bad)
  end
  if utf8.len(path) == nil then return false, "the path is not valid UTF-8" end
  local p = path:gsub("\\", "/")
  if p:sub(1, 2) == "//" then return false, "network (UNC) paths are not supported" end
  p = p:gsub("/+", "/") -- "D://world" is "D:/world"
  local absolute = p:match("^%a:/") or p:sub(1, 1) == "/"
  if not absolute then return false, "the path is not absolute (start it with a drive letter such as D:/ or with /)" end
  for segment in p:gmatch("[^/]+") do
    if segment == ".." then return false, "the path contains .." end
  end
  p = p:gsub("/+$", "")
  if p == "" or p:match("^%a:$") then return false, "the path is a drive or root, not a folder" end
  return true, p
end

--- root/name, with every part checked. `name` must be one of Noctua's own folder names.
function plan.child(root, name)
  local ok, p = plan.safe_path(root)
  if not ok then return false, p end
  if not (plan.is_ours(name) or plan.is_partial(name)) then
    return false, "not a Noctua backup folder name: " .. tostring(name)
  end
  return true, p .. "/" .. name
end

--- Is `child` exactly one of Noctua's folders directly inside `root`?
function plan.is_inside(root, child)
  local ok_r, r = plan.safe_path(root)
  local ok_c, c = plan.safe_path(child)
  if not (ok_r and ok_c) then return false end
  local prefix = r .. "/"
  if c:sub(1, #prefix) ~= prefix then return false end
  local name = c:sub(#prefix + 1)
  if name:find("/", 1, true) then return false end
  return plan.is_ours(name) or plan.is_partial(name)
end

--- The backup folder must not sit inside the world folder (it would copy itself), nor contain it.
function plan.overlaps(a, b)
  local ok_a, pa = plan.safe_path(a)
  local ok_b, pb = plan.safe_path(b)
  if not (ok_a and ok_b) then return false end
  pa, pb = pa:lower() .. "/", pb:lower() .. "/"
  return pa:sub(1, #pb) == pb or pb:sub(1, #pa) == pa
end

return plan
