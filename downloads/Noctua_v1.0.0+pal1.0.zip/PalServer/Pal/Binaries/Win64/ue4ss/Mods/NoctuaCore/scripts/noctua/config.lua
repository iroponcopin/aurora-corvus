-- Noctua: the admin's settings file, config/noctua_settings.json.
--
-- Rules (Claude.md line 5):
--   * a missing file is written with the defaults below;
--   * an existing file is never rewritten, so an admin's edits always survive;
--   * a bad or missing value falls back to its default with one log line that
--     names the key, the value and the reason; the server never stops for it;
--   * every key here is read by code. A key that nothing reads does not belong here.
--
-- Keys are frozen once shipped (Claude.md line 6). Add new keys; never rename them.

local json = require("noctua.json")
local backup_plan = require("noctua.backup_plan")

local config = {}

config.SCHEMA_VERSION = 1
config.FILE_NAME = "noctua_settings.json"

-- Every setting, in the order the default file lists them.
-- type: boolean | integer | number | enum | char_list | item_list | number_list | path
config.SCHEMA = {
  { key = "schema_version", type = "integer", min = 1, max = 1000, default = 1,
    doc = "Format version of this file. Leave it as it is." },
  { key = "language", type = "enum", values = { "ja", "en" }, default = "ja",
    doc = "Language of messages for players who have not chosen one with /lang." },
  { key = "log_level", type = "enum", values = { "debug", "info", "warn", "error" }, default = "info",
    doc = "How much Noctua writes to UE4SS.log." },

  { key = "chat.command_prefixes", type = "char_list", values = { "/", "!", "." }, min_items = 1, max_items = 3,
    default = { "/", "!" },
    doc = "Characters that start a Noctua command. Lines starting with anything else are ordinary chat." },
  { key = "chat.max_line_bytes", type = "integer", min = 32, max = 1000, default = 200,
    doc = "Longer command lines are refused (UTF-8 bytes)." },
  { key = "chat.hide_commands_experimental", type = "boolean", default = false,
    doc = "EXPERIMENTAL, not yet tried on a live server: blank Noctua command lines before the game handles them, "
      .. "so a / command no longer also gets \"Unknown command.\" and a ! command is not shown to everyone." },
  { key = "chat.rate_limit_burst", type = "integer", min = 1, max = 50, default = 5,
    doc = "Commands a player may send back to back before being slowed down." },
  { key = "chat.rate_limit_refill_seconds", type = "number", min = 0.1, max = 60, default = 2.0,
    doc = "Seconds to earn back one command after the burst is used up." },

  { key = "commands.home.enabled", type = "boolean", default = true,
    doc = "Allow /home." },
  { key = "commands.home.cooldown_seconds", type = "integer", min = 0, max = 86400, default = 300,
    doc = "Wait after a successful /home before it can be used again." },
  { key = "commands.home.warmup_seconds", type = "integer", min = 0, max = 60, default = 5,
    doc = "Stand still this long before /home teleports (0 = at once)." },
  { key = "commands.home.combat_lockout_seconds", type = "integer", min = 0, max = 600, default = 15,
    doc = "/home is refused for this long after the player last lost HP." },

  { key = "commands.tpa.enabled", type = "boolean", default = true,
    doc = "Allow /tpa, /tpaccept, /tpdeny and /tpcancel." },
  { key = "commands.tpa.request_timeout_seconds", type = "integer", min = 10, max = 600, default = 60,
    doc = "A request not accepted within this time expires." },
  { key = "commands.tpa.cooldown_seconds", type = "integer", min = 0, max = 86400, default = 120,
    doc = "Wait after a successful /tpa teleport before the requester can teleport again." },
  { key = "commands.tpa.warmup_seconds", type = "integer", min = 0, max = 60, default = 3,
    doc = "The requester stands still this long after acceptance (0 = at once)." },
  { key = "commands.tpa.combat_lockout_seconds", type = "integer", min = 0, max = 600, default = 15,
    doc = "A request cannot be sent or completed for this long after the requester last lost HP." },
  { key = "commands.tpa.max_incoming", type = "integer", min = 1, max = 20, default = 5,
    doc = "Pending requests one player can hold at a time." },

  { key = "commands.stats.enabled", type = "boolean", default = true,
    doc = "Allow /stats." },
  { key = "commands.stats.cooldown_seconds", type = "integer", min = 0, max = 3600, default = 5,
    doc = "Wait between two /stats from the same player." },
  { key = "commands.stats.tps_window_seconds", type = "integer", min = 5, max = 600, default = 60,
    doc = "TPS shown by /stats is the average over this many seconds." },

  { key = "commands.kit.enabled", type = "boolean", default = false,
    doc = "Allow /kit starter (hands the items below to a player once). Off by default: it gives out items." },
  { key = "commands.kit.starter_items", type = "item_list", max_items = 20,
    default = { "PalSphere:10", "Pickaxe_Tier_00:1", "Axe_Tier_00:1", "Torch:1", "Baked_Berries:10" },
    doc = "What /kit starter gives, as \"ItemId:count\". An id the game does not know is skipped and reported to the player." },

  { key = "commands.unstuck.enabled", type = "boolean", default = true,
    doc = "Allow /unstuck, which asks the game to move a stuck player to its nearest safe point." },
  { key = "commands.unstuck.cooldown_seconds", type = "integer", min = 0, max = 86400, default = 300,
    doc = "Wait after /unstuck before it can be used again." },
  { key = "commands.unstuck.combat_lockout_seconds", type = "integer", min = 0, max = 600, default = 15,
    doc = "/unstuck is refused for this long after the player last lost HP." },

  { key = "commands.lang.enabled", type = "boolean", default = true,
    doc = "Allow /lang (each player's language choice is remembered)." },

  { key = "teleport.cancel_move_distance_cm", type = "integer", min = 0, max = 10000, default = 150,
    doc = "Moving farther than this during a warmup cancels it (0 = moving never cancels)." },
  { key = "teleport.cancel_on_damage", type = "boolean", default = true,
    doc = "Losing HP during a warmup cancels it." },
  { key = "teleport.landing_search_radius_cm", type = "integer", min = 100, max = 3000, default = 400,
    doc = "How far around the destination Noctua looks for a safe place to stand." },
  { key = "teleport.headroom_cm", type = "integer", min = 100, max = 1000, default = 220,
    doc = "Free height required above the landing point." },

  { key = "base.worker_max", type = "integer", min = 0, max = 50, default = 0,
    doc = "Worker Pals per base. 0 = leave the game's own setting alone. Above 30 the game's base-level table "
      .. "also limits it; see the setup guide." },
  { key = "base.disable_decay", type = "boolean", default = false,
    doc = "true stops buildings outside a base from decaying (sets the game's decay rate to 0)." },
  { key = "base.reassert_seconds", type = "integer", min = 5, max = 600, default = 30,
    doc = "How often Noctua checks that the game still uses the values above, and writes them again if not." },

  { key = "breeding.egg_hatch_enabled", type = "boolean", default = false,
    doc = "true lets Noctua set the game's egg hatching time (below). Off by default." },
  { key = "breeding.egg_hatch_hours", type = "number", min = 0, max = 240, default = 1.0,
    doc = "Hours the game needs to hatch the biggest egg (smaller eggs are faster). 0 = at once. Used only when egg_hatch_enabled is true." },
  { key = "breeding.optimal_temperature", type = "boolean", default = false,
    doc = "true makes every incubator count as being at the best temperature (the game's fastest hatching speed). Off by default." },
  { key = "breeding.passive_inherit_weights", type = "number_list", length = 4, min = 0, max = 100, default = {},
    doc = "EXPERIMENTAL. Weights for a child inheriting 1, 2, 3 or 4 of its parents' passive skills, e.g. [0, 0, 0, 1] to always try for 4. [] leaves the game's own weights." },

  { key = "encounter.rare_pal_probability", type = "number", min = -1, max = 1000, default = -1,
    doc = "The game's chance of a wild Pal being a Lucky (rare) one. -1 = leave the game's own value. The unit is the game's own (see the value logged at start-up); it applies to Pals that spawn afterwards." },
  { key = "encounter.predator_probability", type = "number", min = -1, max = 1000, default = -1,
    doc = "The game's chance of a wild Pal being a rampaging Predator Pal (bigger, red aura). -1 = leave the game's own value. Needs EnablePredatorBossPal=True in the game's settings." },
  { key = "raid.probability", type = "number", min = -1, max = 1000, default = -1,
    doc = "The game's chance that a raid on a base starts when it checks. -1 = leave the game's own value (the unit is the game's; see the value logged at start-up). Needs bEnableInvaderEnemy=True in the game's settings." },
  { key = "raid.judgment_interval_minutes", type = "integer", min = -1, max = 1440, default = -1,
    doc = "Minutes between the game's checks whether a raid starts. -1 = leave the game's own value." },
  { key = "raid.cooldown_min_minutes", type = "integer", min = -1, max = 10080, default = -1,
    doc = "Shortest wait after a raid before the next one may start. -1 = leave the game's own value. Must not exceed raid.cooldown_max_minutes." },
  { key = "raid.cooldown_max_minutes", type = "integer", min = -1, max = 10080, default = -1,
    doc = "Longest wait after a raid before the next one may start. -1 = leave the game's own value." },

  { key = "guardian.autosave_minutes", type = "integer", min = 0, max = 120, default = 0,
    doc = "Minutes between the game's own automatic saves. 0 = leave the game's setting alone (the game default is 30 seconds)." },
  { key = "guardian.unstuck_auto", type = "enum", values = { "off", "log", "rescue" }, default = "off",
    doc = "Look for players embedded in the terrain: off, log (only write it to UE4SS.log) or rescue (also move them). Try log first." },
  { key = "guardian.unstuck_confirm_checks", type = "integer", min = 2, max = 20, default = 3,
    doc = "How many checks in a row (5 s apart) must find a player embedded before that player is rescued." },
  { key = "guardian.unstuck_max_per_hour", type = "integer", min = 1, max = 20, default = 4,
    doc = "Automatic rescues per player per hour at most, so a wrong detection can never move someone in a loop." },

  { key = "backup.enabled", type = "boolean", default = false,
    doc = "true copies the world's save folder into backup.folder on a schedule. Off by default; needs backup.folder." },
  { key = "backup.folder", type = "path", default = "",
    doc = "Where backups go: an absolute path such as D:/PalBackups (not inside the world's own folder). Noctua only ever deletes folders it made there." },
  { key = "backup.world_folder", type = "path", default = "",
    doc = "The world's save folder if Noctua cannot find it itself (Pal/Saved/SaveGames/0/<world>); empty = find it automatically." },
  { key = "backup.interval_minutes", type = "integer", min = 5, max = 1440, default = 60,
    doc = "Minutes between backups." },
  { key = "backup.keep", type = "integer", min = 1, max = 500, default = 24,
    doc = "How many of Noctua's backups to keep. Older ones are deleted only after a newer one was verified." },
  { key = "backup.settle_seconds", type = "integer", min = 5, max = 300, default = 15,
    doc = "The save files must keep the same size for this long, and no game save may be running, before a copy starts." },

  { key = "admin.reload_enabled", type = "boolean", default = true,
    doc = "Allow admins to reload this file in game with /noctua reload." },
}

-- A list-valued default must be written as a JSON list even when it is empty ([] not {}).
for _, entry in ipairs(config.SCHEMA) do
  if type(entry.type) == "string" and entry.type:match("_list$") then
    setmetatable(entry.default, json.array_mt)
  end
end

local by_key = {}
local group_keys = {} -- "chat", "commands", "commands.home", ...
for _, entry in ipairs(config.SCHEMA) do
  by_key[entry.key] = entry
  local prefix = entry.key:match("^(.*)%.[^%.]+$")
  while prefix do
    group_keys[prefix] = true
    prefix = prefix:match("^(.*)%.[^%.]+$")
  end
end

local function split_key(key)
  local parts = {}
  for part in key:gmatch("[^%.]+") do parts[#parts + 1] = part end
  return parts
end

local function deep_copy(value)
  if type(value) ~= "table" then return value end
  local copy = {}
  for k, v in pairs(value) do copy[k] = deep_copy(v) end
  return setmetatable(copy, getmetatable(value))
end

local function describe(value)
  if value == json.null then return "null" end
  if type(value) == "string" then return string.format("%q", value) end
  if type(value) == "table" then
    local ok, text = pcall(json.encode, value)
    return ok and text or "(table)"
  end
  return tostring(value)
end

local function is_finite(x)
  return type(x) == "number" and x == x and x ~= math.huge and x ~= -math.huge
end

--- Checks one value against its schema entry.
-- @return ok, normalised_value_or_reason
local function validate(entry, value)
  local t = entry.type
  if t == "boolean" then
    if type(value) == "boolean" then return true, value end
    return false, "must be true or false"
  elseif t == "integer" then
    if not is_finite(value) then return false, "must be a whole number" end
    local as_int = math.tointeger(value)
    if as_int == nil then return false, "must be a whole number" end
    if as_int < entry.min or as_int > entry.max then
      return false, string.format("must be between %d and %d", entry.min, entry.max)
    end
    return true, as_int
  elseif t == "number" then
    if not is_finite(value) then return false, "must be a number" end
    if value < entry.min or value > entry.max then
      return false, string.format("must be between %s and %s", tostring(entry.min), tostring(entry.max))
    end
    return true, value + 0.0
  elseif t == "enum" then
    for _, allowed in ipairs(entry.values) do
      if value == allowed then return true, value end
    end
    return false, "must be one of " .. table.concat(entry.values, ", ")
  elseif t == "path" then
    -- "" means "not set"; anything else must be an absolute folder path with no shell metacharacters
    if type(value) ~= "string" then return false, "must be text, such as \"D:/PalBackups\"" end
    if value == "" then return true, "" end
    local ok, result = backup_plan.safe_path(value)
    if not ok then return false, result end
    return true, result
  elseif t == "number_list" then
    -- exactly entry.length numbers, each min..max, not all zero; [] means "leave the game alone"
    if type(value) == "table" and next(value) == nil then return true, setmetatable({}, json.array_mt) end
    if not json.is_array(value) and not (type(value) == "table" and #value > 0) then
      return false, "must be a list of " .. entry.length .. " numbers, or [] to leave the game's own values"
    end
    if #value ~= entry.length then
      return false, string.format("must list exactly %d numbers (or [] to leave the game's own values), not %d", entry.length, #value)
    end
    local out, sum = {}, 0
    for i, n in ipairs(value) do
      if not is_finite(n) then return false, "item " .. i .. " must be a number" end
      if n < entry.min or n > entry.max then
        return false, string.format("item %d must be between %s and %s", i, tostring(entry.min), tostring(entry.max))
      end
      out[#out + 1] = n + 0.0
      sum = sum + n
    end
    if sum <= 0 then return false, "the numbers cannot all be zero" end
    return true, setmetatable(out, json.array_mt)
  elseif t == "item_list" then
    -- ["PalSphere:10", "Wood:20"]: an item id, a colon, a count of 1..9999
    if not json.is_array(value) and not (type(value) == "table" and #value > 0) then
      if type(value) == "table" and next(value) == nil then return true, setmetatable({}, json.array_mt) end
      return false, "must be a list such as [\"PalSphere:10\", \"Wood:20\"]"
    end
    if #value > entry.max_items then
      return false, string.format("must list at most %d items", entry.max_items)
    end
    local seen, out = {}, {}
    for i, item in ipairs(value) do
      if type(item) ~= "string" then return false, "item " .. i .. " must be text like \"PalSphere:10\"" end
      local id, count = item:match("^([A-Za-z][A-Za-z0-9_]*):([1-9]%d*)$")
      if not id or #id > 64 or #count > 4 then
        return false, "item " .. i .. " (" .. describe(item) .. ") must look like \"ItemId:count\" with a count of 1 to 9999"
      end
      if seen[id] then return false, "lists " .. id .. " twice" end
      seen[id] = true
      out[#out + 1] = id .. ":" .. count
    end
    return true, setmetatable(out, json.array_mt)
  elseif t == "char_list" then
    if not json.is_array(value) and not (type(value) == "table" and #value > 0) then
      return false, "must be a list such as [\"/\", \"!\"]"
    end
    if #value < entry.min_items or #value > entry.max_items then
      return false, string.format("must list %d to %d characters", entry.min_items, entry.max_items)
    end
    local allowed, seen, out = {}, {}, {}
    for _, v in ipairs(entry.values) do allowed[v] = true end
    for i, item in ipairs(value) do
      if not allowed[item] then
        return false, "item " .. i .. " must be one of " .. table.concat(entry.values, " ")
      end
      if seen[item] then
        return false, "lists " .. describe(item) .. " twice"
      end
      seen[item] = true
      out[#out + 1] = item
    end
    return true, setmetatable(out, json.array_mt)
  end
  error("config schema: unknown type " .. tostring(t))
end

local function get_path(tree, parts)
  local node = tree
  for i = 1, #parts do
    if type(node) ~= "table" or json.is_array(node) then return nil, i - 1 end
    node = node[parts[i]]
    if node == nil then return nil, i end
  end
  return node, #parts
end

local function set_path(tree, parts, value)
  local node = tree
  for i = 1, #parts - 1 do
    local nxt = node[parts[i]]
    if type(nxt) ~= "table" then
      nxt = {}
      node[parts[i]] = nxt
    end
    node = nxt
  end
  node[parts[#parts]] = value
end

--- A nested table holding every default.
function config.defaults()
  local tree = {}
  for _, entry in ipairs(config.SCHEMA) do
    set_path(tree, split_key(entry.key), deep_copy(entry.default))
  end
  return tree
end

--- The text of the default file, keys in schema order.
function config.default_file_text()
  local tree = {}
  local orders = {}
  for _, entry in ipairs(config.SCHEMA) do
    local parts = split_key(entry.key)
    local node, path = tree, ""
    for i = 1, #parts do
      local part = parts[i]
      orders[path] = orders[path] or {}
      local order = orders[path]
      local listed = false
      for _, k in ipairs(order) do if k == part then listed = true break end end
      if not listed then order[#order + 1] = part end
      if i < #parts then
        if node[part] == nil then
          node[part] = setmetatable({}, { __keyorder = {} })
        end
        node = node[part]
        path = path .. part .. "."
      else
        node[part] = deep_copy(entry.default)
      end
    end
  end
  -- attach the collected orders to each object's metatable
  local function attach(node, path)
    local mt = getmetatable(node) or {}
    mt.__keyorder = orders[path] or {}
    setmetatable(node, mt)
    for k, v in pairs(node) do
      if type(v) == "table" and not json.is_array(v) then
        attach(v, path .. k .. ".")
      end
    end
  end
  attach(tree, "")
  return json.encode(tree, "  ") .. "\n"
end

local function levenshtein(a, b)
  local la, lb = #a, #b
  if la == 0 then return lb end
  if lb == 0 then return la end
  local prev, cur = {}, {}
  for j = 0, lb do prev[j] = j end
  for i = 1, la do
    cur[0] = i
    local ca = a:byte(i)
    for j = 1, lb do
      local cost = (ca == b:byte(j)) and 0 or 1
      cur[j] = math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
    end
    prev, cur = cur, prev
  end
  return prev[lb]
end

local function suggest(key)
  local best, best_d = nil, math.huge
  for _, entry in ipairs(config.SCHEMA) do
    local d = levenshtein(key, entry.key)
    if d < best_d then best, best_d = entry.key, d end
  end
  if best and best_d <= math.max(2, #key // 4) then return best end
  return nil
end

-- Collects every leaf path in the admin's file so typos can be reported.
local function collect_leaves(node, prefix, out, dotted)
  for k, v in pairs(node) do
    local path = prefix == "" and k or (prefix .. "." .. k)
    if type(k) == "string" and k:find(".", 1, true) then
      -- "chat.max_line_bytes": 500 written flat is not the same as {"chat": {"max_line_bytes": 500}}
      dotted[#dotted + 1] = path
    elseif type(v) == "table" and not json.is_array(v) and v ~= json.null then
      collect_leaves(v, path, out, dotted)
    else
      out[#out + 1] = path
    end
  end
end

--- Turns a decoded document into a complete settings table.
-- @return settings (every key present), report (list of {level=, message=})
function config.from_document(doc)
  local report = {}
  local function note(level, fmt, ...)
    report[#report + 1] = { level = level, message = string.format(fmt, ...) }
  end
  local settings = config.defaults()
  if type(doc) ~= "table" or doc == json.null or json.is_array(doc) then
    note("error", "%s must contain a JSON object ({ ... }); using every default", config.FILE_NAME)
    return settings, report
  end

  for _, entry in ipairs(config.SCHEMA) do
    local parts = split_key(entry.key)
    local value = get_path(doc, parts)
    if value == nil then
      note("info", "%s is not set; using the default %s", entry.key, describe(entry.default))
    else
      local ok, result = validate(entry, value)
      if ok then
        set_path(settings, parts, result)
      else
        note("warn", "%s = %s %s; using the default %s", entry.key, describe(value), result, describe(entry.default))
      end
    end
  end

  local leaves, dotted = {}, {}
  collect_leaves(doc, "", leaves, dotted)
  table.sort(leaves)
  table.sort(dotted)
  for _, path in ipairs(dotted) do
    note("warn", "the key %q contains a dot, so it is not the setting it looks like: write nested objects "
      .. "({\"chat\": {\"max_line_bytes\": 500}}); it is ignored", path)
  end
  for _, path in ipairs(leaves) do
    if group_keys[path] then
      note("warn", "%s must be an object ({ ... }); the defaults inside it are used", path)
    elseif not by_key[path] then
      local hint = suggest(path)
      if hint then
        note("warn", "unknown setting %s (did you mean %s?); it is ignored", path, hint)
      else
        note("warn", "unknown setting %s; it is ignored", path)
      end
    end
  end

  -- cross-checks between settings
  local rmin, rmax = settings.raid.cooldown_min_minutes, settings.raid.cooldown_max_minutes
  if rmin >= 0 and rmax >= 0 and rmin > rmax then
    note("warn", "raid.cooldown_min_minutes = %d is larger than raid.cooldown_max_minutes = %d; both are left to the game", rmin, rmax)
    settings.raid.cooldown_min_minutes, settings.raid.cooldown_max_minutes = -1, -1
  end

  if settings.schema_version > config.SCHEMA_VERSION then
    note("warn", "schema_version %d is newer than this Noctua understands (%d); unknown keys are ignored",
      settings.schema_version, config.SCHEMA_VERSION)
  end
  return settings, report
end

--- Parses file text. A syntax error keeps every default (and the file untouched).
function config.from_text(text)
  local doc, err, warnings = json.decode(text)
  if doc == nil then
    local settings = config.defaults()
    return settings, { { level = "error",
      message = string.format("%s could not be read (%s); using every default. The file was not changed.",
        config.FILE_NAME, err) } }
  end
  local settings, report = config.from_document(doc)
  for _, w in ipairs(warnings or {}) do
    table.insert(report, 1, { level = "warn", message = config.FILE_NAME .. ": " .. w })
  end
  return settings, report
end

--- Loads the settings through `fs` (see noctua/fs.lua), creating the file if missing.
-- @return settings, report, created (true when the default file was written)
function config.load(fs, path)
  local text, read_err = fs.read(path)
  if text == nil then
    if fs.exists(path) then
      local settings = config.defaults()
      return settings, { { level = "error", message = string.format(
        "%s exists but could not be opened (%s); using every default", path, tostring(read_err)) } }, false
    end
    local ok, write_err = fs.write_atomic(path, config.default_file_text())
    local settings = config.defaults()
    if ok then
      return settings, { { level = "info", message = "created " .. path .. " with the defaults" } }, true
    end
    return settings, { { level = "warn", message = string.format(
      "could not create %s (%s); using every default", path, tostring(write_err)) } }, false
  end
  local settings, report = config.from_text(text)
  return settings, report, false
end

--- Reads a dotted key from a settings table (for code that stores keys as strings).
function config.get(settings, key)
  local value = get_path(settings, split_key(key))
  return value
end

config._validate = validate
config._by_key = by_key

return config
