-- Noctua: small file helpers on top of the Lua io library UE4SS provides.
--
-- write_atomic never leaves a half-written file under the real name. On Windows,
-- os.rename cannot replace an existing file, so the old file is moved aside first
-- and put back if the swap fails. A crash between the two renames leaves
-- "<name>.tmp" (new) and "<name>.bak" (old); read() falls back to them in that order.

local fs = {}

local function read_whole(path)
  local handle, err = io.open(path, "rb")
  if not handle then return nil, err end
  local text, read_err = handle:read("a")
  handle:close()
  if text == nil then return nil, read_err or "read failed" end
  return text
end

function fs.exists(path)
  local handle = io.open(path, "rb")
  if handle then
    handle:close()
    return true
  end
  return false
end

--- Reads a whole file. If it is missing, a leftover of an interrupted write is used.
function fs.read(path)
  local text, err = read_whole(path)
  if text ~= nil then return text end
  for _, suffix in ipairs({ ".tmp", ".bak" }) do
    local fallback = read_whole(path .. suffix)
    if fallback ~= nil and #fallback > 0 then
      return fallback, nil, path .. suffix
    end
  end
  return nil, err
end

function fs.write_atomic(path, text)
  local tmp, bak = path .. ".tmp", path .. ".bak"
  local handle, err = io.open(tmp, "wb")
  if not handle then return nil, err end
  local ok, write_err = handle:write(text)
  if not ok then
    handle:close()
    os.remove(tmp)
    return nil, write_err
  end
  local flushed, flush_err = handle:flush()
  handle:close()
  if not flushed then
    os.remove(tmp)
    return nil, flush_err
  end
  local had_old = fs.exists(path)
  if had_old then
    os.remove(bak)
    local moved, move_err = os.rename(path, bak)
    if not moved then
      os.remove(tmp)
      return nil, move_err
    end
  end
  local renamed, rename_err = os.rename(tmp, path)
  if not renamed then
    if had_old then os.rename(bak, path) end
    return nil, rename_err
  end
  if had_old then os.remove(bak) end
  return true
end

--- Joins path parts with "/" (Windows accepts forward slashes).
function fs.join(...)
  local parts = { ... }
  local out = {}
  for i, part in ipairs(parts) do
    part = tostring(part):gsub("\\", "/")
    if i > 1 then part = part:gsub("^/+", "") end
    if i < #parts then part = part:gsub("/+$", "") end
    out[#out + 1] = part
  end
  return table.concat(out, "/")
end

--- Parent directory of a path ("a/b/c.lua" -> "a/b").
function fs.dirname(path)
  path = tostring(path):gsub("\\", "/")
  local dir = path:match("^(.*)/[^/]*$")
  return dir or "."
end

return fs
