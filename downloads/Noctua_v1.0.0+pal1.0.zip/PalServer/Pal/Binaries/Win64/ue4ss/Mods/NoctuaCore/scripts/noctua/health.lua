-- Noctua: boot health check (NOCTUA_INIT.md Phase 1: load log + hook health).
--
-- Each feature lists the game symbols it needs (UFunction / class paths such as
-- "/Script/Pal.PalPlayerState:EnterChat_Receive") and may depend on other
-- features ("@messaging"). A feature is on only when every symbol was found and
-- every feature it depends on is on. A missing symbol switches off only the
-- features that need it; the rest of Noctua keeps running.

local health = {}

local Health = {}
Health.__index = Health

--- requirements: { { name = "home", needs = { "/Script/...", "@messaging" } }, ... } (ordered)
function health.new(requirements)
  return setmetatable({
    requirements = requirements,
    symbols = {},  -- path -> true/false
    state = {},    -- feature -> { ok = bool, reason = string|nil }
    runs = 0,
  }, Health)
end

--- Checks every symbol with `exists(path) -> bool` and recomputes the features.
-- Symbols already found are not checked again (they do not disappear).
function Health:run(exists)
  self.runs = self.runs + 1
  for _, req in ipairs(self.requirements) do
    for _, need in ipairs(req.needs) do
      if need:sub(1, 1) ~= "@" and self.symbols[need] ~= true then
        local ok, found = pcall(exists, need)
        self.symbols[need] = (ok and found) and true or false
      end
    end
  end
  self.state = {}
  for _, req in ipairs(self.requirements) do
    local ok, reason = true, nil
    for _, need in ipairs(req.needs) do
      if need:sub(1, 1) == "@" then
        local dep = self.state[need:sub(2)]
        if dep == nil then
          error("health: feature " .. req.name .. " depends on " .. need .. ", which is not declared before it")
        end
        if not dep.ok then ok, reason = false, "needs " .. need:sub(2) break end
      elseif not self.symbols[need] then
        ok, reason = false, "missing " .. need break
      end
    end
    self.state[req.name] = { ok = ok, reason = reason }
  end
end

function Health:feature_ok(name)
  local s = self.state[name]
  return s ~= nil and s.ok
end

function Health:reason(name)
  local s = self.state[name]
  if s == nil then return "not checked" end
  return s.reason
end

function Health:all_ok()
  for _, req in ipairs(self.requirements) do
    if not self:feature_ok(req.name) then return false end
  end
  return true
end

function Health:summary()
  local ok, missing, missing_symbols = 0, 0, {}
  local paths = {}
  for path in pairs(self.symbols) do paths[#paths + 1] = path end
  table.sort(paths)
  for _, path in ipairs(paths) do
    if self.symbols[path] then
      ok = ok + 1
    else
      missing = missing + 1
      missing_symbols[#missing_symbols + 1] = path
    end
  end
  local features = {}
  for _, req in ipairs(self.requirements) do
    local s = self.state[req.name] or { ok = false, reason = "not checked" }
    features[#features + 1] = { name = req.name, ok = s.ok, reason = s.reason }
  end
  return { ok = ok, missing = missing, missing_symbols = missing_symbols, features = features, runs = self.runs }
end

--- Writes the result to the log, one line per symbol and per feature.
function Health:report(log)
  local sum = self:summary()
  log.info("health check #%d: %d symbols found, %d missing", sum.runs, sum.ok, sum.missing)
  local paths = {}
  for path in pairs(self.symbols) do paths[#paths + 1] = path end
  table.sort(paths)
  for _, path in ipairs(paths) do
    if self.symbols[path] then
      log.debug("  OK       %s", path)
    else
      log.warn("  MISSING  %s", path)
    end
  end
  for _, f in ipairs(sum.features) do
    if f.ok then
      log.info("  feature %-10s ON", f.name)
    else
      log.warn("  feature %-10s OFF (%s)", f.name, tostring(f.reason))
    end
  end
  return sum
end

return health
