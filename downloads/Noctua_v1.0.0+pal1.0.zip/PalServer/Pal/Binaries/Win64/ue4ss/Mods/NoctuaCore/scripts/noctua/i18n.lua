-- Noctua: player-facing text. Japanese is primary; English must carry exactly the
-- same keys and placeholders (tests/test_i18n.lua gates both).
-- Placeholders are {name}; values are inserted verbatim, never re-expanded.

local i18n = {}

i18n.LANGUAGES = { "ja", "en" }

i18n.catalog = {
  ja = {
    prefix = "【Noctua】",

    rate_limited = "コマンドの送信が速すぎます。少し待ってからお試しください。",
    line_too_long = "コマンドが長すぎます。",
    command_disabled = "このコマンドはこのサーバーでは無効です。",
    feature_unavailable = "この機能は現在使えません（管理者は /noctua health で確認できます）。",
    cooldown = "{command} はあと {time} 使えません。",
    admin_only = "このコマンドは管理者専用です。",
    internal_error = "内部エラーが発生しました。管理者にお知らせください。",

    help_header = "使えるコマンド:",
    help_home = "/home [番号|list] - ギルド拠点へテレポート",
    help_tpa = "/tpa <名前> - プレイヤーの所へのテレポートを申請",
    help_tpaccept = "/tpaccept [名前]・/tpdeny [名前] - 申請を承認・拒否",
    help_tpcancel = "/tpcancel - 自分の申請を取り消す",
    help_stats = "/stats - サーバーの状況",
    help_lang = "/lang ja|en - 表示言語の切り替え",
    help_kit = "/kit starter - スターターキットを受け取る（1 回だけ）",
    help_unstuck = "/unstuck - 地形に埋まったとき、安全な場所へ移動",
    help_admin = "/noctua health|base|raid|backup|reload|version - 管理者用",

    home_no_guild = "ギルドに入っていないため、拠点がありません。",
    home_no_base = "あなたのギルドにはまだ拠点がありません。",
    home_list_header = "ギルド拠点（{count} 件）:",
    home_list_entry = "  {index}. ここから約 {distance}",
    home_bad_index = "拠点の番号は 1〜{count} で指定してください。",
    home_no_safe_spot = "拠点の近くに安全な着地点が見つかりませんでした。",
    home_arrived = "拠点 {index} に到着しました。",

    tp_warmup = "{seconds} 秒後にテレポートします。動いたり攻撃を受けたりすると中止します。",
    tp_cancel_moved = "移動したため、テレポートを中止しました。",
    tp_cancel_damaged = "攻撃を受けたため、テレポートを中止しました。",
    tp_cancel_invalid = "テレポートを中止しました。",
    tp_in_combat = "ダメージを受けた直後はテレポートできません（あと {time}）。",
    tp_already_pending = "すでにテレポートの準備中です。",
    tp_failed = "テレポートに失敗しました。",

    tpa_usage = "使い方: /tpa <プレイヤー名>",
    tpa_not_found = "「{name}」という名前のプレイヤーはオンラインにいません。",
    tpa_ambiguous = "「{name}」に当てはまるプレイヤーが複数います: {candidates}",
    tpa_self = "自分自身には申請できません。",
    tpa_sent = "{target} さんに申請を送りました（{seconds} 秒で失効）。/tpcancel で取り消せます。",
    tpa_received = "{requester} さんがあなたの所へのテレポートを申請しています。/tpaccept で承認、/tpdeny で拒否（{seconds} 秒）。",
    tpa_replaced = "{target} さんへの前の申請は取り消しました。",
    tpa_target_busy = "{target} さんは申請をこれ以上受け付けられません。少し待ってからお試しください。",
    tpa_none_pending = "承認待ちの申請はありません。",
    tpa_which = "申請が複数あります。/tpaccept <名前> で選んでください: {candidates}",
    tpa_accepted_target = "{requester} さんの申請を承認しました。",
    tpa_accepted_requester = "{target} さんが申請を承認しました。",
    tpa_denied_target = "{requester} さんの申請を拒否しました。",
    tpa_denied_requester = "{target} さんが申請を拒否しました。",
    tpa_expired_requester = "{target} さんへの申請は期限切れになりました。",
    tpa_expired_target = "{requester} さんからの申請は期限切れになりました。",
    tpa_cancelled_requester = "{target} さんへの申請を取り消しました。",
    tpa_cancelled_target = "{requester} さんが申請を取り消しました。",
    tpa_no_outgoing = "取り消す申請はありません。",
    tpa_left = "{name} さんがログアウトしたため、申請は無効になりました。",
    tpa_arrived = "{target} さんの所に到着しました。",
    tpa_no_safe_spot = "{target} さんの近くに安全な着地点が見つかりませんでした。",
    tpa_requester_busy = "{requester} さんは今テレポートできない状態です（ダメージを受けた直後、または別のテレポートの準備中）。",
    tpa_requester_cooldown = "{requester} さんはまだテレポートできません（クールダウン中: あと {time}）。",

    kit_usage = "使い方: /kit starter",
    kit_unknown = "「{name}」というキットはありません。使えるキット: starter",
    kit_done = "スターターキットを受け取りました（{count} 種類）。",
    kit_already = "スターターキットは受け取り済みです。",
    kit_partial = "持ち物に空きがなく、一部しか受け取れませんでした。空きを作って、もう一度 /kit starter を実行してください。",
    kit_none = "アイテムを受け取れませんでした。持ち物に空きを作って、もう一度お試しください。",
    kit_bad_items = "{count} 種類のアイテムは、このサーバーでは配れませんでした。管理者にお知らせください。",
    kit_unverified = "アイテムを渡す処理は成功と返りましたが、持ち物が増えませんでした。管理者にお知らせください。",
    kit_unsaved = "受け取りの記録を保存できないため、今はキットを渡せません。管理者にお知らせください。",

    unstuck_sent = "最寄りの安全な場所へ移動します。",
    unstuck_failed = "移動できませんでした。もう一度お試しください。",
    unstuck_auto_moved = "地形に埋まっているようだったので、安全な場所へ移動しました。",

    stats_header = "【サーバーの状況】",
    stats_uptime = "稼働時間: {uptime}",
    stats_players = "接続人数: {count} / {max}",
    stats_players_nomax = "接続人数: {count}",
    stats_tps = "サーバー TPS: {tps}（直近 {window} 秒の平均）",
    stats_tps_unknown = "サーバー TPS: 計測中",
    stats_version = "Noctua {version}",

    lang_usage = "使い方: /lang ja または /lang en",
    lang_set = "表示言語を日本語にしました。",

    admin_health_header = "Noctua の健全性: 正常 {ok} 件 / 欠落 {missing} 件",
    admin_health_symbol = "  欠落: {symbol}",
    admin_health_feature = "  {feature}: {state}",
    admin_state_on = "有効",
    admin_state_off = "無効（{reason}）",
    admin_usage = "使い方: /noctua health | base | raid | backup | reload | version",
    admin_base_header = "ゲームの設定（いま使われている値）:",
    admin_base_workers = "  作業パルの上限の設定: 現在 {actual} / 目標 {target} / {state}",
    admin_base_decay = "  建築物の劣化の倍率: 現在 {actual} / 目標 {target} / {state}",
    admin_base_eggs = "  卵の孵化時間（時間）: 現在 {actual} / 目標 {target} / {state}",
    admin_base_passives = "  パッシブ継承の重み: 現在 {actual} / 目標 {target} / {state}",
    admin_base_autosave = "  自動保存の間隔（秒）: 現在 {actual} / 目標 {target} / {state}",
    admin_base_guild = "  あなたのギルド: 拠点レベル {level}、作業パルの上限 {cap}",
    admin_base_guild_unknown = "  あなたのギルドの上限は読み取れません（{reason}）",
    admin_base_unreadable = "  ゲームの設定を読み取れません（{reason}）",
    admin_target_none = "変更しない",
    admin_backup_off = "バックアップは無効です（backup.enabled が false）。",
    admin_backup_line = "バックアップ: {phase} / 成功 {ok} 回 / 破棄 {discarded} 回 / 次回まで {next}",
    admin_backup_last = "  最後の成功: {name}（Level.sav {bytes} バイト）",
    admin_backup_error = "  最後の問題: {error}",
    backup_phase_idle = "待機中",
    backup_phase_settling = "保存が落ち着くのを待っています",
    backup_phase_copying = "コピー中",
    backup_phase_cleaning = "古いバックアップを削除中",
    admin_setting_line = "  {name}: 現在 {actual} / 目標 {target} / {state}",
    admin_raid_started = "襲撃を開始しました（{distance} 先の拠点）。",
    admin_raid_failed = "襲撃を開始できませんでした（{reason}）。",
    admin_raid_no_base = "拠点が見つかりません（{reason}）。",
    admin_raid_too_far = "最寄りの拠点が遠すぎます（{distance}）。拠点の近くで実行してください。",
    admin_raid_unavailable = "この版のゲームでは襲撃を起こせません（{reason}）。",
    ws_state_ok = "反映済み",
    ws_state_off = "対象外",
    ws_state_failed = "書き込めません",
    ws_state_unavailable = "待機中",
    ws_state_missing = "このゲームの版には無い",
    admin_reload_ok = "設定を再読み込みしました（警告 {warnings} 件、詳細はサーバーのログ）。",
    admin_version = "Noctua {version}（{lua}）",

    unit_hours_minutes = "{h} 時間 {m} 分",
    unit_minutes_seconds = "{m} 分 {s} 秒",
    unit_minutes = "{m} 分",
    unit_seconds = "{s} 秒",
    unit_days_hours = "{d} 日 {h} 時間",
    unit_meters = "{m} m",
    unit_kilometers = "{km} km",
    list_separator = "、",
  },

  en = {
    prefix = "[Noctua] ",

    rate_limited = "You're sending commands too fast. Please wait a moment.",
    line_too_long = "That command is too long.",
    command_disabled = "This command is disabled on this server.",
    feature_unavailable = "This feature is unavailable right now (admins: /noctua health).",
    cooldown = "You can use {command} again in {time}.",
    admin_only = "This command is for admins only.",
    internal_error = "Something went wrong. Please tell an admin.",

    help_header = "Commands:",
    help_home = "/home [number|list] - teleport to your guild base",
    help_tpa = "/tpa <name> - ask to teleport to a player",
    help_tpaccept = "/tpaccept [name] / /tpdeny [name] - accept or refuse a request",
    help_tpcancel = "/tpcancel - withdraw your request",
    help_stats = "/stats - server status",
    help_lang = "/lang ja|en - switch language",
    help_kit = "/kit starter - get the starter kit (once)",
    help_unstuck = "/unstuck - move to a safe spot if you are stuck in the terrain",
    help_admin = "/noctua health|base|raid|backup|reload|version - admins",

    home_no_guild = "You're not in a guild, so you have no base.",
    home_no_base = "Your guild has no base yet.",
    home_list_header = "Guild bases ({count}):",
    home_list_entry = "  {index}. about {distance} away",
    home_bad_index = "Choose a base number from 1 to {count}.",
    home_no_safe_spot = "No safe landing spot was found near the base.",
    home_arrived = "Arrived at base {index}.",

    tp_warmup = "Teleporting in {seconds}s. Moving or taking damage cancels it.",
    tp_cancel_moved = "Teleport cancelled: you moved.",
    tp_cancel_damaged = "Teleport cancelled: you took damage.",
    tp_cancel_invalid = "Teleport cancelled.",
    tp_in_combat = "You were just hurt: no teleporting for {time}.",
    tp_already_pending = "A teleport is already in progress.",
    tp_failed = "Teleport failed.",

    tpa_usage = "Usage: /tpa <player name>",
    tpa_not_found = "No online player is called \"{name}\".",
    tpa_ambiguous = "\"{name}\" matches several players: {candidates}",
    tpa_self = "You can't send a request to yourself.",
    tpa_sent = "Request sent to {target} (expires in {seconds}s). /tpcancel withdraws it.",
    tpa_received = "{requester} wants to teleport to you. /tpaccept to allow, /tpdeny to refuse ({seconds}s).",
    tpa_replaced = "Your earlier request to {target} was withdrawn.",
    tpa_target_busy = "{target} can't take more requests right now. Please try again shortly.",
    tpa_none_pending = "You have no pending requests.",
    tpa_which = "You have several requests. Choose one with /tpaccept <name>: {candidates}",
    tpa_accepted_target = "You accepted {requester}'s request.",
    tpa_accepted_requester = "{target} accepted your request.",
    tpa_denied_target = "You refused {requester}'s request.",
    tpa_denied_requester = "{target} refused your request.",
    tpa_expired_requester = "Your request to {target} expired.",
    tpa_expired_target = "The request from {requester} expired.",
    tpa_cancelled_requester = "You withdrew your request to {target}.",
    tpa_cancelled_target = "{requester} withdrew their request.",
    tpa_no_outgoing = "You have no request to withdraw.",
    tpa_left = "{name} left, so the request was cancelled.",
    tpa_arrived = "Arrived at {target}.",
    tpa_no_safe_spot = "No safe landing spot was found near {target}.",
    tpa_requester_busy = "{requester} can't teleport right now (just hurt, or another teleport is under way).",
    tpa_requester_cooldown = "{requester} can't teleport yet (cooldown: {time} left).",

    kit_usage = "Usage: /kit starter",
    kit_unknown = "There is no kit called \"{name}\". Kits: starter",
    kit_done = "You received the starter kit ({count} items).",
    kit_already = "You already received the starter kit.",
    kit_partial = "Your inventory is full, so only part of the kit arrived. Make room and run /kit starter again.",
    kit_none = "No items could be given. Make room in your inventory and try again.",
    kit_bad_items = "{count} items could not be given on this server. Please tell an admin.",
    kit_unverified = "The game said the items were given, but your inventory did not grow. Please tell an admin.",
    kit_unsaved = "The record of what you received cannot be saved right now, so no kit is given. Please tell an admin.",

    unstuck_sent = "Moving you to the nearest safe spot.",
    unstuck_failed = "Could not move you. Please try again.",
    unstuck_auto_moved = "You looked stuck in the terrain, so you were moved to a safe spot.",

    stats_header = "[Server status]",
    stats_uptime = "Uptime: {uptime}",
    stats_players = "Players online: {count} / {max}",
    stats_players_nomax = "Players online: {count}",
    stats_tps = "Server TPS: {tps} (average over the last {window}s)",
    stats_tps_unknown = "Server TPS: measuring",
    stats_version = "Noctua {version}",

    lang_usage = "Usage: /lang ja or /lang en",
    lang_set = "Language set to English.",

    admin_health_header = "Noctua health: {ok} OK / {missing} missing",
    admin_health_symbol = "  missing: {symbol}",
    admin_health_feature = "  {feature}: {state}",
    admin_state_on = "on",
    admin_state_off = "off ({reason})",
    admin_usage = "Usage: /noctua health | base | raid | backup | reload | version",
    admin_base_header = "Game settings (the values in use now):",
    admin_base_workers = "  Worker Pal limit setting: now {actual} / target {target} / {state}",
    admin_base_decay = "  Structure decay rate: now {actual} / target {target} / {state}",
    admin_base_eggs = "  Egg hatching time (hours): now {actual} / target {target} / {state}",
    admin_base_passives = "  Passive inheritance weights: now {actual} / target {target} / {state}",
    admin_base_autosave = "  Autosave interval (seconds): now {actual} / target {target} / {state}",
    admin_base_guild = "  Your guild: base level {level}, worker Pal cap {cap}",
    admin_base_guild_unknown = "  Your guild's cap could not be read ({reason})",
    admin_base_unreadable = "  Game settings could not be read ({reason})",
    admin_target_none = "leave as is",
    admin_backup_off = "Backups are off (backup.enabled is false).",
    admin_backup_line = "Backups: {phase} / {ok} done / {discarded} discarded / next in {next}",
    admin_backup_last = "  Last success: {name} (Level.sav {bytes} bytes)",
    admin_backup_error = "  Last problem: {error}",
    backup_phase_idle = "idle",
    backup_phase_settling = "waiting for the save to settle",
    backup_phase_copying = "copying",
    backup_phase_cleaning = "removing old backups",
    admin_setting_line = "  {name}: now {actual} / target {target} / {state}",
    admin_raid_started = "Raid started on the base {distance} away.",
    admin_raid_failed = "Could not start a raid ({reason}).",
    admin_raid_no_base = "No base found ({reason}).",
    admin_raid_too_far = "The nearest base is too far away ({distance}). Run this near a base.",
    admin_raid_unavailable = "This game version cannot start a raid ({reason}).",
    ws_state_ok = "in effect",
    ws_state_off = "not managed",
    ws_state_failed = "could not write",
    ws_state_unavailable = "waiting",
    ws_state_missing = "not in this game version",
    admin_reload_ok = "Config reloaded ({warnings} warnings; details in the server log).",
    admin_version = "Noctua {version} ({lua})",

    unit_hours_minutes = "{h}h {m}m",
    unit_minutes_seconds = "{m}m {s}s",
    unit_minutes = "{m}m",
    unit_seconds = "{s}s",
    unit_days_hours = "{d}d {h}h",
    unit_meters = "{m} m",
    unit_kilometers = "{km} km",
    list_separator = ", ",
  },
}

local default_language = "ja"

function i18n.is_language(lang)
  return i18n.catalog[lang] ~= nil
end

function i18n.set_default(lang)
  if i18n.catalog[lang] then
    default_language = lang
    return true
  end
  return false
end

function i18n.default()
  return default_language
end

--- Formats message `key` in `lang` (falls back to the default language, then to ja).
-- A missing key returns the key itself in angle brackets, so it shows up in tests
-- and in chat instead of silently printing nothing.
function i18n.t(lang, key, params)
  local catalog = i18n.catalog[lang] or i18n.catalog[default_language] or i18n.catalog.ja
  local template = catalog[key]
  if template == nil then
    template = i18n.catalog.ja[key]
  end
  if template == nil then
    return "<" .. tostring(key) .. ">"
  end
  if params == nil then
    return template
  end
  return (template:gsub("{([%w_]+)}", function(name)
    local value = params[name]
    if value == nil then
      return "{" .. name .. "}"
    end
    return tostring(value)
  end))
end

--- Placeholder names used by a template, sorted (for the parity gate).
function i18n.placeholders(template)
  local names, seen = {}, {}
  for name in template:gmatch("{([%w_]+)}") do
    if not seen[name] then
      seen[name] = true
      names[#names + 1] = name
    end
  end
  table.sort(names)
  return names
end

--- Human-readable duration from whole seconds.
function i18n.duration(lang, seconds)
  seconds = math.max(0, math.floor((tonumber(seconds) or 0) + 0.5))
  local d = seconds // 86400
  local h = (seconds % 86400) // 3600
  local m = (seconds % 3600) // 60
  local s = seconds % 60
  if d > 0 then
    return i18n.t(lang, "unit_days_hours", { d = d, h = h })
  elseif h > 0 then
    return i18n.t(lang, "unit_hours_minutes", { h = h, m = m })
  elseif m > 0 and s > 0 then
    return i18n.t(lang, "unit_minutes_seconds", { m = m, s = s })
  elseif m > 0 then
    return i18n.t(lang, "unit_minutes", { m = m })
  else
    return i18n.t(lang, "unit_seconds", { s = s })
  end
end

--- Distance from Unreal units (centimetres).
function i18n.distance(lang, centimetres)
  local metres = math.max(0, (tonumber(centimetres) or 0) / 100)
  if metres >= 1000 then
    return i18n.t(lang, "unit_kilometers", { km = string.format("%.1f", metres / 1000) })
  end
  return i18n.t(lang, "unit_meters", { m = string.format("%d", math.floor(metres + 0.5)) })
end

function i18n.join(lang, items)
  return table.concat(items, i18n.t(lang, "list_separator"))
end

return i18n
