-- Noctua: strict JSON reader (RFC 8259) and a stable, indented writer.
-- No external libraries: UE4SS ships none, and admins edit these files by hand,
-- so every rejection names the line and column.

local json = {}

local byte, sub, char, find, format = string.byte, string.sub, string.char, string.find, string.format
local concat, sort = table.concat, table.sort

-- Sentinel for JSON null, so a key set to null is distinguishable from an absent key.
json.null = setmetatable({}, { __name = "json.null", __tostring = function() return "null" end })

-- Decoded containers carry these metatables so the writer can round-trip [] and {}.
json.array_mt = { __name = "json.array" }
json.object_mt = { __name = "json.object" }

local MAX_DEPTH = 64

local function line_col(text, pos)
  local line, col = 1, 1
  for i = 1, pos - 1 do
    if byte(text, i) == 10 then
      line, col = line + 1, 1
    else
      col = col + 1
    end
  end
  return line, col
end

local function fail(state, pos, message)
  local line, col = line_col(state.text, pos)
  error({ noctua_json = true, message = format("line %d, column %d: %s", line, col, message) }, 0)
end

local function skip_ws(state, pos)
  local text = state.text
  while true do
    local b = byte(text, pos)
    if b == 32 or b == 9 or b == 10 or b == 13 then
      pos = pos + 1
    else
      return pos
    end
  end
end

local function utf8_encode(cp)
  if cp < 0x80 then
    return char(cp)
  elseif cp < 0x800 then
    return char(0xC0 | (cp >> 6), 0x80 | (cp & 0x3F))
  elseif cp < 0x10000 then
    return char(0xE0 | (cp >> 12), 0x80 | ((cp >> 6) & 0x3F), 0x80 | (cp & 0x3F))
  else
    return char(0xF0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3F), 0x80 | ((cp >> 6) & 0x3F), 0x80 | (cp & 0x3F))
  end
end

local ESCAPES = {
  [34] = '"', [92] = "\\", [47] = "/", [98] = "\b", [102] = "\f", [110] = "\n", [114] = "\r", [116] = "\t",
}

local function read_hex4(state, pos)
  local hex = sub(state.text, pos, pos + 3)
  if #hex < 4 or not find(hex, "^%x%x%x%x$") then
    fail(state, pos, "\\u must be followed by four hex digits")
  end
  return tonumber(hex, 16)
end

local function decode_string(state, pos)
  -- pos is at the opening quote
  local text = state.text
  local parts, n = {}, 0
  local i = pos + 1
  local run_start = i
  while true do
    local b = byte(text, i)
    if b == nil then
      fail(state, pos, "unterminated string")
    elseif b == 34 then
      n = n + 1
      parts[n] = sub(text, run_start, i - 1)
      return concat(parts), i + 1
    elseif b == 92 then
      n = n + 1
      parts[n] = sub(text, run_start, i - 1)
      local e = byte(text, i + 1)
      if e == 117 then
        local cp = read_hex4(state, i + 2)
        local consumed = 6
        if cp >= 0xD800 and cp <= 0xDBFF then
          if sub(text, i + 6, i + 7) ~= "\\u" then
            fail(state, i, "high surrogate without a following low surrogate")
          end
          local low = read_hex4(state, i + 8)
          if low < 0xDC00 or low > 0xDFFF then
            fail(state, i + 6, "invalid low surrogate")
          end
          cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00)
          consumed = 12
        elseif cp >= 0xDC00 and cp <= 0xDFFF then
          fail(state, i, "lone low surrogate")
        end
        n = n + 1
        parts[n] = utf8_encode(cp)
        i = i + consumed
      else
        local mapped = e and ESCAPES[e]
        if not mapped then
          fail(state, i, "invalid escape sequence")
        end
        n = n + 1
        parts[n] = mapped
        i = i + 2
      end
      run_start = i
    elseif b < 32 then
      fail(state, i, "control character inside a string (use \\n, \\t ...)")
    else
      i = i + 1
    end
  end
end

local function decode_number(state, pos)
  local text = state.text
  local i = pos
  local is_float = false
  if byte(text, i) == 45 then i = i + 1 end -- '-'
  local b = byte(text, i)
  if b == 48 then -- '0'
    i = i + 1
  elseif b and b >= 49 and b <= 57 then
    repeat i = i + 1; b = byte(text, i) until not (b and b >= 48 and b <= 57)
  else
    fail(state, pos, "invalid number")
  end
  if byte(text, i) == 46 then -- '.'
    is_float = true
    i = i + 1
    b = byte(text, i)
    if not (b and b >= 48 and b <= 57) then fail(state, i, "digit expected after decimal point") end
    repeat i = i + 1; b = byte(text, i) until not (b and b >= 48 and b <= 57)
  end
  b = byte(text, i)
  if b == 101 or b == 69 then -- 'e' 'E'
    is_float = true
    i = i + 1
    b = byte(text, i)
    if b == 43 or b == 45 then i = i + 1 end
    b = byte(text, i)
    if not (b and b >= 48 and b <= 57) then fail(state, i, "digit expected in exponent") end
    repeat i = i + 1; b = byte(text, i) until not (b and b >= 48 and b <= 57)
  end
  local literal = sub(text, pos, i - 1)
  local value
  if is_float then
    value = tonumber(literal)
  else
    value = math.tointeger(tonumber(literal)) or tonumber(literal)
  end
  if value == nil or value ~= value or value == math.huge or value == -math.huge then
    fail(state, pos, "number out of range")
  end
  return value, i
end

local decode_value

local function decode_array(state, pos, depth)
  local result = setmetatable({}, json.array_mt)
  local n = 0
  local i = skip_ws(state, pos + 1)
  if byte(state.text, i) == 93 then
    return result, i + 1
  end
  while true do
    local value
    value, i = decode_value(state, i, depth + 1)
    n = n + 1
    result[n] = value
    i = skip_ws(state, i)
    local b = byte(state.text, i)
    if b == 93 then
      return result, i + 1
    elseif b == 44 then
      i = skip_ws(state, i + 1)
      if byte(state.text, i) == 93 then fail(state, i, "trailing comma in array") end
    else
      fail(state, i, "',' or ']' expected in array")
    end
  end
end

local function decode_object(state, pos, depth)
  local result = setmetatable({}, json.object_mt)
  local i = skip_ws(state, pos + 1)
  if byte(state.text, i) == 125 then
    return result, i + 1
  end
  while true do
    if byte(state.text, i) ~= 34 then
      fail(state, i, "object key must be a string in double quotes")
    end
    local key_pos = i
    local key
    key, i = decode_string(state, i)
    i = skip_ws(state, i)
    if byte(state.text, i) ~= 58 then fail(state, i, "':' expected after object key") end
    i = skip_ws(state, i + 1)
    local value
    value, i = decode_value(state, i, depth + 1)
    if rawget(result, key) ~= nil then
      local line, col = line_col(state.text, key_pos)
      state.warnings[#state.warnings + 1] =
        format("line %d, column %d: duplicate key %q (the last one wins)", line, col, key)
    end
    rawset(result, key, value)
    i = skip_ws(state, i)
    local b = byte(state.text, i)
    if b == 125 then
      return result, i + 1
    elseif b == 44 then
      i = skip_ws(state, i + 1)
      if byte(state.text, i) == 125 then fail(state, i, "trailing comma in object") end
    else
      fail(state, i, "',' or '}' expected in object")
    end
  end
end

decode_value = function(state, pos, depth)
  if depth > MAX_DEPTH then fail(state, pos, "nesting deeper than " .. MAX_DEPTH) end
  local text = state.text
  local b = byte(text, pos)
  if b == 123 then
    return decode_object(state, pos, depth)
  elseif b == 91 then
    return decode_array(state, pos, depth)
  elseif b == 34 then
    return decode_string(state, pos)
  elseif b == 45 or (b and b >= 48 and b <= 57) then
    return decode_number(state, pos)
  elseif sub(text, pos, pos + 3) == "true" then
    return true, pos + 4
  elseif sub(text, pos, pos + 4) == "false" then
    return false, pos + 5
  elseif sub(text, pos, pos + 3) == "null" then
    return json.null, pos + 4
  elseif b == nil then
    fail(state, pos, "unexpected end of input")
  elseif b == 47 then
    fail(state, pos, "comments are not allowed in JSON")
  else
    fail(state, pos, "unexpected character " .. format("%q", char(b)))
  end
end

--- Decodes a JSON document.
-- @return value, nil, warnings   on success (warnings is a list, possibly empty)
-- @return nil, message            on failure (message names line and column)
function json.decode(text)
  if type(text) ~= "string" then
    return nil, "input is not a string"
  end
  -- Windows Notepad saves UTF-8 with a byte-order mark; accept it.
  if sub(text, 1, 3) == "\239\187\191" then
    text = sub(text, 4)
  end
  local valid, bad_pos = utf8.len(text)
  if not valid then
    local line, col = line_col(text, bad_pos)
    return nil, format("line %d, column %d: invalid UTF-8 (save the file as UTF-8)", line, col)
  end
  local state = { text = text, warnings = {} }
  local ok, value_or_err, pos = pcall(function()
    local p = skip_ws(state, 1)
    local value, after = decode_value(state, p, 0)
    after = skip_ws(state, after)
    if after <= #text then
      fail(state, after, "unexpected text after the JSON value")
    end
    return value, after
  end)
  if not ok then
    if type(value_or_err) == "table" and value_or_err.noctua_json then
      return nil, value_or_err.message
    end
    error(value_or_err, 0) -- a bug in this reader, not in the input
  end
  return value_or_err, nil, state.warnings
end

function json.is_array(value)
  return type(value) == "table" and getmetatable(value) == json.array_mt
end

function json.is_object(value)
  return type(value) == "table" and getmetatable(value) == json.object_mt
end

---------------------------------------------------------------------------
-- Writer
---------------------------------------------------------------------------

local function encode_string(s)
  return '"' .. s:gsub('[%c"\\]', function(c)
    local b = byte(c)
    if c == '"' then return '\\"'
    elseif c == "\\" then return "\\\\"
    elseif b == 10 then return "\\n"
    elseif b == 13 then return "\\r"
    elseif b == 9 then return "\\t"
    elseif b == 8 then return "\\b"
    elseif b == 12 then return "\\f"
    else return format("\\u%04x", b)
    end
  end) .. '"'
end

local function encode_number(x)
  if x ~= x or x == math.huge or x == -math.huge then
    error("cannot encode a non-finite number in JSON", 0)
  end
  if math.type(x) == "integer" then
    return format("%d", x)
  end
  if x == math.floor(x) and math.abs(x) < 1e15 then
    return format("%.1f", x)
  end
  local s = format("%.14g", x)
  if tonumber(s) ~= x then s = format("%.17g", x) end
  return s
end

local function is_sequence(t)
  local n = #t
  if n == 0 then return false end
  local count = 0
  for k in pairs(t) do
    if math.type(k) ~= "integer" or k < 1 or k > n then return false end
    count = count + 1
  end
  return count == n
end

local function ordered_keys(t)
  local keys, seen = {}, {}
  local mt = getmetatable(t)
  local preferred = type(mt) == "table" and rawget(mt, "__keyorder") or nil
  if preferred then
    for _, k in ipairs(preferred) do
      if rawget(t, k) ~= nil and not seen[k] then
        keys[#keys + 1] = k
        seen[k] = true
      end
    end
  end
  local rest = {}
  for k in pairs(t) do
    if type(k) ~= "string" then
      error("JSON object keys must be strings (got " .. type(k) .. ")", 0)
    end
    if not seen[k] then rest[#rest + 1] = k end
  end
  sort(rest)
  for _, k in ipairs(rest) do keys[#keys + 1] = k end
  return keys
end

local function encode_value(value, indent, level, out, visiting)
  local kind = type(value)
  if value == json.null or value == nil then
    out[#out + 1] = "null"
  elseif kind == "boolean" then
    out[#out + 1] = value and "true" or "false"
  elseif kind == "number" then
    out[#out + 1] = encode_number(value)
  elseif kind == "string" then
    out[#out + 1] = encode_string(value)
  elseif kind == "table" then
    if visiting[value] then error("cannot encode a table that contains itself", 0) end
    visiting[value] = true
    local pad = indent and ("\n" .. string.rep(indent, level + 1)) or ""
    local close_pad = indent and ("\n" .. string.rep(indent, level)) or ""
    local mt = getmetatable(value)
    local as_array = mt == json.array_mt or (mt ~= json.object_mt and is_sequence(value))
    if as_array then
      if #value == 0 then
        out[#out + 1] = "[]"
      else
        out[#out + 1] = "["
        for i = 1, #value do
          if i > 1 then out[#out + 1] = "," end
          out[#out + 1] = pad
          encode_value(value[i], indent, level + 1, out, visiting)
        end
        out[#out + 1] = close_pad .. "]"
      end
    else
      local keys = ordered_keys(value)
      if #keys == 0 then
        out[#out + 1] = "{}"
      else
        out[#out + 1] = "{"
        for i, k in ipairs(keys) do
          if i > 1 then out[#out + 1] = "," end
          out[#out + 1] = pad .. encode_string(k) .. (indent and ": " or ":")
          encode_value(value[k], indent, level + 1, out, visiting)
        end
        out[#out + 1] = close_pad .. "}"
      end
    end
    visiting[value] = nil
  else
    error("cannot encode a " .. kind .. " in JSON", 0)
  end
end

--- Encodes a value. With `indent` (e.g. "  ") the output is pretty-printed.
-- Object keys come out in the order listed in the metatable field __keyorder,
-- then the rest sorted, so a rewritten file never reshuffles.
function json.encode(value, indent)
  local out = {}
  encode_value(value, indent, 0, out, {})
  return concat(out)
end

return json
