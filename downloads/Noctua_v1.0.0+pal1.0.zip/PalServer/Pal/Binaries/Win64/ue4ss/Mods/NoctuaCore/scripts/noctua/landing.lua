-- Noctua: finding a safe place to put a player down.
--
-- Pure geometry. The caller supplies trace(start, finish), a line trace against
-- world geometry only (terrain and buildings, not characters), returning nil for
-- no hit or { location = {x,y,z}, normal = {x,y,z}, start_penetrating = bool }.
-- Unreal units: centimetres, Z up.
--
-- A candidate spot is accepted only when:
--   1. nothing solid lies between the destination and the spot (no landing behind a wall);
--   2. a downward trace finds ground (no ground in range = void or unloaded terrain: refuse);
--   3. the ground is walkable (normal Z >= min_normal_z, about 45 degrees by default);
--   4. the ground is within max_rise above / max_drop below the destination;
--   5. the space above the ground is free for `headroom` (never inside rock or a roof).

local landing = {}

landing.DEFAULTS = {
  radius = 400,          -- outermost ring, cm
  first_ring = 150,      -- innermost ring, cm
  headroom = 220,        -- free height needed above the ground, cm
  probe_up = 250,        -- the downward trace starts this far above the destination height
  probe_down = 1500,     -- ...and ends this far below it
  max_rise = 400,
  max_drop = 800,
  min_normal_z = 0.7,
  chest = 100,           -- height of the wall-check line above the destination
  stand_offset = 100,    -- actor origin above the ground (capsule half height + margin)
  angles = 8,
}

local function with_defaults(opts)
  local o = {}
  for k, v in pairs(landing.DEFAULTS) do o[k] = v end
  for k, v in pairs(opts or {}) do o[k] = v end
  return o
end

local function vec(x, y, z) return { x = x, y = y, z = z } end

--- Candidate (x, y) offsets, nearest first, deterministic.
function landing.candidates(opts)
  local o = with_defaults(opts)
  local radii = {}
  local function add(r)
    r = math.floor(r + 0.5)
    if r > 0 and r <= o.radius then
      for _, existing in ipairs(radii) do if existing == r then return end end
      radii[#radii + 1] = r
    end
  end
  -- first ring, halfway, outer ring; nothing inside the first ring (the palbox or
  -- the target player stands there)
  local first = math.min(o.first_ring, o.radius)
  add(first)
  add((first + o.radius) / 2)
  add(o.radius)
  table.sort(radii)
  local out = {}
  for ring, r in ipairs(radii) do
    local count = o.angles + (ring - 1) * 4
    -- offset alternate rings by half a step so they do not line up
    local phase = (ring % 2 == 0) and (math.pi / count) or 0
    for i = 0, count - 1 do
      local a = phase + (2 * math.pi * i / count)
      out[#out + 1] = { dx = r * math.cos(a), dy = r * math.sin(a), ring = r }
    end
  end
  return out
end

--- Checks one spot. Returns the standing location or nil plus a reason.
function landing.check_spot(center, dx, dy, o, trace)
  local cx, cy, cz = center.x, center.y, center.z
  local sx, sy = cx + dx, cy + dy

  -- 1. wall between destination and spot
  if trace(vec(cx, cy, cz + o.chest), vec(sx, sy, cz + o.chest)) then
    return nil, "blocked"
  end
  -- 2. ground
  local hit = trace(vec(sx, sy, cz + o.probe_up), vec(sx, sy, cz - o.probe_down))
  if not hit then return nil, "no_ground" end
  if hit.start_penetrating then return nil, "inside_geometry" end
  local g = hit.location
  -- 3. slope (when the trace gives no normal, measure it from two nearby probes)
  local nz
  if hit.normal then
    nz = hit.normal.z
  else
    nz = landing.estimate_normal_z(g, center, o, trace)
    if nz == nil then return nil, "steep" end
  end
  if nz < o.min_normal_z then return nil, "steep" end
  -- 4. height window
  local rise = g.z - cz
  if rise > o.max_rise or -rise > o.max_drop then return nil, "height" end
  -- 5. headroom
  if trace(vec(g.x, g.y, g.z + 5), vec(g.x, g.y, g.z + o.headroom)) then
    return nil, "no_headroom"
  end
  return vec(g.x, g.y, g.z + o.stand_offset)
end

--- Upward component of the ground's normal at `g`, from the ground heights 30 cm
-- away along X and Y. nil when either probe finds no ground (treated as unsafe).
function landing.estimate_normal_z(g, center, o, trace)
  local step = 30
  local function height(x, y)
    local h = trace(vec(x, y, center.z + o.probe_up), vec(x, y, center.z - o.probe_down))
    if not h or h.start_penetrating then return nil end
    return h.location.z
  end
  local hx, hy = height(g.x + step, g.y), height(g.x, g.y + step)
  if hx == nil or hy == nil then return nil end
  local gx, gy = (hx - g.z) / step, (hy - g.z) / step
  return 1 / math.sqrt(1 + gx * gx + gy * gy)
end

--- Finds a standing location around `center`.
-- opts.allow_center: when every ring spot fails, return `center` itself (used for
-- /tpa, where the destination is a player who is standing there right now).
-- @return location, info  or  nil, reasons (table reason -> count)
function landing.find(center, opts, trace)
  local o = with_defaults(opts)
  local reasons = {}
  for _, c in ipairs(landing.candidates(o)) do
    local spot, why = landing.check_spot(center, c.dx, c.dy, o, trace)
    if spot then
      return spot, { ring = c.ring }
    end
    reasons[why] = (reasons[why] or 0) + 1
  end
  if o.allow_center then
    -- the target's own spot: fine while they stand near the ground, never mid-air (a glider, a
    -- flying mount), where the visitor would fall
    local below = trace(vec(center.x, center.y, center.z), vec(center.x, center.y, center.z - (o.center_max_height or 500)))
    if below then
      return vec(center.x, center.y, center.z), { ring = 0 }
    end
    reasons.airborne = (reasons.airborne or 0) + 1
  end
  return nil, reasons
end

function landing.distance(a, b)
  local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
  return math.sqrt(dx * dx + dy * dy + dz * dz)
end

return landing
