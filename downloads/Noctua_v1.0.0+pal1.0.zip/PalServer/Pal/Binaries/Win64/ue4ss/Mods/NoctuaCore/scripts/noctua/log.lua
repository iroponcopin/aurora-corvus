-- Noctua: levelled logging to the UE4SS log (UE4SS.log and the server console).
-- Never pass a raw chat line here: vanilla admin commands such as /AdminPassword
-- travel through the same chat hook, and their text must not reach any log.

local log = {}

local LEVELS = { debug = 10, info = 20, warn = 30, error = 40 }
local LABELS = { debug = "DEBUG", info = "INFO", warn = "WARN", error = "ERROR" }

local threshold = LEVELS.info
local sink = function(line) print(line) end
local recent, recent_max = {}, 30

--- Replaces the output function (main.lua installs the UE4SS one; tests capture lines).
function log.set_sink(fn)
  sink = fn
end

function log.set_level(name)
  local value = LEVELS[name]
  if value then
    threshold = value
    return true
  end
  return false
end

function log.level_names()
  return { "debug", "info", "warn", "error" }
end

--- Warnings and errors seen since start, newest last (for /noctua health).
function log.recent()
  local copy = {}
  for i, entry in ipairs(recent) do copy[i] = entry end
  return copy
end

local function emit(level, fmt, ...)
  if LEVELS[level] < threshold then return end
  local ok, message = pcall(string.format, fmt, ...)
  if not ok then
    message = tostring(fmt) .. " (log format error: " .. tostring(message) .. ")"
  end
  local line = "[NOCTUA] [" .. LABELS[level] .. "] " .. message
  if LEVELS[level] >= LEVELS.warn then
    recent[#recent + 1] = line
    if #recent > recent_max then table.remove(recent, 1) end
  end
  -- A failing sink must not take the caller down with it.
  pcall(sink, line)
end

function log.debug(fmt, ...) emit("debug", fmt, ...) end
function log.info(fmt, ...) emit("info", fmt, ...) end
function log.warn(fmt, ...) emit("warn", fmt, ...) end
function log.error(fmt, ...) emit("error", fmt, ...) end

--- Clears state between offline test cases.
function log._reset()
  threshold = LEVELS.info
  recent = {}
  sink = function(line) print(line) end
end

return log
