-- Noctua: the only file that touches Palworld and UE4SS (Claude.md line 3).
--
-- Every identifier below was read from the Palworld 1.0 reflection headers
-- (PalworldModdingKit, "Update 1.0" + "update_10_patch1") or from a working
-- UE4SS mod on 1.0.x; see docs/ENGINE_FACTS.md for the source of each one. None
-- of it has been run on a live server by this project yet (UNVERIFIED.md).
--
-- The rest of Noctua sees plain Lua tables:
--   player = { uid = "32 hex digits", name = "...", guid = {A,B,C,D},
--              controller = <APalPlayerController>, state = <APalPlayerState> }
-- The pawn is always re-read from the controller, because it changes on respawn.

local pal_api = {}

local G = _G         -- UE4SS globals; tests replace them with a mock (pal_api.init)
local log = nil

pal_api.SYMBOLS = {
  CHAT_RPC        = "/Script/Pal.PalPlayerController:EnterChat_Receive",
  UTILITY         = "/Script/Pal.Default__PalUtility",
  SEND_TO_PLAYER  = "/Script/Pal.PalUtility:SendSystemToPlayerChat",
  ANNOUNCE        = "/Script/Pal.PalUtility:SendSystemAnnounce",
  TELEPORT        = "/Script/Pal.PalUtility:TeleportAroundLoccation", -- sic: the game's spelling
  TELEPORT_ACTOR  = "/Script/Engine.Actor:K2_TeleportTo",
  IS_DEAD         = "/Script/Pal.PalPlayerState:IsPlayerDead",
  GET_CONTROLLER  = "/Script/Engine.PlayerState:GetPlayerController",
  PLAYER_STATE    = "/Script/Pal.PalPlayerState",
  BASE_MODEL      = "/Script/Pal.PalBaseCampModel",
  BASE_POINT      = "/Script/Pal.PalBuildObjectBaseCampPoint",
  GAME_STATE      = "/Script/Pal.PalGameStateInGame",
  MAX_PLAYERS     = "/Script/Pal.PalGameStateInGame:GetMaxPlayerNum",
  GET_LOCATION    = "/Script/Engine.Actor:K2_GetActorLocation",
  KSL             = "/Script/Engine.Default__KismetSystemLibrary",
  TRACE           = "/Script/Engine.KismetSystemLibrary:LineTraceSingleForObjects",
  FRAME_COUNT     = "/Script/Engine.KismetSystemLibrary:GetFrameCount",
  GPS             = "/Script/Engine.Default__GameplayStatics",
  REAL_TIME       = "/Script/Engine.GameplayStatics:GetRealTimeSeconds",
  WORLD_DELTA     = "/Script/Engine.GameplayStatics:GetWorldDeltaSeconds",
  HP_COMPONENT    = "/Script/Pal.PalCharacterParameterComponent",
  GET_HP          = "/Script/Pal.PalCharacterParameterComponent:GetHP",
  OPTION_SUBSYSTEM   = "/Script/Pal.PalOptionSubsystem",
  GET_WORLD_SETTINGS = "/Script/Pal.PalOptionSubsystem:GetOptionWorldSettings",
  GUILD_CAPACITY     = "/Script/Pal.PalGroupGuildBase:GetWorkerCapacityNum",
  GUILD_LEVEL        = "/Script/Pal.PalGroupGuildBase:GetBaseCampLevel",
  GET_GAME_SETTING   = "/Script/Pal.PalUtility:GetGameSetting",
  SET_TEMP_DIFF      = "/Script/Pal.PalMapObjectHatchingEggModel:SetTemperatureDiff",
  ADD_ITEM           = "/Script/Pal.PalPlayerInventoryData:AddItem_ServerInternal",
  GET_INVENTORY      = "/Script/Pal.PalPlayerState:GetInventoryData",
  UNSTUCK            = "/Script/Pal.PalPlayerController:TeleportToSafePoint_ToServer",
  CAPSULE_OVERLAP    = "/Script/Engine.KismetSystemLibrary:CapsuleOverlapActors",
  GET_SAVED_DIR      = "/Script/Engine.KismetSystemLibrary:GetProjectSavedDirectory",
  WORLD_DIR_NAME     = "/Script/Pal.PalGameStateInGame:GetWorldSaveDirectoryName",
  GET_SAVE_MANAGER   = "/Script/Pal.PalUtility:GetSaveGameManager",
  IS_AUTOSAVING      = "/Script/Pal.PalSaveGameManager:IsWorldAutoSaving",
  GET_INVADER_MANAGER = "/Script/Pal.PalUtility:GetInvaderManager",
  START_RAID         = "/Script/Pal.PalInvaderManager:StartInvaderMarchForBaseCamp",
}
local S = pal_api.SYMBOLS

--- What each feature needs. Order matters: a feature may depend on an earlier one.
pal_api.REQUIREMENTS = {
  { name = "chat",      needs = { S.CHAT_RPC, S.PLAYER_STATE } },
  { name = "messaging", needs = { S.UTILITY, S.SEND_TO_PLAYER } },
  { name = "players",   needs = { S.PLAYER_STATE, S.GET_CONTROLLER } },
  { name = "worldsettings", needs = { S.OPTION_SUBSYSTEM, S.GET_WORLD_SETTINGS } },
  { name = "basecap",   needs = { S.GUILD_CAPACITY, S.GUILD_LEVEL, "@players" } },
  { name = "gamesetting", needs = { S.UTILITY, S.GET_GAME_SETTING } },
  { name = "eggtemp",   needs = { S.SET_TEMP_DIFF } },
  { name = "trace",     needs = { S.KSL, S.TRACE, S.GET_LOCATION } },
  { name = "teleport",  needs = { S.UTILITY, S.TELEPORT, S.GET_LOCATION, "@trace" } },
  { name = "home",      needs = { S.BASE_MODEL, "@chat", "@messaging", "@players", "@teleport" } },
  { name = "tpa",       needs = { "@chat", "@messaging", "@players", "@teleport" } },
  { name = "stats",     needs = { "@chat", "@messaging", "@players" } },
  { name = "admin",     needs = { "@chat", "@messaging", S.PLAYER_STATE } },
  { name = "vitals",    needs = { S.HP_COMPONENT, S.GET_HP, S.IS_DEAD } },
  { name = "kit",       needs = { S.ADD_ITEM, S.GET_INVENTORY, "@chat", "@messaging", "@players" } },
  { name = "unstuck",   needs = { S.UNSTUCK, "@chat", "@messaging", "@players" } },
  { name = "embedded",  needs = { S.KSL, S.CAPSULE_OVERLAP, S.GET_LOCATION, "@players" } },
  { name = "backup",    needs = { S.KSL, S.GET_SAVED_DIR, S.GAME_STATE, S.WORLD_DIR_NAME } },
  { name = "raid",      needs = { S.GET_INVADER_MANAGER, S.START_RAID, S.BASE_MODEL, "@chat", "@messaging", "@players" } },
}

-- EObjectTypeQuery values: ObjectTypeQuery1 = WorldStatic, ObjectTypeQuery2 = WorldDynamic
-- (terrain and placed buildings; characters are Pawn and are not traced).
local OBJECT_TYPES_WORLD = { 0, 1 }
local DRAW_DEBUG_NONE = 0

local cache = {
  utility = nil, ksl = nil, gps = nil, game_state = nil, options = nil, game_setting = nil,
  states = {},            -- address -> APalPlayerState seen via NotifyOnNewObject / FindAllOf
  last_full_scan = -math.huge,
  bases = nil, bases_time = -math.huge,
  probe_done = {},
}

---------------------------------------------------------------------------
-- helpers
---------------------------------------------------------------------------

local function valid(obj)
  if obj == nil then return false end
  local ok, result = pcall(function() return obj:IsValid() end)
  return ok and result == true
end
pal_api.valid = valid

local function address(obj)
  local ok, a = pcall(function() return obj:GetAddress() end)
  if ok and a then return a end
  local ok2, name = pcall(function() return obj:GetFullName() end)
  return ok2 and name or tostring(obj)
end

local function u32(v)
  v = math.tointeger(v) or 0
  return v & 0xFFFFFFFF
end

--- FGuid (A, B, C, D int32) -> 32 upper-case hex digits, the form admins see in the game's logs.
function pal_api.guid_string(g)
  if g == nil then return nil end
  local ok, s = pcall(function()
    return string.format("%08X%08X%08X%08X", u32(g.A), u32(g.B), u32(g.C), u32(g.D))
  end)
  return ok and s or nil
end

--- A plain Lua copy of an FGuid, suitable for passing back as a UFunction parameter.
function pal_api.guid_copy(g)
  return { A = math.tointeger(g.A), B = math.tointeger(g.B), C = math.tointeger(g.C), D = math.tointeger(g.D) }
end

local function finite(x)
  return type(x) == "number" and x == x and x ~= math.huge and x ~= -math.huge
end

local function vec_from(v)
  if v == nil then return nil end
  local ok, x, y, z = pcall(function() return v.X, v.Y, v.Z end)
  if not ok or not (finite(x) and finite(y) and finite(z)) then return nil end
  return { x = x, y = y, z = z }
end

local function to_fvector(v)
  return { X = v.x, Y = v.y, Z = v.z }
end

--- Unreal yaw in degrees -> FQuat (rotation about +Z).
function pal_api.quat_from_yaw(yaw)
  local half = math.rad(yaw or 0) / 2
  return { X = 0.0, Y = 0.0, Z = math.sin(half), W = math.cos(half) }
end

local function to_string(value)
  if value == nil then return nil end
  if type(value) == "string" then return value end
  local ok, s = pcall(function() return value:ToString() end)
  if ok and type(s) == "string" then return s end
  return nil
end

--- Logs the first result of a runtime field read, so a renamed field shows up once in UE4SS.log.
local function probe(label, ok)
  if cache.probe_done[label] == nil then
    cache.probe_done[label] = ok
    if log then
      if ok then log.debug("probe %s: OK", label) else log.warn("probe %s: FAILED (renamed in a game update?)", label) end
    end
  end
end

local function cdo(slot, path)
  local obj = cache[slot]
  if valid(obj) then return obj end
  local ok, found = pcall(G.StaticFindObject, path)
  if ok and valid(found) then
    cache[slot] = found
    return found
  end
  cache[slot] = nil
  return nil
end

local function utility() return cdo("utility", S.UTILITY) end
local function ksl() return cdo("ksl", S.KSL) end
local function gps() return cdo("gps", S.GPS) end

local function game_state()
  if valid(cache.game_state) then return cache.game_state end
  local ok, gs = pcall(G.FindFirstOf, "PalGameStateInGame")
  if ok and valid(gs) then
    cache.game_state = gs
    return gs
  end
  return nil
end

--- A WorldContextObject for static library calls: the game state (an actor in the
-- game world), else the first World.
local function world_context()
  local gs = game_state()
  if gs then return gs end
  local ok, world = pcall(G.FindFirstOf, "World")
  if ok and valid(world) then return world end
  return nil
end

---------------------------------------------------------------------------
-- setup
---------------------------------------------------------------------------

--- env: table of UE4SS globals (defaults to _G); logger: noctua/log.lua
function pal_api.init(env, logger)
  G = env or _G
  log = logger
  cache = {
    utility = nil, ksl = nil, gps = nil, game_state = nil, options = nil, game_setting = nil,
    states = {}, last_full_scan = -math.huge,
    bases = nil, bases_time = -math.huge,
    probe_done = {},
  }
end

--- Does a UFunction / class / default object exist right now?
function pal_api.symbol_exists(path)
  local ok, obj = pcall(G.StaticFindObject, path)
  return ok and valid(obj)
end

--- Registers the chat hook. `on_chat(controller, text, category)` runs inside the
-- hook; it must only copy what it needs and return quickly.
-- With `suppress(text) -> bool`, a line for which it returns true is blanked
-- before the game handles it (experimental; see chat.hide_commands_experimental).
function pal_api.register_chat(on_chat, suppress)
  local ok, pre, post = pcall(G.RegisterHook, S.CHAT_RPC, function(ctx, message, category)
    local pc = ctx:get()
    local text = to_string(message:get())
    local cat = category and category:get() or nil
    if text == nil then return end
    on_chat(pc, text, cat)
    if suppress and suppress(text) then
      local blanked = pcall(function() message:set("") end)
      if not blanked and log then log.warn("could not blank a command line in the chat hook") end
    end
  end)
  if not ok then return false, tostring(pre) end
  return true, pre, post
end

--- Starts the game-thread ticker. Prefers LoopInGameThreadWithDelay (Palworld UE4SS
-- builds after 3.0.1); falls back to LoopAsync + ExecuteInGameThread (3.0.1).
-- Returns the method used.
function pal_api.start_ticker(ms, fn)
  if type(G.LoopInGameThreadWithDelay) == "function" then
    G.LoopInGameThreadWithDelay(ms, function()
      local ok, err = pcall(fn)
      if not ok and log then log.error("tick failed: %s", tostring(err)) end
    end)
    return "LoopInGameThreadWithDelay"
  end
  local busy = false
  G.LoopAsync(ms, function()
    if not busy then
      busy = true
      G.ExecuteInGameThread(function()
        local ok, err = pcall(fn)
        busy = false
        if not ok and log then log.error("tick failed: %s", tostring(err)) end
      end)
    end
    return false -- keep looping
  end)
  return "LoopAsync+ExecuteInGameThread"
end

--- Watches for new player states so joins are seen without scanning every object.
function pal_api.watch_players()
  if type(G.NotifyOnNewObject) ~= "function" then return false end
  local ok = pcall(G.NotifyOnNewObject, S.PLAYER_STATE, function(obj)
    -- The object is still being constructed: remember it, read it on a later tick.
    cache.states[address(obj)] = obj
  end)
  return ok
end

---------------------------------------------------------------------------
-- players
---------------------------------------------------------------------------

--- Builds a player record from a PalPlayerState; nil when it is not a connected player.
function pal_api.player_from_state(ps)
  if not valid(ps) then return nil end
  local ok_pc, pc = pcall(function() return ps:GetPlayerController() end)
  if not ok_pc or not valid(pc) then return nil end -- inactive copy of a player who left
  local ok_g, g = pcall(function() return ps.PlayerUId end)
  local uid = ok_g and pal_api.guid_string(g) or nil
  probe("PalPlayerState.PlayerUId", uid ~= nil)
  if uid == nil or uid == "00000000000000000000000000000000" then return nil end
  local name = nil
  local ok_n, n = pcall(function() return ps.PlayerNamePrivate end)
  if ok_n then name = to_string(n) end
  if name == nil then
    local ok_f, f = pcall(function() return ps:GetPlayerName() end)
    if ok_f then name = to_string(f) end
  end
  probe("PalPlayerState.PlayerNamePrivate", name ~= nil)
  return { uid = uid, name = name or "?", guid = pal_api.guid_copy(g), controller = pc, state = ps }
end

--- A stable key for a controller (used to count a player's queued lines inside the chat hook).
function pal_api.controller_key(pc)
  return address(pc)
end

--- The player behind a controller (the chat hook's `self`).
function pal_api.player_from_controller(pc)
  if not valid(pc) then return nil end
  local ok, ps = pcall(function() return pc.PlayerState end)
  if not ok or not valid(ps) then return nil end
  return pal_api.player_from_state(ps)
end

--- Connected players. Uses the states collected by watch_players() and rescans
-- every object at most once per `full_scan_seconds` (FindAllOf walks the whole
-- object array, which is slow on a big world).
function pal_api.players(now, full_scan_seconds)
  now = now or 0
  if now - cache.last_full_scan >= (full_scan_seconds or 30) then
    cache.last_full_scan = now
    local ok, all = pcall(G.FindAllOf, "PalPlayerState")
    if ok and type(all) == "table" then
      for _, ps in ipairs(all) do cache.states[address(ps)] = ps end
    end
  end
  local list, seen = {}, {}
  for key, ps in pairs(cache.states) do
    if not valid(ps) then
      cache.states[key] = nil
    else
      local p = pal_api.player_from_state(ps)
      if p and not seen[p.uid] then
        seen[p.uid] = true
        list[#list + 1] = p
      end
    end
  end
  table.sort(list, function(a, b) return a.uid < b.uid end)
  return list
end

function pal_api.force_rescan()
  cache.last_full_scan = -math.huge
end

local function pawn_of(p)
  if p == nil or not valid(p.controller) then return nil end
  local ok, pawn = pcall(function() return p.controller.Pawn end)
  if ok and valid(pawn) then return pawn end
  return nil
end
pal_api.pawn_of = pawn_of

function pal_api.location(p)
  local pawn = pawn_of(p)
  if not pawn then return nil end
  local ok, v = pcall(function() return pawn:K2_GetActorLocation() end)
  if not ok then return nil end
  return vec_from(v)
end

function pal_api.is_admin(p)
  if p == nil or not valid(p.controller) then return false end
  local ok, admin = pcall(function() return p.controller.bAdmin end)
  probe("PalPlayerController.bAdmin", ok and type(admin) == "boolean")
  return ok and admin == true
end

--- Current HP as a plain number, or nil when it cannot be read.
-- PalCharacterParameterComponent:GetHP() returns FFixedPoint64 { Value = int64 };
-- only the comparison between two samples matters here, so the raw value is used.
function pal_api.hp(p)
  local pawn = pawn_of(p)
  if not pawn then return nil end
  local ok, raw = pcall(function()
    local comp = pawn.CharacterParameterComponent
    local hp = comp:GetHP()
    if type(hp) == "number" then return hp end
    return hp.Value
  end)
  local value = ok and tonumber(raw) or nil
  probe("PalCharacterParameterComponent:GetHP", value ~= nil)
  return value
end

--- false when the game says the player is dead; nil when unknown.
function pal_api.is_alive(p)
  if p == nil or not valid(p.state) then return false end
  local ok, dead = pcall(function() return p.state:IsPlayerDead() end)
  if ok and type(dead) == "boolean" then return not dead end
  local pawn = pawn_of(p)
  if pawn then
    local ok2, dead2 = pcall(function() return pawn.CharacterParameterComponent:IsDead() end)
    if ok2 and type(dead2) == "boolean" then return not dead2 end
  end
  return nil
end

--- Capsule half height of the player's pawn, in cm (nil when unknown).
function pal_api.stand_offset(p)
  local pawn = pawn_of(p)
  if not pawn then return nil end
  local ok, h = pcall(function() return pawn.CapsuleComponent:GetScaledCapsuleHalfHeight() end)
  if ok and finite(h) and h > 0 then return h end
  return nil
end

---------------------------------------------------------------------------
-- messages
---------------------------------------------------------------------------

--- One line to one player's chat, as a system message.
function pal_api.send(p, text)
  local util, ctx = utility(), world_context()
  if not util or not ctx then error("PalUtility or world not available") end
  util:SendSystemToPlayerChat(ctx, text, { p.guid })
end

--- One line to everyone's chat, as a system message.
function pal_api.broadcast(text)
  local util, ctx = utility(), world_context()
  if not util or not ctx then error("PalUtility or world not available") end
  util:SendSystemAnnounce(ctx, text)
end

---------------------------------------------------------------------------
-- guild bases
---------------------------------------------------------------------------

local function base_models(now)
  if cache.bases and now - cache.bases_time < 5 then return cache.bases end
  local ok, all = pcall(G.FindAllOf, "PalBaseCampModel")
  cache.bases = (ok and type(all) == "table") and all or {}
  cache.bases_time = now
  return cache.bases
end

local function base_points()
  local ok, all = pcall(G.FindAllOf, "PalBuildObjectBaseCampPoint")
  return (ok and type(all) == "table") and all or {}
end

--- The player's guild bases: list of { id, location, actor } (actor = the palbox,
-- ignored by traces), or nil plus "no_guild".
function pal_api.guild_bases(p, now)
  if p == nil or not valid(p.state) then return nil, "no_player" end
  local ok_g, guild = pcall(function() return p.state.GuildBelongTo end)
  if not ok_g or not valid(guild) then return nil, "no_guild" end
  local wanted = {}
  local ok_ids = pcall(function()
    local ids = guild.BaseCampIds
    for i = 1, #ids do
      local e = ids[i]
      -- an element may arrive as the struct itself or wrapped (needing :get())
      local ok_get, inner = pcall(function() return e:get() end)
      if ok_get and inner ~= nil then e = inner end
      local s = pal_api.guid_string(e)
      if s then wanted[s] = true end
    end
  end)
  probe("PalGroupGuildBase.BaseCampIds", ok_ids)
  if not ok_ids then return nil, "no_guild" end

  local out = {}
  for _, model in ipairs(base_models(now or 0)) do
    if valid(model) then
      local ok_m, id, loc = pcall(function()
        return pal_api.guid_string(model.ID), vec_from(model.Transform.Translation)
      end)
      if ok_m and id and loc and wanted[id] then
        out[#out + 1] = { id = id, location = loc }
      end
    end
  end
  if #out > 0 then
    -- attach the palbox actor nearest to each base (within 10 m) so traces ignore it
    local points = base_points()
    for _, b in ipairs(out) do
      local best, best_d = nil, 1000
      for _, point in ipairs(points) do
        if valid(point) then
          local ok_l, v = pcall(function() return point:K2_GetActorLocation() end)
          local l = ok_l and vec_from(v) or nil
          if l then
            local dx, dy, dz = l.x - b.location.x, l.y - b.location.y, l.z - b.location.z
            local d = math.sqrt(dx * dx + dy * dy + dz * dz)
            if d < best_d then best, best_d = point, d end
          end
        end
      end
      b.actor = best
    end
  end
  return out
end

---------------------------------------------------------------------------
-- traces and teleport
---------------------------------------------------------------------------

--- Line trace against terrain and buildings. ignore: list of player records or
-- tables with `.actor`. Returns nil or { location, normal, start_penetrating }.
function pal_api.trace(a, b, ignore)
  local lib, ctx = ksl(), world_context()
  if not lib or not ctx then error("trace unavailable") end
  local actors = {}
  for _, item in ipairs(ignore or {}) do
    local actor = item.actor or pawn_of(item)
    if actor and valid(actor) then actors[#actors + 1] = actor end
  end
  local hit = {}
  local blocked = lib:LineTraceSingleForObjects(ctx, to_fvector(a), to_fvector(b), OBJECT_TYPES_WORLD,
    false, actors, DRAW_DEBUG_NONE, hit, true,
    { R = 0, G = 0, B = 0, A = 0 }, { R = 0, G = 0, B = 0, A = 0 }, 0.0)
  if not blocked or not hit.bBlockingHit then return nil end
  -- ImpactPoint / ImpactNormal are FVector_NetQuantize types; if their X, Y, Z do not
  -- come through, the hit point follows from Time (0..1 along the trace), and the
  -- normal is left unknown so landing.lua measures the slope itself.
  local loc = vec_from(hit.ImpactPoint) or vec_from(hit.Location)
  if loc == nil and finite(hit.Time) and hit.Time >= 0 and hit.Time <= 1 then
    loc = { x = a.x + (b.x - a.x) * hit.Time, y = a.y + (b.y - a.y) * hit.Time, z = a.z + (b.z - a.z) * hit.Time }
  end
  probe("FHitResult.ImpactPoint", loc ~= nil)
  if loc == nil then return nil end
  local normal = vec_from(hit.ImpactNormal) or vec_from(hit.Normal)
  probe("FHitResult.ImpactNormal", normal ~= nil)
  return { location = loc, normal = normal, start_penetrating = hit.bStartPenetrating == true }
end

--- Asks the game to move the player's character. Returns true when the call was
-- accepted (the move itself may land on a later frame; teleport.lua checks arrival),
-- or false plus a reason.
--   attempt 1: PalUtility.TeleportAroundLoccation, the game's own placement call
--              that the working 1.0 admin mods use;
--   attempt 2: Actor.K2_TeleportTo, the engine's generic teleport.
function pal_api.teleport(p, loc, yaw, attempt)
  local pawn = pawn_of(p)
  if not pawn then return false, "no character" end
  if (attempt or 1) == 1 then
    local util = utility()
    if not util then return false, "PalUtility missing" end
    local accepted = util:TeleportAroundLoccation(pawn, to_fvector(loc), pal_api.quat_from_yaw(yaw))
    if accepted == false then return false, "TeleportAroundLoccation returned false" end
    return true
  end
  local accepted = pawn:K2_TeleportTo(to_fvector(loc), { Pitch = 0.0, Yaw = yaw or 0.0, Roll = 0.0 })
  if accepted == false then return false, "K2_TeleportTo returned false" end
  return true
end

---------------------------------------------------------------------------
-- server numbers
---------------------------------------------------------------------------

function pal_api.max_players()
  local gs = game_state()
  if not gs then return nil end
  local ok, n = pcall(function() return gs:GetMaxPlayerNum() end)
  if ok and type(n) == "number" and n > 0 then return n end
  local ok2, m = pcall(function() return gs.MaxPlayerNum end)
  if ok2 and type(m) == "number" and m > 0 then return m end
  return nil
end

--- Engine frame counter (for the TPS average), or nil.
function pal_api.frame_count()
  local lib = ksl()
  if not lib then return nil end
  local ok, n = pcall(function() return lib:GetFrameCount() end)
  if ok and type(n) == "number" then return n end
  return nil
end

--- Seconds of real time since the world started, or nil.
function pal_api.real_time()
  local lib, ctx = gps(), world_context()
  if not lib or not ctx then return nil end
  local ok, t = pcall(function() return lib:GetRealTimeSeconds(ctx) end)
  if ok and finite(t) then return t end
  return nil
end

---------------------------------------------------------------------------
-- world settings, guild capacity, level-table probe (Phase 3)
---------------------------------------------------------------------------

local function option_subsystem()
  if valid(cache.options) then return cache.options end
  local ok, sub = pcall(G.FindFirstOf, "PalOptionSubsystem")
  if ok and valid(sub) then
    cache.options = sub
    return sub
  end
  cache.options = nil
  return nil
end

--- One field of the game's world settings (the struct the ini file and WorldOption.sav
-- feed), or nil plus a reason.
function pal_api.world_setting_read(name)
  local sub = option_subsystem()
  if not sub then return nil, "the options subsystem was not found" end
  local ok, v = pcall(function() return sub.OptionWorldSettings[name] end)
  probe("PalOptionSubsystem.OptionWorldSettings." .. name, ok and v ~= nil)
  if not ok or v == nil then return nil, "the field " .. name .. " could not be read" end
  return v
end

--- Writes one field in place, in the live struct and in the cache copy the game may restore
-- it from. The caller reads it back: a write that only changed a copy is not a write.
function pal_api.world_setting_write(name, value)
  local sub = option_subsystem()
  if not sub then return false, "the options subsystem was not found" end
  local main_ok = pcall(function() sub.OptionWorldSettings[name] = value end)
  if not main_ok then return false, "the write to OptionWorldSettings raised an error" end
  local cache_ok = pcall(function() sub.OptionWorldSettingsCache[name] = value end)
  return true, cache_ok and "live struct and cache" or "live struct only"
end

--- The guild's base level and worker cap, from the game's own function.
function pal_api.worker_capacity(p)
  if p == nil or not valid(p.state) then return nil, "no player" end
  local ok, level, cap = pcall(function()
    local guild = p.state.GuildBelongTo
    if not valid(guild) then error("the player has no guild object", 0) end
    local lv = guild:GetBaseCampLevel()
    return lv, guild:GetWorkerCapacityNum(lv)
  end)
  probe("PalGroupGuildBase:GetWorkerCapacityNum", ok and type(cap) == "number")
  if not ok then return nil, tostring(level) end
  if type(cap) ~= "number" then return nil, "the game returned no number" end
  return level, cap
end

-- Field names a base-level row might carry; read one by one (a missing one just reads nil).
local LEVEL_ROW_CANDIDATES = { "WorkerMaxNum", "WorkerMax", "WorkerCapacityNum", "BaseCampWorkerMaxNum",
  "BaseCampMaxNumInGuild", "Level", "BaseCampLevel", "Exp", "RequiredExp" }

local function plain(v)
  local t = type(v)
  if t == "number" or t == "boolean" or t == "string" then return v end
  return nil
end

--- Read-only fact-finder for the base-level data table (where the per-level worker cap
-- lives). Logs what it can learn; changes nothing. Returns info, or nil plus a reason.
function pal_api.probe_level_table()
  local ok, all = pcall(G.FindAllOf, "DataTable")
  if not ok or type(all) ~= "table" then return nil, "no data tables found" end
  local target, target_name
  for _, tbl in ipairs(all) do
    local ok_n, name = pcall(function() return tbl:GetFullName() end)
    if ok_n and type(name) == "string" and name:find("BaseCamp", 1, true) and name:find("Level", 1, true) then
      target, target_name = tbl, name
      break
    end
  end
  if not target then return nil, string.format("no BaseCamp level table among %d data tables", #all) end

  local count = 0
  local ok_c, err_c = pcall(function() target:ForEachRow(function() count = count + 1 end) end)
  if not ok_c then return nil, "ForEachRow failed: " .. tostring(err_c) end

  local wanted = { [1] = true, [math.max(1, (count + 1) // 2)] = true, [count] = true }
  local info = { name = target_name, rows = count, samples = {}, fields = nil }
  local index = 0
  pcall(function()
    target:ForEachRow(function(row_name, row)
      index = index + 1
      if not wanted[index] then return end
      local sample = { row = to_string(row_name) or tostring(row_name), values = {} }
      for _, field in ipairs(LEVEL_ROW_CANDIDATES) do
        local ok_v, v = pcall(function() return row[field] end)
        if ok_v and plain(v) ~= nil then sample.values[field] = v end
      end
      if info.fields == nil and type(row.ForEachProperty) == "function" then
        local names = {}
        pcall(function()
          row:ForEachProperty(function(prop)
            local ok_p, nm = pcall(function() return prop:GetFName():ToString() end)
            if ok_p then names[#names + 1] = nm end
          end)
        end)
        if #names > 0 then info.fields = names end
      end
      info.samples[#info.samples + 1] = sample
    end)
  end)
  return info
end

---------------------------------------------------------------------------
-- game-setting object (arrays such as the passive inheritance weights)
---------------------------------------------------------------------------

local function game_setting()
  if valid(cache.game_setting) then return cache.game_setting end
  local util, ctx = utility(), world_context()
  if not util or not ctx then return nil end
  local ok, gs = pcall(function() return util:GetGameSetting(ctx) end)
  if ok and valid(gs) then
    cache.game_setting = gs
    return gs
  end
  return nil
end

local function array_length(arr)
  local ok, n = pcall(function() return #arr end)
  if ok and math.type(n) == "integer" then return n end
  local ok2, n2 = pcall(function() return arr:GetArrayNum() end)
  if ok2 and math.type(n2) == "integer" then return n2 end
  return nil
end

--- A field of UPalGameSetting: a number, a boolean, or an array read into a plain list.
function pal_api.game_setting_read(name)
  local gs = game_setting()
  if not gs then return nil, "the game-setting object was not found" end
  local ok, v = pcall(function() return gs[name] end)
  if not ok or v == nil then return nil, "the field " .. name .. " could not be read" end
  if type(v) == "number" or type(v) == "boolean" then return v end
  local n = array_length(v)
  if n == nil then return nil, "the field " .. name .. " is not a list or a number" end
  local out = {}
  for i = 1, n do
    local ok_i, x = pcall(function() return v[i] end)
    if not ok_i or type(x) ~= "number" then return nil, "element " .. i .. " of " .. name .. " could not be read" end
    out[i] = x
  end
  probe("PalGameSetting." .. name, true)
  return out
end

--- Writes a number, or a list element by element (the list must have the game's own length).
function pal_api.game_setting_write(name, value)
  local gs = game_setting()
  if not gs then return false, "the game-setting object was not found" end
  if type(value) ~= "table" then
    local ok = pcall(function() gs[name] = value end)
    if not ok then return false, "the write raised an error" end
    return true, "game-setting object"
  end
  local ok_a, arr = pcall(function() return gs[name] end)
  if not ok_a or arr == nil then return false, "the field " .. name .. " could not be read" end
  local n = array_length(arr)
  if n ~= #value then
    return false, string.format("the game's list has %s entries, the setting has %d", tostring(n), #value)
  end
  for i = 1, n do
    local ok = pcall(function() arr[i] = value[i] end)
    if not ok then return false, "element " .. i .. " could not be written" end
  end
  return true, "game-setting object, element by element"
end

---------------------------------------------------------------------------
-- eggs: incubator temperature counts as the best band
---------------------------------------------------------------------------

--- Hooks SetTemperatureDiff on the incubator model so a temperature difference of 0
-- (the game's fastest band) is used whatever the surroundings are. `enabled()` is asked
-- on every call, so /noctua reload takes effect without registering again.
-- Returns ok, ids_or_reason.
function pal_api.register_optimal_temperature(enabled, on_result)
  local ok, pre, post = pcall(G.RegisterHook, S.SET_TEMP_DIFF, function(_ctx, diff)
    if not enabled() then return end
    local set_ok = pcall(function() diff:set(0) end)
    local now_value
    if set_ok then
      local got_ok, got = pcall(function() return diff:get() end)
      if got_ok then now_value = got end
    end
    -- the value the game will see: 0 when the write reached the parameter
    if on_result then on_result(set_ok and now_value == 0, set_ok, now_value) end
  end)
  if not ok then return false, tostring(pre) end
  return true, { pre, post }
end

---------------------------------------------------------------------------
-- items
---------------------------------------------------------------------------

local function inventory_of(p)
  if p == nil or not valid(p.state) then return nil end
  local ok, inv = pcall(function() return p.state:GetInventoryData() end)
  if ok and valid(inv) then return inv end
  return nil
end

local function count_item(inv, name)
  local ok, n = pcall(function() return inv:CountItemNum(name) end)
  if ok and math.type(n) == "integer" then return n end
  if ok and type(n) == "number" then return math.floor(n) end
  return nil
end

--- Gives `count` of item `id` to the player and MEASURES the result: the number of that item
-- in the inventory before and after. Returns { code = number|nil, given = number|nil } or nil, reason.
-- code: the game's EPalItemOperationResult (0 = success, 15 = unknown item, 16 = no room).
function pal_api.give_item(p, id, count)
  local inv = inventory_of(p)
  if not inv then return nil, "the player's inventory was not found" end
  local ok_n, name = pcall(G.FName, id)
  if not ok_n then return nil, "FName failed" end
  local before = count_item(inv, name)
  local ok, code = pcall(function() return inv:AddItem_ServerInternal(name, count, false, 0.0, true) end)
  if not ok then return nil, tostring(code) end
  local after = count_item(inv, name)
  local given = nil
  if before ~= nil and after ~= nil then given = math.max(0, after - before) end
  probe("PalPlayerInventoryData:AddItem_ServerInternal", type(code) == "number")
  return { code = type(code) == "number" and code or nil, given = given }
end

---------------------------------------------------------------------------
-- stuck players
---------------------------------------------------------------------------

--- The game's own "unstuck": move the player to the nearest safe point. Returns true or false, reason.
function pal_api.unstuck(p)
  if p == nil or not valid(p.controller) then return false, "no controller" end
  local ok, err = pcall(function() p.controller:TeleportToSafePoint_ToServer(true) end)
  if not ok then return false, tostring(err) end
  return true
end

local EMBED_SHRINK_CM = 10 -- the capsule is made this much smaller so standing on ground never counts

--- Is the player's capsule (made slightly smaller) overlapping terrain or buildings?
-- true = embedded, false = free, nil = the check could not be made.
function pal_api.embedded(p)
  local pawn = pawn_of(p)
  local lib, ctx = ksl(), world_context()
  if not pawn or not lib or not ctx then return nil end
  local loc = pal_api.location(p)
  if not loc then return nil end
  local ok_r, radius, half = pcall(function()
    local cap = pawn.CapsuleComponent
    return cap:GetScaledCapsuleRadius(), cap:GetScaledCapsuleHalfHeight()
  end)
  if not ok_r or not finite(radius) or not finite(half) or radius <= EMBED_SHRINK_CM or half <= EMBED_SHRINK_CM then
    return nil
  end
  local out = {}
  local ok, hit = pcall(function()
    return lib:CapsuleOverlapActors(ctx, to_fvector(loc), radius - EMBED_SHRINK_CM, half - EMBED_SHRINK_CM,
      OBJECT_TYPES_WORLD, nil, { pawn }, out)
  end)
  probe("KismetSystemLibrary:CapsuleOverlapActors", ok)
  if not ok then return nil end
  if hit == true then return true end
  return #out > 0
end

---------------------------------------------------------------------------
-- raids (an admin starts one on the nearest base, to see the game's own raid)
---------------------------------------------------------------------------

--- The base camp nearest to the player: { id, guid, distance } (cm) or nil plus a reason.
function pal_api.nearest_base(p, now)
  local loc = pal_api.location(p)
  if not loc then return nil, "the player's position is unknown" end
  local best
  for _, model in ipairs(base_models(now or 0)) do
    if valid(model) then
      local ok, id_text, guid, where = pcall(function()
        return pal_api.guid_string(model.ID), pal_api.guid_copy(model.ID), vec_from(model.Transform.Translation)
      end)
      if ok and id_text and where then
        local dx, dy, dz = where.x - loc.x, where.y - loc.y, where.z - loc.z
        local d = math.sqrt(dx * dx + dy * dy + dz * dz)
        if best == nil or d < best.distance then best = { id = id_text, guid = guid, distance = d } end
      end
    end
  end
  if not best then return nil, "no base camp exists" end
  return best
end

--- Asks the game's invader manager to march a raid on that base camp (FGuid as a plain table).
function pal_api.start_raid(guid)
  local util, ctx = utility(), world_context()
  if not util or not ctx then return false, "PalUtility or world not available" end
  local ok, manager = pcall(function() return util:GetInvaderManager(ctx) end)
  if not ok or not valid(manager) then return false, "the invader manager was not found" end
  local ok2, err = pcall(function() manager:StartInvaderMarchForBaseCamp(guid) end)
  if not ok2 then return false, tostring(err) end
  return true
end

---------------------------------------------------------------------------
-- saving and the world folder
---------------------------------------------------------------------------

--- true / false while the game says whether a world save is running, nil when it cannot tell.
function pal_api.is_saving()
  local util, ctx = utility(), world_context()
  if not util or not ctx then return nil end
  local ok, manager = pcall(function() return util:GetSaveGameManager(ctx) end)
  if not ok or not valid(manager) then return nil end
  local ok2, saving = pcall(function() return manager:IsWorldAutoSaving() end)
  if ok2 and type(saving) == "boolean" then return saving end
  return nil
end

--- The running world's save folder, or nil plus a reason. Level.sav must exist there.
function pal_api.world_folder()
  local lib, gs = ksl(), game_state()
  if not lib or not gs then return nil, "the game is not ready" end
  local ok_d, dir = pcall(function() return to_string(lib:GetProjectSavedDirectory()) end)
  if not ok_d or type(dir) ~= "string" or dir == "" then return nil, "the saved-data folder is unknown" end
  local ok_w, world = pcall(function() return to_string(gs:GetWorldSaveDirectoryName()) end)
  if not ok_w or type(world) ~= "string" or world == "" then return nil, "the world folder name is unknown" end
  dir = dir:gsub("\\", "/"):gsub("/+$", "")
  local path = dir .. "/SaveGames/0/" .. world
  local h = io.open(path .. "/Level.sav", "rb")
  if not h then return nil, "Level.sav was not found in " .. path end
  h:close()
  return path
end

--- Size of a file in bytes, or nil.
function pal_api.file_size(path)
  local h = io.open(path, "rb")
  if not h then return nil end
  local size = h:seek("end")
  h:close()
  return size
end

function pal_api.world_delta()
  local lib, ctx = gps(), world_context()
  if not lib or not ctx then return nil end
  local ok, dt = pcall(function() return lib:GetWorldDeltaSeconds(ctx) end)
  if ok and finite(dt) and dt > 0 then return dt end
  return nil
end

return pal_api
