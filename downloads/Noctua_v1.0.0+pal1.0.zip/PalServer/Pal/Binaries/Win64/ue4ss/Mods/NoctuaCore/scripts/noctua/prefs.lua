-- Noctua: per-player preferences (for now only the /lang choice), kept in
-- Mods/NoctuaCore/data/players.json. File name and fields are frozen once shipped.
--
-- { "format": 1, "players": { "<PlayerUId>": { "lang": "en", "kits": { "starter": ["PalSphere:10"] } } } }
-- "kits" lists the items of each kit that were already handed to that player, so a kit
-- is never given twice, and a partly delivered kit (full inventory) is finished later.
-- "partial" remembers how many of an item arrived before the inventory was full.

local json = require("noctua.json")

local prefs = {}

local Store = {}
Store.__index = Store

function prefs.new(fs, path, log)
  return setmetatable({ fs = fs, path = path, log = log, players = {} }, Store)
end

function Store:load()
  local was_locked = self.locked
  self.locked = false
  self.warned_locked = false
  local text, err, used = self.fs.read(self.path)
  if text == nil then
    self.players = {}
    if self.fs.exists(self.path) then
      -- present but unreadable (permissions, a sharing violation): do not mistake it for a first
      -- run, or the next save would replace everyone's choices and kits would be handed out again
      self.locked = true
      if not was_locked then -- a retry that fails again stays quiet
        self.log.error("%s exists but could not be read (%s); nothing is saved and no kit is given until it can be read",
          self.path, tostring(err))
      end
      return false
    end
    return true -- first run: nothing saved yet
  end
  if used then
    self.log.warn("%s was missing; recovered it from %s", self.path, used)
  end
  local doc, perr = json.decode(text)
  if type(doc) ~= "table" or type(doc.players) ~= "table" then
    -- Not decodable: keep a copy, and do NOT carry on as if nobody had ever chosen or claimed anything
    -- (every kit could be claimed again, and the next save would replace the file). Fix or restore the
    -- file, then /noctua reload; the mod also looks again every 5 minutes.
    self.players = {}
    self.locked = true
    if not was_locked then
      local keep = self.path .. ".unreadable-" .. os.date("!%Y%m%d-%H%M%S")
      self.fs.write_atomic(keep, text)
      self.log.error("%s could not be read (%s); a copy was kept as %s. Nothing is saved and no kit is given until the "
        .. "file is fixed or removed (then /noctua reload)", self.path, tostring(perr or "no players object"), keep)
    end
    return false
  end
  local players = {}
  for uid, entry in pairs(doc.players) do
    if type(uid) == "string" and uid:match("^[%x%-]+$") and type(entry) == "table" then
      local rec = {}
      if entry.lang == "ja" or entry.lang == "en" then rec.lang = entry.lang end
      if type(entry.kits) == "table" then
        for kit, list in pairs(entry.kits) do
          if type(kit) == "string" and kit:match("^[a-z][a-z0-9_]*$") and #kit <= 32 and type(list) == "table" then
            local clean = {}
            for _, item in ipairs(list) do
              if type(item) == "string" and item:match("^[A-Za-z][A-Za-z0-9_]*:[1-9]%d*$") then clean[#clean + 1] = item end
            end
            rec.kits = rec.kits or {}
            rec.kits[kit] = clean
          end
        end
      end
      if type(entry.partial) == "table" then
        for kit, map in pairs(entry.partial) do
          if type(kit) == "string" and kit:match("^[a-z][a-z0-9_]*$") and #kit <= 32 and type(map) == "table" then
            for id, n in pairs(map) do
              if type(id) == "string" and id:match("^[A-Za-z][A-Za-z0-9_]*$") and math.type(n) == "integer" and n > 0 and n < 10000 then
                rec.partial = rec.partial or {}
                rec.partial[kit] = rec.partial[kit] or {}
                rec.partial[kit][id] = n
              end
            end
          end
        end
      end
      if rec.lang or rec.kits or rec.partial then players[uid] = rec end
    end
  end
  self.players = players
  return true
end

--- False while the saved file could not be read (saving now would overwrite it with an empty list)
-- and while the last save failed (what is in memory is not on disk yet).
function Store:writable()
  return not self.locked and not self.dirty
end

--- Tries to write the current state; used to check that a kit's record can be kept BEFORE it is handed out.
function Store:probe()
  return self:save()
end

--- Retries a failed save. Returns true when there was something to retry and it worked now.
function Store:flush()
  if self.dirty and not self.locked then
    return self:save() == true
  end
  return false
end

function Store:save()
  if self.locked then
    if not self.warned_locked then
      self.warned_locked = true
      self.log.warn("not saving %s: it exists but could not be read, and it must not be overwritten", self.path)
    end
    return false
  end
  local out = {}
  for uid, entry in pairs(self.players) do
    local rec = setmetatable({}, { __keyorder = { "lang", "kits", "partial" } })
    rec.lang = entry.lang
    if entry.kits then
      local kits = setmetatable({}, json.object_mt)
      for kit, list in pairs(entry.kits) do kits[kit] = setmetatable({ table.unpack(list) }, json.array_mt) end
      rec.kits = kits
    end
    if entry.partial then
      local partial = setmetatable({}, json.object_mt)
      for kit, map in pairs(entry.partial) do
        local m = setmetatable({}, json.object_mt)
        for id, n in pairs(map) do m[id] = n end
        partial[kit] = m
      end
      rec.partial = partial
    end
    out[uid] = rec
  end
  local doc = setmetatable({ format = 1, players = setmetatable(out, json.object_mt) },
    { __keyorder = { "format", "players" } })
  local ok, err = self.fs.write_atomic(self.path, json.encode(doc, "  ") .. "\n")
  if not ok then
    self.log.warn("could not save %s: %s (it is tried again every minute)", self.path, tostring(err))
  end
  self.dirty = not ok
  return ok
end

function Store:language(uid)
  local entry = self.players[uid]
  return entry and entry.lang or nil
end

function Store:set_language(uid, lang)
  local rec = self.players[uid] or {}
  rec.lang = lang
  self.players[uid] = rec
  return self:save()
end

--- The items of `kit` already given to this player, as a set { ["PalSphere:10"] = true }.
function Store:kit_delivered(uid, kit)
  local set = {}
  local rec = self.players[uid]
  for _, item in ipairs(rec and rec.kits and rec.kits[kit] or {}) do set[item] = true end
  return set
end

--- How many of each item of `kit` already arrived in an interrupted delivery: { PalSphere = 4 }.
function Store:kit_partial(uid, kit)
  local out = {}
  local rec = self.players[uid]
  for id, n in pairs(rec and rec.partial and rec.partial[kit] or {}) do out[id] = n end
  return out
end

--- Sets (or, with n = nil, clears) the partly delivered amount of one item. Saves.
function Store:kit_partial_set(uid, kit, id, n)
  local rec = self.players[uid] or {}
  if n ~= nil then
    rec.partial = rec.partial or {}
    rec.partial[kit] = rec.partial[kit] or {}
    rec.partial[kit][id] = n
  elseif rec.partial and rec.partial[kit] then
    rec.partial[kit][id] = nil
    if next(rec.partial[kit]) == nil then rec.partial[kit] = nil end
    if next(rec.partial) == nil then rec.partial = nil end
  end
  if rec.lang == nil and rec.kits == nil and rec.partial == nil then
    self.players[uid] = nil
  else
    self.players[uid] = rec
  end
  return self:save()
end

--- Records delivered items (already saved when this returns true).
function Store:kit_mark(uid, kit, items)
  local rec = self.players[uid] or {}
  rec.kits = rec.kits or {}
  local list = rec.kits[kit] or {}
  local have = {}
  for _, item in ipairs(list) do have[item] = true end
  for _, item in ipairs(items) do
    if not have[item] then list[#list + 1] = item; have[item] = true end
  end
  rec.kits[kit] = list
  self.players[uid] = rec
  return self:save()
end

return prefs
