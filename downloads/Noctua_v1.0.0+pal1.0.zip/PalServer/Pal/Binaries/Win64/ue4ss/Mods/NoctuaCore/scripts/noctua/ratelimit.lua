-- Noctua: per-player token bucket for chat commands, and per-player cooldowns.
-- Pure logic: the caller passes the current time in seconds.

local ratelimit = {}

local Bucket = {}
Bucket.__index = Bucket

--- burst: tokens available at once; refill_seconds: time to earn one token back.
function ratelimit.new_bucket(burst, refill_seconds)
  return setmetatable({ burst = burst, refill = refill_seconds, state = {} }, Bucket)
end

function Bucket:configure(burst, refill_seconds)
  self.burst, self.refill = burst, refill_seconds
end

--- Spends one token for `key`. Returns allowed, first_refusal.
-- first_refusal is true only on the first refused command of a streak, so the
-- player is told once instead of being answered for every spammed line.
function Bucket:take(key, now)
  local s = self.state[key]
  if s == nil then
    s = { tokens = self.burst, stamp = now, warned = false }
    self.state[key] = s
  end
  local elapsed = now - s.stamp
  if elapsed > 0 then
    s.tokens = math.min(self.burst, s.tokens + elapsed / self.refill)
    s.stamp = now
  end
  if s.tokens >= 1 then
    s.tokens = s.tokens - 1
    s.warned = false
    return true, false
  end
  local first = not s.warned
  s.warned = true
  return false, first
end

function Bucket:forget(key)
  self.state[key] = nil
end

local Cooldowns = {}
Cooldowns.__index = Cooldowns

function ratelimit.new_cooldowns()
  return setmetatable({ until_time = {} }, Cooldowns)
end

local function slot(key, name)
  return tostring(key) .. "\0" .. tostring(name)
end

--- Seconds left for (key, name), or 0 when ready.
function Cooldowns:remaining(key, name, now)
  local t = self.until_time[slot(key, name)]
  if t == nil or t <= now then return 0 end
  return t - now
end

function Cooldowns:start(key, name, seconds, now)
  if seconds and seconds > 0 then
    self.until_time[slot(key, name)] = now + seconds
  end
end

function Cooldowns:clear(key, name)
  self.until_time[slot(key, name)] = nil
end

--- Drops expired entries so the table does not grow over a long uptime.
function Cooldowns:sweep(now)
  for k, t in pairs(self.until_time) do
    if t <= now then self.until_time[k] = nil end
  end
end

return ratelimit
