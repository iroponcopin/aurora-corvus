-- Noctua: the few operating-system commands the backup feature needs, built in one place.
--
-- Lua has no way to copy or list a folder, so this uses os.execute and io.popen (UE4SS
-- opens the whole standard library). Every path is checked by backup_plan.safe_path first
-- (absolute, no shell metacharacters, no ".."), and a folder is removed only if
-- backup_plan.is_inside says it is one of Noctua's own backup folders directly inside the
-- backup root. The runner is replaceable so the tests can watch the commands instead of
-- running them.
--
-- Windows (and Wine: package.config still says "\"): robocopy, dir, rmdir, mkdir.
-- Anything else: cp, ls, rm, mkdir.

local plan = require("noctua.backup_plan")

local shell = {}

--- The real runner: a wrapper around os.execute and io.popen that never throws.
shell.SYSTEM = {
  --- returns success (boolean), exit code (number or nil), and a note
  execute = function(command)
    if type(os.execute) ~= "function" then return false, nil, "os.execute is not available" end
    local ok, result, how, code = pcall(os.execute, command)
    if not ok then return false, nil, tostring(result) end
    -- Lua 5.4: os.execute returns true|nil, "exit"|"signal", code
    if how == "exit" and type(code) == "number" then return result == true, code, nil end
    return result == true, nil, tostring(how)
  end,
  --- returns a list of lines, or nil plus a note
  lines = function(command)
    if type(io.popen) ~= "function" then return nil, "io.popen is not available" end
    local ok, handle = pcall(io.popen, command, "r")
    if not ok or not handle then return nil, tostring(handle) end
    local out = {}
    for line in handle:lines() do
      line = line:gsub("\r$", "")
      if line ~= "" then out[#out + 1] = line end
    end
    handle:close()
    return out
  end,
}

local S = {}
S.__index = S

function shell.is_windows()
  return package.config:sub(1, 1) == "\\"
end

--- runner: { execute(cmd) -> ok, code, note ; lines(cmd) -> list | nil, note }
function shell.new(runner, windows)
  if windows == nil then windows = shell.is_windows() end
  return setmetatable({ run = runner or shell.SYSTEM, windows = windows }, S)
end

-- The native spelling of a normalised path ("D:/a/b" -> "D:\a\b" on Windows).
function S:native(path)
  if self.windows then return (path:gsub("/", "\\")) end
  return path
end

local function checked(path)
  local ok, p = plan.safe_path(path)
  if not ok then return nil, p end
  return p
end

--- Command builders (no side effects): returned so tests and logs can show them.
function S:copy_command(src, dst)
  local s, why = checked(src)
  if not s then return nil, "source: " .. why end
  local d, why2 = checked(dst)
  if not d then return nil, "destination: " .. why2 end
  if plan.overlaps(s, d) then return nil, "the source and destination folders overlap" end
  if self.windows then
    -- /E subfolders (also empty), retry once, no per-file listing; robocopy exits 0-7 on success
    return string.format('robocopy "%s" "%s" /E /R:1 /W:1 /NFL /NDL /NP /NJH /NJS >NUL 2>&1', self:native(s), self:native(d))
  end
  return string.format('mkdir -p "%s" && cp -a "%s/." "%s/" 2>&1', d, s, d)
end

function S:list_command(root)
  local r, why = checked(root)
  if not r then return nil, why end
  if self.windows then return string.format('dir /b /ad "%s" 2>NUL', self:native(r)) end
  return string.format('ls -1 "%s" 2>/dev/null', r)
end

function S:remove_command(root, dir)
  if not plan.is_inside(root, dir) then
    return nil, "refusing to remove a folder that is not one of Noctua's backup folders directly inside the backup folder"
  end
  local d = checked(dir)
  if self.windows then return string.format('rmdir /s /q "%s" >NUL 2>&1', self:native(d)) end
  return string.format('rm -rf "%s"', d)
end

function S:mkdir_command(dir)
  local d, why = checked(dir)
  if not d then return nil, why end
  if self.windows then
    return string.format('if not exist "%s\\" mkdir "%s" >NUL 2>&1', self:native(d), self:native(d))
  end
  return string.format('mkdir -p "%s"', d)
end

--- Copies the whole folder `src` into `dst`. Returns ok, note.
function S:copy_dir(src, dst)
  local cmd, why = self:copy_command(src, dst)
  if not cmd then return false, why end
  local ok, code, note = self.run.execute(cmd)
  if self.windows then
    -- robocopy: 0 = nothing to copy, 1 = copied, 2-3 = extras; 8 and above = a failure
    if code ~= nil and code < 8 then return true, "robocopy exit code " .. code end
    return false, code and ("robocopy exit code " .. code) or tostring(note)
  end
  if ok then return true end
  return false, code and ("cp exit code " .. code) or tostring(note)
end

--- Names of the folders directly inside `root`, or nil plus a reason.
function S:list(root)
  local cmd, why = self:list_command(root)
  if not cmd then return nil, why end
  local lines, note = self.run.lines(cmd)
  if lines == nil then return nil, note end
  return lines
end

function S:remove(root, dir)
  local cmd, why = self:remove_command(root, dir)
  if not cmd then return false, why end
  local ok, code, note = self.run.execute(cmd)
  if ok then return true end
  return false, code and ("exit code " .. code) or tostring(note)
end

function S:mkdir(dir)
  local cmd, why = self:mkdir_command(dir)
  if not cmd then return false, why end
  local ok, code, note = self.run.execute(cmd)
  if ok then return true end
  return false, code and ("exit code " .. code) or tostring(note)
end

return shell
