-- Noctua: server tick-rate measurement for /stats.
--
-- Preferred: frames counted by the engine (a running frame counter) divided by the
-- real time between two samples; that is an exact average, whatever the sampling rate.
-- Fallback: the average of 1 / (last frame's delta time) over the samples, which
-- only sees the frames that happen to be sampled.

local stats = {}

local Sampler = {}
Sampler.__index = Sampler

function stats.new_sampler(window_seconds)
  return setmetatable({ window = window_seconds, frames = {}, deltas = {} }, Sampler)
end

function Sampler:set_window(window_seconds)
  self.window = window_seconds
end

local function trim(list, now, window)
  -- keep one sample older than the window so the span can cover it fully
  while #list > 2 and list[2].t <= now - window do
    table.remove(list, 1)
  end
end

--- A frame-counter sample (engine frame number at time `now`).
function Sampler:add_frame_count(now, frame_count)
  if type(frame_count) ~= "number" or frame_count ~= frame_count then return end
  local last = self.frames[#self.frames]
  if last and now == last.t and frame_count >= last.v then
    return -- the same instant (a clock that only counts whole seconds): nothing new to add
  end
  if last and (now < last.t or frame_count < last.v) then
    -- clock or counter went backwards (world restart): start again
    self.frames = {}
  end
  self.frames[#self.frames + 1] = { t = now, v = frame_count }
  trim(self.frames, now, self.window)
end

--- A frame-time sample, in seconds.
function Sampler:add_delta(now, delta_seconds)
  if type(delta_seconds) ~= "number" or delta_seconds ~= delta_seconds or delta_seconds <= 0 then return end
  self.deltas[#self.deltas + 1] = { t = now, v = 1 / delta_seconds }
  while #self.deltas > 0 and self.deltas[1].t <= now - self.window do
    table.remove(self.deltas, 1)
  end
end

--- Average ticks per second over the window, or nil before enough samples exist.
-- Second value: "frames" or "deltas", naming the method used.
function Sampler:tps()
  local f = self.frames
  if #f >= 2 then
    local first, last = f[1], f[#f]
    local span = last.t - first.t
    if span >= 1 then
      return (last.v - first.v) / span, "frames"
    end
  end
  local d = self.deltas
  if #d >= 3 then
    local sum = 0
    for _, s in ipairs(d) do sum = sum + s.v end
    return sum / #d, "deltas"
  end
  return nil
end

--- Seconds covered by the current measurement (for "average over N s").
function Sampler:span()
  local f = self.frames
  if #f >= 2 then return f[#f].t - f[1].t end
  local d = self.deltas
  if #d >= 2 then return d[#d].t - d[1].t end
  return 0
end

return stats
