-- Noctua: deciding WHEN to rescue someone who looks stuck inside the terrain
-- (NOCTUA_INIT.md module E, "スタック救済"). Pure logic: the caller observes, this decides.
--
-- A single observation is never enough (a trace can flicker for one frame at a seam), so:
--   * a rescue needs `confirm` observations in a row, `interval` seconds apart or more;
--   * one good observation clears the count;
--   * after a rescue the player is left alone for `cooldown` seconds;
--   * at most `max_per_hour` rescues per player per hour, so a wrong detector can never
--     teleport someone in a loop (the count then stays as it is and the reason is reported);
--   * players in a state that makes the check meaningless (dead, mid-teleport) are skipped.

local stuck = {}

local T = {}
T.__index = T

--- params: { confirm = 3, interval = 5, cooldown = 60, max_per_hour = 4 } (see config: guardian.*)
function stuck.new(params)
  return setmetatable({ p = params, players = {} }, T)
end

function T:configure(params)
  self.p = params
end

local function record(self, uid)
  local r = self.players[uid]
  if r == nil then
    r = { count = 0, last_obs = nil, cooldown_until = 0, rescues = {}, blocked_reported = false }
    self.players[uid] = r
  end
  return r
end

--- One observation. `is_stuck` is true/false, or nil when the check could not be made
-- (treated as "not stuck" and not counted either way).
-- @return "rescue" | "wait" | "blocked" | "none"
--   rescue:  move this player now (the caller then calls rescued())
--   blocked: the hourly limit stops a rescue that would otherwise happen
function T:observe(uid, is_stuck, now)
  local r = record(self, uid)
  if now < r.cooldown_until then return "none" end
  if is_stuck == nil then return "none" end
  if not is_stuck then
    r.count = 0
    r.last_obs = nil
    r.blocked_reported = false
    return "none"
  end
  -- observations closer together than `interval` are the same observation
  if r.last_obs ~= nil and now - r.last_obs < self.p.interval then return "wait" end
  r.last_obs = now
  r.count = r.count + 1
  if r.count < self.p.confirm then return "wait" end
  -- confirmed: check the hourly limit
  local recent = {}
  for _, when in ipairs(r.rescues) do
    if now - when < 3600 then recent[#recent + 1] = when end
  end
  r.rescues = recent
  if #recent >= self.p.max_per_hour then return "blocked" end
  return "rescue"
end

--- Whether the "blocked" outcome was already reported for this streak (report it once).
function T:mark_blocked_reported(uid)
  local r = record(self, uid)
  local first = not r.blocked_reported
  r.blocked_reported = true
  return first
end

--- The caller moved the player (or tried and failed: pass ok = false to retry later
-- without counting it against the hourly limit).
function T:rescued(uid, ok, now)
  local r = record(self, uid)
  r.count = 0
  r.last_obs = nil
  r.blocked_reported = false
  if ok then
    r.rescues[#r.rescues + 1] = now
    r.cooldown_until = now + self.p.cooldown
  else
    r.cooldown_until = now + self.p.interval
  end
end

function T:forget(uid)
  self.players[uid] = nil
end

function T:count(uid)
  local r = self.players[uid]
  return r and r.count or 0
end

return stuck
