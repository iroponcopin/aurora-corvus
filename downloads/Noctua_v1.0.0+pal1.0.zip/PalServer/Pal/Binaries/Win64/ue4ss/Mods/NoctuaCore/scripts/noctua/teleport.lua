-- Noctua: teleport warmups, cancellation and the "recently hurt" lockout.
--
-- Engine-free: the manager talks to the game only through the `api` table it is
-- given (location, hp, is_alive, teleport), so the offline tests drive it with a
-- fake world. The ticker calls tick(now, roster) on the game thread.

local landing = require("noctua.landing")

local teleport = {}

-- The game's placement call can move the character on a later frame, so arrival is
-- checked on the following ticks. A call that is accepted but does not move the
-- character within VERIFY_SECONDS is retried with the next method; after
-- MAX_ATTEMPTS the teleport is reported as failed (never as done).
teleport.ARRIVE_CM = 1500
teleport.VERIFY_SECONDS = 2.0
teleport.MAX_ATTEMPTS = 2

local Manager = {}
Manager.__index = Manager

--- api: { location(p), hp(p), is_alive(p), teleport(p, loc, yaw, attempt) }
-- options(): returns { cancel_move_distance_cm, cancel_on_damage }
function teleport.new(api, options)
  return setmetatable({
    api = api,
    options = options,
    tickets = {},     -- uid -> ticket
    last_hp = {},     -- uid -> last HP sample
    last_hurt = {},   -- uid -> time HP last dropped
  }, Manager)
end

function Manager:pending(uid)
  return self.tickets[uid] ~= nil
end

-- Arrived = within ARRIVE_CM of the destination and within half the distance the
-- teleport had to cover, so a short hop is never "confirmed" by a character who
-- did not move. A destination already within 2 m counts as reached.
local function arrived(loc, dest, from)
  if loc == nil then return false end
  local tolerance = teleport.ARRIVE_CM
  if from then
    local span = landing.distance(from, dest)
    if span <= 200 then return true end
    tolerance = math.min(tolerance, span / 2)
  end
  return landing.distance(loc, dest) <= tolerance
end

-- Tries the next teleport method(s) until one is accepted. Returns true when the
-- ticket is now waiting for arrival.
function Manager:launch(ticket, player, now, errors)
  ticket.launch_loc = ticket.launch_loc or self.api.location(player)
  while ticket.attempt < teleport.MAX_ATTEMPTS do
    ticket.attempt = ticket.attempt + 1
    local ok_tp, accepted, tp_err = pcall(self.api.teleport, player, ticket.dest, ticket.yaw, ticket.attempt)
    if ok_tp and accepted then
      ticket.phase = "arriving"
      ticket.verify_until = now + teleport.VERIFY_SECONDS
      return true
    end
    errors[#errors + 1] = string.format("teleport method %d refused: %s", ticket.attempt,
      ok_tp and tostring(tp_err or "refused") or tostring(accepted))
  end
  return false
end

--- Starts a warmup. `resolve(player)` runs when it completes and returns
-- location, yaw  or  nil, message_key, params. `done(ok, message_key, params)`
-- reports the outcome (message_key nil on success).
function Manager:begin(player, kind, warmup_seconds, now, resolve, done)
  local uid = player.uid
  if self.tickets[uid] then
    return false, "tp_already_pending"
  end
  local origin = self.api.location(player)
  if origin == nil then
    return false, "tp_failed"
  end
  self.tickets[uid] = {
    uid = uid,
    kind = kind,
    phase = "warmup",
    attempt = 0,
    fires_at = now + math.max(0, warmup_seconds or 0),
    origin = origin,
    hp = self.api.hp(player),
    resolve = resolve,
    done = done,
  }
  return true
end

function Manager:cancel(uid, message_key)
  local ticket = self.tickets[uid]
  if ticket then
    self.tickets[uid] = nil
    if message_key then
      pcall(ticket.done, false, message_key)
    end
  end
  return ticket
end

--- Records an HP sample; a drop marks the player as hurt at `now`.
function Manager:observe_hp(uid, hp, now)
  if hp == nil then return end
  local previous = self.last_hp[uid]
  if previous ~= nil and hp < previous - 1e-3 then
    self.last_hurt[uid] = now
  end
  self.last_hp[uid] = hp
end

--- Seconds of lockout left after the player was last hurt (0 = free to go).
function Manager:hurt_remaining(uid, lockout_seconds, now)
  local t = self.last_hurt[uid]
  if t == nil or lockout_seconds <= 0 then return 0 end
  local left = (t + lockout_seconds) - now
  return left > 0 and left or 0
end

function Manager:forget(uid)
  self.tickets[uid] = nil
  self.last_hp[uid] = nil
  self.last_hurt[uid] = nil
end

local function finish(ticket, ok, key, params)
  local success, err = pcall(ticket.done, ok, key, params)
  if not success then return err end
end

--- Advances every warmup. roster: uid -> current player handle (online players).
-- Returns a list of error strings from callbacks (for the log), usually empty.
function Manager:tick(now, roster)
  local errors = {}
  local opts = self.options()
  -- Snapshot first: a callback may start a new warmup, and adding keys to a table
  -- while pairs() walks it is undefined behaviour in Lua.
  local uids = {}
  for uid in pairs(self.tickets) do uids[#uids + 1] = uid end
  table.sort(uids)
  for _, uid in ipairs(uids) do
    local ticket = self.tickets[uid]
    local player = roster[uid]
    if ticket == nil then
      -- cancelled by an earlier callback in this same tick
    elseif player == nil then
      -- left the server: drop quietly, nobody to tell
      self.tickets[uid] = nil
    elseif ticket.phase == "arriving" then
      if arrived(self.api.location(player), ticket.dest, ticket.launch_loc) then
        self.tickets[uid] = nil
        errors[#errors + 1] = finish(ticket, true, nil, ticket.params)
      elseif now >= ticket.verify_until then
        errors[#errors + 1] = string.format("teleport method %d was accepted but the character did not arrive within %.1f s",
          ticket.attempt, teleport.VERIFY_SECONDS)
        if not self:launch(ticket, player, now, errors) then
          self.tickets[uid] = nil
          errors[#errors + 1] = finish(ticket, false, "tp_failed")
        end
      end
    else
      local reason
      local alive = self.api.is_alive(player)
      local loc = self.api.location(player)
      if alive == false or loc == nil then
        reason = "tp_cancel_invalid"
      elseif opts.cancel_move_distance_cm > 0
          and landing.distance(loc, ticket.origin) > opts.cancel_move_distance_cm then
        reason = "tp_cancel_moved"
      elseif opts.cancel_on_damage then
        local hp = self.api.hp(player)
        if hp ~= nil and ticket.hp ~= nil and hp < ticket.hp - 1e-3 then
          reason = "tp_cancel_damaged"
        elseif hp ~= nil then
          -- healing during the warmup raises the bar; any later drop still cancels
          ticket.hp = math.max(ticket.hp or hp, hp)
        end
      end

      if reason then
        self.tickets[uid] = nil
        errors[#errors + 1] = finish(ticket, false, reason)
      elseif now >= ticket.fires_at then
        local ok_resolve, dest, yaw_or_key, params = pcall(ticket.resolve, player)
        if not ok_resolve then
          self.tickets[uid] = nil
          errors[#errors + 1] = tostring(dest)
          errors[#errors + 1] = finish(ticket, false, "tp_failed")
        elseif dest == nil then
          self.tickets[uid] = nil
          errors[#errors + 1] = finish(ticket, false, yaw_or_key or "tp_failed", params)
        else
          ticket.dest, ticket.yaw, ticket.params = dest, yaw_or_key, params
          if not self:launch(ticket, player, now, errors) then
            self.tickets[uid] = nil
            errors[#errors + 1] = finish(ticket, false, "tp_failed")
          end
        end
      end
    end
  end
  local out = {}
  for _, e in ipairs(errors) do if e ~= nil then out[#out + 1] = e end end
  return out
end

return teleport
