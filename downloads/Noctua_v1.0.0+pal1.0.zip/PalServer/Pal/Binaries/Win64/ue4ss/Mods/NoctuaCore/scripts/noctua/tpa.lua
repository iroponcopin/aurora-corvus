-- Noctua: /tpa request book-keeping. Pure logic; the caller passes the time.
--
-- A request is { requester = uid, target = uid, created = t, expires = t }.
-- Each requester has at most one outgoing request (a new one replaces it).
-- Each target holds at most `max_incoming` requests.

local tpa = {}

local Book = {}
Book.__index = Book

function tpa.new(timeout_seconds, max_incoming)
  return setmetatable({
    timeout = timeout_seconds,
    max_incoming = max_incoming,
    outgoing = {}, -- requester uid -> request
  }, Book)
end

function Book:configure(timeout_seconds, max_incoming)
  self.timeout, self.max_incoming = timeout_seconds, max_incoming
end

--- Requests addressed to `target`, newest first. With `now`, requests that have expired
-- (whether or not the periodic sweep has removed them yet) are left out.
function Book:incoming(target, now)
  local list = {}
  for _, req in pairs(self.outgoing) do
    if req.target == target and (now == nil or req.expires > now) then list[#list + 1] = req end
  end
  table.sort(list, function(a, b)
    if a.created ~= b.created then return a.created > b.created end
    return a.requester < b.requester
  end)
  return list
end

function Book:outgoing_of(requester)
  return self.outgoing[requester]
end

--- Files a request. Returns ok, reason_or_request, replaced_request.
-- reasons: "self", "target_busy", "duplicate"
function Book:send(requester, target, now)
  if requester == target then
    return false, "self"
  end
  local previous = self.outgoing[requester]
  if previous and previous.target == target and previous.expires > now then
    -- Same request again: refresh the timer instead of spamming the target.
    previous.expires = now + self.timeout
    return false, "duplicate", nil
  end
  local waiting = 0
  for _, req in pairs(self.outgoing) do
    if req.target == target and req.requester ~= requester then waiting = waiting + 1 end
  end
  if waiting >= self.max_incoming then
    return false, "target_busy"
  end
  local req = { requester = requester, target = target, created = now, expires = now + self.timeout }
  self.outgoing[requester] = req
  if previous and previous.target ~= target then
    return true, req, previous
  end
  return true, req, nil
end

--- Removes and returns the request `target` answers.
-- With `requester` nil and exactly one request pending, that one is taken.
-- Returns request, or nil plus reason "none" | "ambiguous" | "not_found" (and the list).
function Book:take(target, requester, now)
  local list = self:incoming(target, now)
  if #list == 0 then
    return nil, "none", list
  end
  local chosen
  if requester == nil then
    if #list > 1 then return nil, "ambiguous", list end
    chosen = list[1]
  else
    for _, req in ipairs(list) do
      if req.requester == requester then chosen = req break end
    end
    if chosen == nil then return nil, "not_found", list end
  end
  self.outgoing[chosen.requester] = nil
  return chosen
end

--- Withdraws the requester's own request.
function Book:cancel(requester)
  local req = self.outgoing[requester]
  self.outgoing[requester] = nil
  return req
end

--- Removes every expired request and returns them (oldest first).
function Book:expire(now)
  local expired = {}
  for requester, req in pairs(self.outgoing) do
    if req.expires <= now then
      expired[#expired + 1] = req
      self.outgoing[requester] = nil
    end
  end
  table.sort(expired, function(a, b)
    if a.created ~= b.created then return a.created < b.created end
    return a.requester < b.requester
  end)
  return expired
end

--- Removes every request that involves `uid` (a player left). Returns them.
function Book:drop_player(uid)
  local dropped = {}
  for requester, req in pairs(self.outgoing) do
    if req.requester == uid or req.target == uid then
      dropped[#dropped + 1] = req
      self.outgoing[requester] = nil
    end
  end
  table.sort(dropped, function(a, b) return a.requester < b.requester end)
  return dropped
end

function Book:count()
  local n = 0
  for _ in pairs(self.outgoing) do n = n + 1 end
  return n
end

return tpa
