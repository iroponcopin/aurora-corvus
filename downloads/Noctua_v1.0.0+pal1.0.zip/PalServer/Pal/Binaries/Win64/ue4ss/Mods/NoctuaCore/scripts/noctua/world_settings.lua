-- Noctua: keeps a few of the game's rule settings at the values the admin chose
-- (NOCTUA_INIT.md modules A, B and E).
--
--   source "world" = the game's world-settings struct (what the ini file and WorldOption.sav feed):
--     base.worker_max                    -> BaseCampWorkerMaxNum                 (worker Pals per base)
--     base.disable_decay                 -> BuildObjectDeteriorationDamageRate   (0 = no decay outside a base)
--     breeding.egg_hatch_enabled/_hours  -> PalEggDefaultHatchingTime            (hours for the biggest egg)
--     guardian.autosave_minutes          -> autoSaveSpan                         (seconds; the header spells it with a small a)
--   source "game" = the game-setting object (UPalGameSetting):
--     breeding.passive_inherit_weights   -> Combi_PassiveInheritNum              (weights for inheriting 1..4 passives)
--
-- The spec's own route for the worker cap (hooking GetMaxBaseCampWorkerSlots / GetMaxWorkerPalNum)
-- is not possible: neither function exists in Palworld 1.0. Noctua writes the values at run time,
-- reads them back to prove the write took, writes them again if the game puts the old value back,
-- and puts the game's own value back when the admin switches a setting off.
--
-- Engine-free: `apis` = { world = api, game = api }, each api = { read(name) -> value | nil, reason ;
-- write(name, value) -> ok, note }. A value is a number, a boolean, or a list of numbers.
-- `available(source)` says whether the game functions for that source exist (health check).

local ws = {}

local FIELDS = {
  {
    name = "BaseCampWorkerMaxNum", source = "world",
    desired = function(st)
      local n = st.base.worker_max
      if n > 0 then return n end
      return nil
    end,
  },
  {
    name = "BuildObjectDeteriorationDamageRate", source = "world",
    desired = function(st)
      if st.base.disable_decay then return 0.0 end
      return nil
    end,
  },
  {
    name = "PalEggDefaultHatchingTime", source = "world",
    desired = function(st)
      if st.breeding.egg_hatch_enabled then return st.breeding.egg_hatch_hours + 0.0 end
      return nil
    end,
  },
  {
    name = "autoSaveSpan", source = "world",
    desired = function(st)
      local m = st.guardian.autosave_minutes
      if m > 0 then return m * 60.0 end
      return nil
    end,
  },
  {
    name = "RarePal_AppearanceProbability", source = "game",
    desired = function(st)
      local v = st.encounter.rare_pal_probability
      if v >= 0 then return v + 0.0 end
      return nil
    end,
  },
  {
    name = "PredatorPal_AppearanceProbability", source = "game",
    desired = function(st)
      local v = st.encounter.predator_probability
      if v >= 0 then return v + 0.0 end
      return nil
    end,
  },
  {
    name = "InvadeProbability", source = "game",
    desired = function(st)
      local v = st.raid.probability
      if v >= 0 then return v + 0.0 end
      return nil
    end,
  },
  {
    name = "InvadeJudgmentInterval_Minutes", source = "game",
    desired = function(st)
      local v = st.raid.judgment_interval_minutes
      if v >= 0 then return v end
      return nil
    end,
  },
  {
    name = "InvadeCollTime_Min_Minutes", source = "game",
    desired = function(st)
      local v = st.raid.cooldown_min_minutes
      if v >= 0 then return v end
      return nil
    end,
  },
  {
    name = "InvadeCollTime_Max_Minutes", source = "game",
    desired = function(st)
      local v = st.raid.cooldown_max_minutes
      if v >= 0 then return v end
      return nil
    end,
  },
  {
    name = "Combi_PassiveInheritNum", source = "game",
    desired = function(st)
      local w = st.breeding.passive_inherit_weights
      if #w == 0 then return nil end
      local copy = {}
      for i, v in ipairs(w) do copy[i] = v end
      return copy
    end,
  },
}

-- read for the log and the admin only, never written
local OBSERVED = { "bAutoResetGuildNoOnlinePlayers", "AutoResetGuildTimeNoOnlinePlayers", "EnablePredatorBossPal",
  "bEnableInvaderEnemy" }

ws.MANAGED_NAMES = {}
for _, f in ipairs(FIELDS) do ws.MANAGED_NAMES[#ws.MANAGED_NAMES + 1] = f.name end
ws.OBSERVED_NAMES = OBSERVED

local UNAVAILABLE_RETRY_SECONDS = 5
local FLAP_LIMIT = 5          -- this many resets ...
local FLAP_WINDOW = 3600      -- ... within this many seconds count as a game that keeps resetting it

local function same(a, b)
  if type(a) == "table" or type(b) == "table" then
    if type(a) ~= "table" or type(b) ~= "table" or #a ~= #b then return false end
    for i = 1, #a do
      if not same(a[i], b[i]) then return false end
    end
    return true
  end
  if type(a) == "number" and type(b) == "number" then
    -- the game stores many of these as 32-bit floats: 100.1 reads back as 100.0999984741. A relative
    -- tolerance (about 1e-6, far above float32's 6e-8) accepts that, and still tells 29 from 30.
    return math.abs(a - b) <= 1e-6 + 1e-6 * math.max(math.abs(a), math.abs(b))
  end
  return a == b
end
ws.same = same

local function show(v)
  if v == nil then return "?" end
  if type(v) == "table" then
    local parts = {}
    for i, x in ipairs(v) do parts[i] = show(x) end
    return "[" .. table.concat(parts, ", ") .. "]"
  end
  if math.type(v) == "integer" then return string.format("%d", v) end
  if type(v) == "number" then return string.format("%g", v) end
  return tostring(v)
end
ws.show = show

local function copy(v)
  if type(v) ~= "table" then return v end
  local out = {}
  for i, x in ipairs(v) do out[i] = x end
  return out
end

local W = {}
W.__index = W

--- apis: { world = api, game = api } (or a single api, used for both)
function ws.new(apis, settings_fn, log, available)
  if apis.read then apis = { world = apis, game = apis } end
  local self = setmetatable({ apis = apis, settings = settings_fn, log = log, fields = {}, observed = {}, next_at = nil,
    announced = false, available = available or function() return true end }, W)
  for _, f in ipairs(FIELDS) do
    self.fields[#self.fields + 1] = {
      name = f.name, source = f.source, desired_fn = f.desired, state = "off", actual = nil, original = nil,
      established = false, changed = false, writes = 0, reverts = 0, why = nil, tried = false,
      flap_warned = false, last_failure = nil, revert_times = {}, last_desired = nil,
    }
  end
  return self
end

function W:_announce_if_ready()
  if self.announced then return end
  -- one attempt at every field is enough: a field that cannot be read is shown as "?"
  for _, f in ipairs(self.fields) do
    if self.available(f.source) and not f.tried then return end
  end
  self.announced = true
  local parts = {}
  for _, f in ipairs(self.fields) do
    -- f.original is what the game used before Noctua wrote anything; f.actual may be Noctua's own value
    if self.available(f.source) then parts[#parts + 1] = f.name .. "=" .. show(f.original) end
  end
  for _, name in ipairs(OBSERVED) do
    if self.observed[name] ~= nil then parts[#parts + 1] = name .. "=" .. show(self.observed[name]) end
  end
  self.log.info("game settings the game started with: %s", table.concat(parts, ", "))
  -- a setting the admin asked for that the game's own switch makes pointless
  local function managed(name)
    for _, f in ipairs(self.fields) do
      if f.name == name and f.desired_fn(self.settings()) ~= nil then return true end
    end
    return false
  end
  if self.observed.EnablePredatorBossPal == false and managed("PredatorPal_AppearanceProbability") then
    self.log.warn("encounter.predator_probability is set, but EnablePredatorBossPal is False in the game's settings, "
      .. "so no Predator Pals will appear")
  end
  if self.observed.bEnableInvaderEnemy == false and (managed("InvadeProbability") or managed("InvadeJudgmentInterval_Minutes")
      or managed("InvadeCollTime_Min_Minutes") or managed("InvadeCollTime_Max_Minutes")) then
    self.log.warn("the raid settings are set, but bEnableInvaderEnemy is False in the game's settings, so no raids will happen")
  end
  if self.observed.bAutoResetGuildNoOnlinePlayers == true then
    self.log.warn("bAutoResetGuildNoOnlinePlayers is on: the game deletes a guild's bases after %s hours with nobody online "
      .. "(a game setting, not Noctua; turn it off in PalWorldSettings.ini if that is not wanted)",
      show(self.observed.AutoResetGuildTimeNoOnlinePlayers))
  end
end

--- Returns true when a setting Noctua is asked to manage could not be read (retry sooner).
function W:_handle(f, now)
  local desired = f.desired_fn(self.settings())
  -- the admin changed what Noctua should hold (an edit + /noctua reload): what follows is a new
  -- setting, not the game resetting the old one
  if not same(f.last_desired, desired) then
    f.established, f.revert_times, f.flap_warned = false, {}, false
  end
  f.last_desired = copy(desired)
  if not self.available(f.source) then
    f.state, f.why = "missing", "the game functions for this setting were not found"
    if desired ~= nil and f.last_failure ~= f.why then
      f.last_failure = f.why
      self.log.warn("%s cannot be managed: %s", f.name, f.why)
    end
    return false
  end
  local api = self.apis[f.source]
  local actual, why = api.read(f.name)
  f.tried = true
  if actual == nil then
    f.state, f.why = "unavailable", why
    -- only a setting the admin asked for is worth retrying every few seconds
    return desired ~= nil
  end
  f.actual = copy(actual)
  if f.original == nil then f.original = copy(actual) end

  if desired == nil then
    if f.changed and not same(actual, f.original) then
      local ok = api.write(f.name, copy(f.original))
      local after = api.read(f.name)
      if ok and same(after, f.original) then
        self.log.info("%s put back to the game's own value %s (Noctua no longer manages it)", f.name, show(f.original))
        f.actual = copy(after)
      else
        self.log.warn("%s could not be put back to %s; a server restart restores the game's own value", f.name,
          show(f.original))
      end
    end
    f.changed, f.established, f.state, f.why = false, false, "off", nil
    return false
  end

  if same(actual, desired) then
    f.state, f.why, f.last_failure = "ok", nil, nil
    f.established = true
    return false
  end

  -- the game uses another value: write ours, then read it back
  local ok, note = api.write(f.name, copy(desired))
  local after = api.read(f.name)
  if ok and same(after, desired) then
    f.writes = f.writes + 1
    f.changed = true
    f.actual, f.state, f.why, f.last_failure = copy(after), "ok", nil, nil
    if f.established then
      f.reverts = f.reverts + 1
      if f.reverts == 1 or f.reverts % 10 == 0 then
        self.log.warn("the game put %s back to %s; Noctua wrote %s again (%d time(s) so far)", f.name, show(actual),
          show(desired), f.reverts)
      end
      -- only resets close together mean something keeps resetting it
      local recent = {}
      for _, when in ipairs(f.revert_times) do
        if now - when < FLAP_WINDOW then recent[#recent + 1] = when end
      end
      recent[#recent + 1] = now
      f.revert_times = recent
      if #recent >= FLAP_LIMIT and not f.flap_warned then
        f.flap_warned = true
        self.log.warn("something keeps resetting %s (WorldOption.sav or another mod?); Noctua keeps writing it back", f.name)
      elseif #recent < FLAP_LIMIT then
        f.flap_warned = false
      end
    else
      self.log.info("%s changed from %s to %s (%s)", f.name, show(actual), show(desired), tostring(note))
    end
    f.established = true
  else
    f.state = "failed"
    f.why = ok and "the write did not stick (the game still reports the old value)" or tostring(note)
    f.actual = copy(after or actual)
    if f.last_failure ~= f.why then
      f.last_failure = f.why
      self.log.warn("could not set %s to %s: %s", f.name, show(desired), f.why)
    end
  end
  return false
end

--- Runs on the game thread from the ticker; does its work only when due.
function W:tick(now)
  if self.next_at and now < self.next_at then return end
  local retry_soon = false
  for _, f in ipairs(self.fields) do
    local ok, waiting = pcall(self._handle, self, f, now)
    if not ok then
      f.state, f.why = "failed", tostring(waiting)
      self.log.error("game settings: %s", tostring(waiting))
    elseif waiting then
      retry_soon = true
    end
  end
  if self.available("world") then
    for _, name in ipairs(OBSERVED) do
      if self.observed[name] == nil then
        local ok, v = pcall(self.apis.world.read, name)
        if ok and v ~= nil then self.observed[name] = v end
      end
    end
  end
  self:_announce_if_ready()
  local wait = retry_soon and UNAVAILABLE_RETRY_SECONDS or self.settings().base.reassert_seconds
  self.next_at = now + wait
end

--- Makes the next tick check at once (after /noctua reload changed the settings).
function W:recheck()
  self.next_at = nil
end

--- For /noctua base: one entry per managed setting.
function W:status()
  local out = {}
  for _, f in ipairs(self.fields) do
    out[#out + 1] = {
      name = f.name, source = f.source, desired = f.desired_fn(self.settings()), actual = f.actual, state = f.state,
      why = f.why, writes = f.writes, reverts = f.reverts,
    }
  end
  return { fields = out, observed = self.observed }
end

return ws
