# Noctua

The studio's Palworld brand: a server-only mod. Players install nothing (NOCTUA_INIT.md §1). It runs in UE4SS Lua on the Palworld 1.0 dedicated server.

**Status:** V1.0.0 (see [CHANGELOG.md](CHANGELOG.md)). Released on the owner's decision **without a test on a live server**: it has only been verified offline. The five modules of NOCTUA_INIT.md are built as far as they can be built and checked offline (details below); Phase 5's live checks (a vanilla client, 20 players) are still to do on a real server. **Nothing has run on a live server yet.** See [UNVERIFIED.md](UNVERIFIED.md) and [docs/LIVE_TEST_PLAN.md](docs/LIVE_TEST_PLAN.md).

## What is in it
| Module (spec) | Built | Not built |
|---|---|---|
| C, chat commands | `/help /home /tpa /tpaccept /tpdeny /tpcancel /stats /lang /kit starter /unstuck` and the admin `/noctua health\|base\|raid\|backup\|reload\|version` | |
| A, bases | worker-Pal cap and decay through the game's world settings (opt-in) | 50 workers (the game's level table stops at 30), slope/rock placement (no server setting) |
| B, breeding | egg hatching time, optimal incubator temperature, passive-inheritance weights (opt-in) | giving back a parent's lost passive (no hook exists) |
| D, encounters | Lucky/Predator odds and raid tuning through the game settings, `/noctua raid` | spawning apex Pals ourselves, custom raid compositions |
| E, guardian | autosave interval, verified scheduled backups, `/unstuck` and an opt-in automatic check | differential backups (every copy is complete instead), stuck Pals |

Every feature that changes a game rule is **off by default**. The reasons for each "not built" are in [docs/SERVER_SETUP_GUIDE.md](docs/SERVER_SETUP_GUIDE.md) and [docs/ENGINE_FACTS.md](docs/ENGINE_FACTS.md).

## Layout
```
PalServer/Pal/Binaries/Win64/ue4ss/Mods/NoctuaCore/   the mod, laid out as on the server
  enabled.txt
  scripts/main.lua                 bootstrap: config, health check, chat hook, ticker
  scripts/command_handler.lua      chat commands (module C, NoctuaCommandCore)
  scripts/noctua/pal_api.lua       the ONLY file that touches Palworld / UE4SS
  scripts/noctua/*.lua             json, config, i18n, log, fs, health, landing, teleport, tpa, ratelimit,
                                   stats, prefs, world_settings, stuck, backup, backup_plan, shell
  config/noctua_settings.example.json   the defaults (generated from the schema); the live noctua_settings.json is
                                   created on first start and is never part of a release
  data/                            players' saved choices and kit records (created at run time)
CHANGELOG.md                       what each version contains and what it does not
docs/SERVER_SETUP_GUIDE.md         admin guide (ja + en), with every setting
docs/ENGINE_FACTS.md               source of every game identifier used
docs/LIVE_TEST_PLAN.md             the order for the first live test
tests/                             offline suite: fake world + mock UE4SS
tools/                             check.sh (the gate), mutate.py, profile.lua, package.sh, verify_package*.py
UNVERIFIED.md                      what only a live server can prove
```

## Differences from NOCTUA_INIT.md, and why
- **Chat hook**: the spec's `PalPlayerController:SendChatMessage` does not exist in Palworld 1.0. The server RPC is `PalPlayerController:EnterChat_Receive(FString, uint8)`.
- **Blocking vanilla chat**: a UE4SS Lua hook cannot stop the original function, so the spec's `return true` does nothing. Blanking the parameter might work and is behind `chat.hide_commands_experimental` (off). `/` lines are already hidden from other players by the game, which answers "Unknown command." instead.
- **Mod folder**: the current Palworld build of UE4SS loads mods from `Win64/ue4ss/Mods`. It reads the spec's `Win64/Mods` only when `ue4ss/Mods` is absent (legacy 3.0.1), so the tree uses `ue4ss/Mods`. The guide covers both.
- **Worker-slot hook (module A sample)**: neither `PalBaseCampModel:GetMaxWorkerPalNum` nor `UPalGameSetting::GetMaxBaseCampWorkerSlots` exists in the 1.0 headers. Noctua writes the game's world settings instead and reads them back.
- **50 worker Pals is not delivered yet.** The game's per-level table (`DT_BaseCampLevelData`) stops at 30, so values above 30 are expected not to take effect. Noctua writes down that table's contents on the first live boot (a read-only probe) so the next step can be built on facts.
- **Incubator temperature (module B)**: there is no pass/fail check to make "optimal"; the game uses a speed multiplier. Noctua forces the temperature difference to 0 (the best band).
- **Passive inheritance (module B)**: no hook can restore a lost parent passive; only the weights for how many passives are inherited can be changed.
- **Apex Pals and raid waves (module D)**: the game's own Lucky/Predator odds and raid frequency can be tuned; Noctua does not spawn Pals itself or rewrite raid compositions (see the guide for the reasons).
- **Backups (module E)**: full, verified, independent copies instead of "differential" ones; the copy runs in a separate process so it never stalls the game.
- **Placement redlines (slopes, rock)**: no server setting relaxes them and placement is also checked on the client. Not implemented.

## Verify (offline)
```
tools/check.sh          # syntax of every .lua, the suite twice, and the per-tick cost; prints the verdict
lua tests/run.lua       # the suite once
python3 tools/mutate.py # planted defects: every one must turn the suite (or the profile gate) red at its own test
lua tools/profile.lua   # Noctua's own Lua per 250 ms tick with 1, 20 and 50 mock players (a lower bound)
tools/package.sh        # builds dist/Noctua_v<version>+pal1.0.zip after the gate and verifies every entry
python3 tools/verify_package_controls.py dist/<zip>   # the package verifier must fail on 6 kinds of damage
```
Needs Lua 5.4 (UE4SS's Palworld build uses 5.4.7) and, for `mutate.py` and the package tools, Python 3.

## Licence
MIT (LICENSE). Palworld is a trademark of its owner; Noctua is not affiliated with it.
