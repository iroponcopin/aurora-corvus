# What only a live server can prove / 実機でしか確かめられないこと

Noctua has been verified offline only: an automated test suite drives the real Lua code against a mock of UE4SS and a fake Palworld world. The mock follows the Palworld 1.0 headers (docs/ENGINE_FACTS.md), so it proves that Noctua calls the game the way the headers describe. It cannot prove how the game answers. Every item below needs a Palworld 1.0 dedicated server with UE4SS (Okaetsu's Palworld build) and at least one unmodded client. Tick an item only after seeing it happen.

Noctua はまだオフラインでしか検証していません。自動テストは本物の Lua コードを、UE4SS の模擬と Palworld の偽の世界に対して動かします。模擬は Palworld 1.0 のヘッダー（docs/ENGINE_FACTS.md）に沿っているので、Noctua がヘッダーのとおりにゲームを呼んでいることは確かめられます。ゲームがどう応えるかは確かめられません。以下の項目には、UE4SS（Okaetsu の Palworld 版）を入れた Palworld 1.0 の専用サーバーと、MOD を入れていないクライアントが 1 台以上要ります。チェックを付けるのは、実際に起きるのを見てからにしてください。

## Boot / 起動
- [ ] UE4SS.log shows `[NOCTUA] ... ready: 19/19 features on`. If any line says `MISSING`, a game update renamed that function; record which one.
- [ ] The log shows `ticker started every 250 ms (LoopInGameThreadWithDelay)`.
- [ ] On first boot `config/noctua_settings.json` is created, and it is never rewritten afterwards.
- [ ] `trace self-test: ground found ... cm below a player's position` appears within about 10 s of the first player spawning. If it says `no ground found`, the object-type indices {0, 1} are wrong for Palworld (ENGINE_FACTS.md).

## Chat / チャット
- [ ] `/tpcancel` from a vanilla client: the sender sees the game's "Unknown command." and then Noctua's reply. Nobody else sees either. Confirm who sees "Unknown command.".
- [ ] `!tpcancel`: Noctua replies, and the line also appears in everyone's chat. This is expected unless the next item works.
- [ ] `chat.hide_commands_experimental = true`: `/` commands no longer get "Unknown command.", `!` commands are not shown to others, and ordinary chat and the game's own admin commands still work. Watch for crashes. The write into the RPC's parameter is only inferred to work.
- [ ] Noctua's replies render correctly in the chat box: 【】 brackets, Japanese text, and line length on English and Japanese clients.
- [ ] Replies go only to the sender (SendSystemToPlayerChat with one FGuid).
- [ ] Japanese replies are not garbled. They depend on UE4SS turning a UTF-8 Lua string into an FString correctly. If they are garbled, `language: "en"` is the fallback (English replies are ASCII only), and this needs a fix.
- [ ] The log shows no `probe FHitResult.ImpactPoint: FAILED` or `probe FHitResult.ImpactNormal: FAILED`. If it does, UE4SS is not exposing FVector_NetQuantize fields. Noctua then works from `Time` and measured slopes: check that landings are still right.
- [ ] No other `probe ...: FAILED` line in the log (PlayerUId, PlayerNamePrivate, bAdmin, GetHP, BaseCampIds).

## /home
- [ ] A solo player (Unnamed Guild) with one base arrives beside the palbox, not inside it, not in the air, and takes no fall damage.
- [ ] With several bases, `/home list` distances look right and `/home 2` goes to the second base.
- [ ] Taking damage, then `/home` straight away, is refused with the time left, which shows HP polling works. Being hurt during the 5 s warmup cancels it.
- [ ] Moving more than 1.5 m during the warmup cancels it.
- [ ] Arrival is confirmed. If the log shows `method 1 was accepted but the character did not arrive`, write down whether method 2 (K2_TeleportTo) then worked, and whether the client snapped back.
- [ ] Mounted or gliding players: note what happens. Noctua does not dismount anyone yet.
- [ ] A base inside a cave or under an overhang: the landing spot is not on the rock above.

## /tpa
- [ ] Request, accept, 3 s warmup, and arrival beside the target on both clients. Check the target does not see the requester stuck inside them.
- [ ] Names with Japanese characters, names with spaces, and two players with the same name (the `name#abcd` form).
- [ ] The target logging out during the warmup: the requester is told and not moved.

## /stats
- [ ] Player count and maximum match the server settings. Uptime is plausible.
- [ ] Compare the TPS figure with the REST API `/v1/api/metrics` `serverfps`.

## Base settings / 拠点の設定（Phase 3）
- [ ] With `base.worker_max = 30`: the log shows `BaseCampWorkerMaxNum changed from 15 to 30`, and an admin's `/noctua base` shows "現在 30 / 目標 30 / 反映済み". If it shows "書き込めません", the write did not stick (the property write may only change a copy): note the exact log line.
- [ ] The number a player's base really allows changes (build up a base, or check the base screen on a vanilla client). `/noctua base` shows the game's own cap for the admin's guild (`GetWorkerCapacityNum`): does it follow the setting?
- [ ] With `base.worker_max = 50`: does the base still stop at 30? (The per-level table is expected to cap it. The `base-level table probe` lines in UE4SS.log, written 30 s after start, give the table's fields and sample rows for the next step.)
- [ ] A vanilla client's screen with more than 30 slots: does it show the slots, or something broken?
- [ ] With `base.disable_decay = true`: `BuildObjectDeteriorationDamageRate changed from 1 to 0` in the log, and structures outside a base stop losing HP over a day or two. The write only proves the number was stored. Whether the game re-reads it while running is not confirmed.
- [ ] `WorldOption.sav`: on a world that already has one, the value Noctua writes still wins after a restart, and there are no `the game put ... back` lines in the log (each one means something resets the setting).
- [ ] `/noctua reload` changes the values within a second (the next check is immediate).
- [ ] `bAutoResetGuildNoOnlinePlayers`: the start-up line says what the game uses.
- [ ] The performance cost of a higher worker count with 20 or more players.

## Kit, unstuck and chat robustness / キット、救済、チャットの堅牢性（Phase 2 の補足）
- [ ] `/kit starter` (with `commands.kit.enabled = true`): the five items appear in the inventory of a vanilla client, and `/kit starter` again says "already received". The count before and after is what Noctua trusts: check that the log has no `answered success ... but ... inventory did not grow` line.
- [ ] **A full inventory**: fill the inventory, run `/kit starter`. Note what happens: nothing arrives, a part arrives, or items drop on the ground? Noctua's bookkeeping assumes only what it measures.
- [ ] The starter items' ids exist in this version: no `the game does not know the item id` line in the log.
- [ ] `players.json` is written into `data/` (the folder must exist), and a restart does not give the kit a second time.
- [ ] `/unstuck` while stuck in terrain or a building: the player is moved to a safe point. Note what the game's own function does when the player is NOT stuck.
- [ ] `guardian.unstuck_auto = "log"`: no `stuck check (log only)` lines while people play normally: in a cave, under a roof, in a house, on a slope, while riding, gliding, swimming, on a moving mount. Any such line is a false positive: send it back, and do not use `rescue`. Only then try `rescue` with a player who is really stuck.
- [ ] The probe lines `KismetSystemLibrary:CapsuleOverlapActors` do not say FAILED (the out-array call worked).
- [ ] Two players with the same name (or names that differ only by an invisible character): notices show `Name#abcd`. Names that differ by look-alike letters (Cyrillic for Latin) are not detected: compare the tag when someone asks to teleport to you.

## Breeding and encounters / 繁殖と遭遇（実機で 1 つずつ）
- [ ] `breeding.egg_hatch_enabled = true` with a short time: `PalEggDefaultHatchingTime changed from ... to ...` in the log, and a newly placed egg hatches in about that time on a vanilla client (an egg that was already incubating may keep its old timer). Note the default the log printed (`game settings the game started with`).
- [ ] `breeding.optimal_temperature = true`: the log says `the first SetTemperatureDiff call was set to 0`, and an egg in a cold or hot spot hatches at the fast rate. If the log says `the hook fired but the parameter could not be set to 0`, this option does not work in this game version.
- [ ] `breeding.passive_inherit_weights = [0, 0, 0, 1]`: `Combi_PassiveInheritNum changed from [...] to [0, 0, 0, 1]`, and the passive count of newly bred Pals goes up. The meaning of each list position is inferred, so check that `[0, 0, 0, 1]` really means "try for 4" and not "try for 1".
- [ ] `encounter.rare_pal_probability` / `predator_probability`: note the unit of the value logged at start-up before choosing a number. New wild Pals show the effect; Predators need `EnablePredatorBossPal`.
- [ ] `raid.*`: `InvadeProbability` and the others change, and a raid comes in the expected time (the game's own settings decide `bEnableInvaderEnemy`).
- [ ] `/noctua raid` near a base: the game starts a raid on that base, and note what happens when a raid is already running or one ended recently.
- [ ] `guardian.autosave_minutes = 15`: does the game really save every 15 minutes afterwards (or only after a restart)?

## Backups / バックアップ
- [ ] `backup.enabled = true` with `backup.folder` (not inside the world folder): the log shows `backup: copying ...`, then `is complete and verified`, and a folder `noctua-backup-<UTC time>` exists with `Level.sav`, `LevelMeta.sav`, `Players/`.
- [ ] **Windows**: the generated `noctua-job.cmd` runs (`start "" /B`), robocopy is found (else xcopy under Wine), the result file appears, and no console window flashes or stalls the server. Check the server's FPS during a large copy.
- [ ] `backup.world_folder` empty: the log line names the folder Noctua found (`Pal/Saved/SaveGames/0/<world>`) and it is the right one. If it says `not known yet`, set `backup.world_folder`.
- [ ] Restore test: copy a backup over a stopped test server's world folder and start it: the world loads.
- [ ] A backup started while the game autosaves is discarded or delayed, never counted (look for `discarded` in `/noctua backup`).
- [ ] Old backups beyond `backup.keep` disappear, the admin's own folders in the same place stay.
- [ ] The finished name is given by Lua (`os.rename` of a folder): on Windows and under Wine it works, on the same disk and on another disk (a rename across disks may fail: then the log says `could not be renamed`, and the copy stays a `.partial`).
- [ ] The job's script and result files (`noctua-job-...`) are gone from the backup folder once a backup is over.
- [ ] A backup folder with `(x86)` or spaces in its path works (Windows and Linux).

## Load / 負荷
- [ ] The 250 ms ticker costs nothing measurable at 20 or more players. Compare server FPS with and without Noctua.
- [ ] RE-UE4SS issue #1372 reports a crash in hook dispatch with 25+ players. Watch for it.

## Platforms / 環境
- [ ] The Windows dedicated server.
- [ ] A Linux host running the Windows server under Wine/Proton, if any admin needs it.
- [ ] The legacy UE4SS 3.0.1 layout (`Win64/Mods`), including the `LoopAsync` fallback ticker.
- [ ] Steam, Game Pass and Mac clients joining the same server. Nothing is installed on any of them.
