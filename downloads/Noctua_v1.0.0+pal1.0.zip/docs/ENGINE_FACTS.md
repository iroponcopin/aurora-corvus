# Engine facts: where every identifier in `pal_api.lua` comes from

Researched on 2026-09-27 (UK time). None of these has been called on a live Palworld server by this project yet. "Confirmed" means the name and signature appear in the source below, not that Noctua has seen it work.

**Sources**
- **KIT**: localcc/PalworldModdingKit `main`, reflection headers updated for game **1.0** (2026-07-11, "Update 1.0" plus "update_10_patch1"), `Source/Pal/Public/*.h`.
- **SDK**: skript023/Palworld-SDK, a Dumper-7 dump pushed 2026-09-07, with the 1.0 layout (includes the engine classes).
- **AC**: dkoz/AdminCommands v1.0.1 (updated 2026-09-10), a working UE4SS Lua admin mod for game 1.0.1. Tested by a user on 1.0.2.101103.
- **UE4SS**: RE-UE4SS `main` at 515bd218 (2026-09-26), its docs, and Okaetsu's Palworld build `2281fa31` (2026-09-03).

## Game functions and fields (Palworld 1.0)

| Used for | Identifier | Status | Source |
|---|---|---|---|
| Chat from a player (server RPC) | `/Script/Pal.PalPlayerController:EnterChat_Receive(const FString& Message, uint8 Category)` | confirmed | KIT PalPlayerController.h; AC hooks it |
| (spec's name) | `PalPlayerController:SendChatMessage` | **does not exist** in 1.0 | KIT |
| (pre-1.0 name) | `PalPlayerState:EnterChat_Receive(FPalChatMessage)` | existed up to 0.7.3 only | KIT history |
| Reply to one player | `UPalUtility::SendSystemToPlayerChat(WorldContextObject, const FString& Message, const TArray<FGuid>& ReceiverPlayerUIds)` | confirmed | KIT PalUtility.h; AC calls it |
| Message to everyone | `UPalUtility::SendSystemAnnounce(WorldContextObject, const FString& Message)` | confirmed | KIT PalUtility.h |
| Utility default object | `/Script/Pal.Default__PalUtility` | confirmed | AC |
| Players | `APalPlayerState`, found with `FindAllOf("PalPlayerState")` | confirmed | AC |
| Player id | `APalPlayerState.PlayerUId` (FGuid: A, B, C, D int32) | confirmed | KIT PalPlayerState.h |
| Player name | `APlayerState.PlayerNamePrivate` (FString), fallback `GetPlayerName()` | confirmed (engine) | AC |
| Controller | `APlayerState:GetPlayerController()`; `pc.Pawn`, `pc.PlayerState` | confirmed | AC |
| Admin | `APalPlayerController.bAdmin` (bool; there is no IsAdmin function) | confirmed | KIT; AC checks it |
| Dead | `APalPlayerState:IsPlayerDead()`; fallback `CharacterParameterComponent:IsDead()` | confirmed (names) | KIT |
| HP | `pawn.CharacterParameterComponent:GetHP()` returns `FFixedPoint64 { int64 Value }`, HP x 1000 | confirmed (names). Scale seen in two mods, both reading Pals | KIT; Palvolve; a C++ tool |
| Capsule | `ACharacter.CapsuleComponent:GetScaledCapsuleHalfHeight()` | confirmed (engine). No Palworld mod seen using it | SDK |
| Position | `pawn:K2_GetActorLocation()` | confirmed | AC; Palladium |
| Guild | `APalPlayerState.GuildBelongTo` (UPalGroupGuildBase). Every player has one (a solo player is in an "Unnamed Guild", `UPalGroupIndependentGuild`) | confirmed | KIT; SDK; wiki |
| Guild's bases | `UPalGroupOrganization.BaseCampIds` (TArray<FGuid>) | confirmed | KIT |
| Base | `UPalBaseCampModel.ID` (FGuid) and `.Transform` (FTransform; `.Translation` used) | confirmed | KIT |
| Palbox | `APalBuildObjectBaseCampPoint` (actor) | confirmed | KIT; AC |
| Teleport, method 1 | `UPalUtility::TeleportAroundLoccation(APalCharacter* Target, const FVector& Location, const FQuat& Rotation) -> bool`. The double "cc" is the game's own spelling | confirmed (declaration). Used by three server mods. What "Around" does is **unknown** | KIT; SDK; AC; Palladium |
| Teleport, method 2 | `AActor::K2_TeleportTo(FVector DestLocation, FRotator DestRotation) -> bool` | confirmed (engine) | SDK; Palladium falls back to it |
| Max players | `APalGameStateInGame:GetMaxPlayerNum()` / `.MaxPlayerNum` | confirmed | KIT |

## Base settings, worker cap and decay (researched 2026-09-28)

Sources as above (KIT headers, main branch, last commit 2026-08-24), plus the official server documentation (docs.palworldgame.com, "Configuration") and palworld.wiki.gg. A web-summarising fetch tool read the headers, so an entry is marked "confirmed" only when two separate fetches agreed or another source corroborated it. The Dumper-7 SDK was too large to cross-check.

| Used for | Identifier | Status |
|---|---|---|
| (spec's name) | `UPalGameSetting::GetMaxBaseCampWorkerSlots` | **does not exist** in the 1.0 headers |
| (spec's name) | `PalBaseCampModel:GetMaxWorkerPalNum` | **does not exist** in the 1.0 headers |
| Worker Pals per base (the world setting) | `FPalOptionWorldSettings.BaseCampWorkerMaxNum` (int32, Config); ini key `BaseCampWorkerMaxNum`, default 15, documented maximum 50 | confirmed (KIT; official docs) |
| Where the limit of 50 lives | `FPalOptionWorldSettinThresholds.BaseCampWorkerMaxNum` (`TMap<EPalSupportedPlatformType,int32>`; the struct name really is spelled "Settin") on `UPalOptionSubsystem.WorldSettingThreshold` | confirmed (KIT) |
| Per-level cap | Data table `DT_BaseCampLevelData` (`Pal/DataTable/BaseCamp/`): +1 worker per base level up to 30 at level 30. Its row field name is **unknown** (mod tools call it "WorkerMax" or "WorkerMaxNum"). Effective cap = the lower of the table value and the world setting is **inferred** | partly unconfirmed. Noctua only reads the table (probe) |
| The guild's cap, computed by the game | `UPalGroupGuildBase:GetWorkerCapacityNum(int32 InLevel)`, `:GetBaseCampLevel()`, `:IsWorkerCapacityLimited(int32)`; `UPalGroupGuild : UPalGroupGuildBase` | confirmed (KIT, two fetches) |
| Game's world settings at run time | `UPalOptionSubsystem`: properties `OptionWorldSettings` and `OptionWorldSettingsCache` (FPalOptionWorldSettings); functions `GetOptionWorldSettings()`, `SetOptionWorldSettings(const FPalOptionWorldSettings&)`, `ApplyWorldSettings()` | confirmed (KIT). Noctua writes the two properties in place. Whether the game re-reads them while running is **unconfirmed** |
| Decay rate | `FPalOptionWorldSettings.BuildObjectDeteriorationDamageRate` (float; default 1.0; 0 stops decay), applies only outside Palbox range | confirmed (KIT; official docs; wiki) |
| Guild bases deleted when nobody is online | `bAutoResetGuildNoOnlinePlayers` (default false), `AutoResetGuildTimeNoOnlinePlayers` (hours, default 72) | confirmed (KIT). Noctua only reads them |
| Class that applies decay | not in the headers; only `UPalMapObjectModel.DeteriorationDamage` / `DeteriorationTotalDamage` (float, Transient) | so there is no function to hook. Noctua does not try |
| Placement limits | no world setting relaxes slope, rock or overlap checks (`bBuildObjectCollisionCheck` does not exist). Per-object fields such as `APalBuildObject.InstallCapacitySlopeAngle` are protected, and placement is probably also checked on the client | not possible server-side by settings |

## Breeding, eggs and items (researched 2026-09-29)

Same sources as above, plus paldb, palworldbreeding.gg, palworld.tools and the AdminCommands mod. "Confirmed" = a header or a working mod shows the name and signature; nothing here has run on a live server.

| Used for | Identifier | Status |
|---|---|---|
| Egg hatching time (world setting) | `FPalOptionWorldSettings.PalEggDefaultHatchingTime` (float, hours for the biggest egg; smaller eggs are divided by a rarity divisor; 0 hatches at once) | confirmed (KIT + docs). The default is **unknown**: sources say 72 (before 1.0), 1 (1.0), or give none, so Noctua logs the value the game starts with. Whether the game re-reads it after a run-time write: **unconfirmed** |
| Incubator temperature | There is **no pass/fail check**. `UPalGameSetting.PalEggHatchingSpeedRateByTemperature` (`TMap<int32,float>`) maps a temperature difference to a speed multiplier: 0 -> x2.0, 1 -> x1.5, 2-3 -> x1.0, 4-8 -> x0.75 | confirmed (KIT; two calculators) |
| The call Noctua hooks | `/Script/Pal.PalMapObjectHatchingEggModel:SetTemperatureDiff(int32 TemperatureDiff)`; the property `CurrentPalEggTemperatureDiff` is replicated | signature confirmed (KIT). Who calls it, whether a hook fires for a native call, and whether `param:set(0)` reaches the game: **unconfirmed** |
| Remaining hatching work | `UPalMapObjectWorkeeModule:GetWorkProgress()` -> `UPalWorkProgress` (`RequiredWorkAmount`, `CurrentWorkAmount`, replicated) | confirmed (KIT); Noctua does not touch it |
| Passive inheritance weights | `UPalGameSetting.Combi_PassiveInheritNum` (`TArray<float>`), `Combi_PassiveRandomAddNum`, `Combi_TalentInheritNum` | confirmed (KIT; a PalSchema issue shows `Combi_PassiveInheritNum [0,0,0,1]`). Which index means how many passives: **inferred** (index 0..3 = 1..4). Writing a `TArray` element from Lua: **unverified** |
| A hook to give back a lost parent passive | not found: `UPalBreedingUtility` only has `FindConsumableBreedItem`, `CanProceedBreeding`, `CalcBreedBuffRate`; an egg's save parameter has no parent data | not possible as specified |
| Reaching the game-setting object | `UPalUtility::GetGameSetting(WorldContextObject)` (static) | confirmed (KIT) |
| Vanilla inheritance numbers | the child takes 1/2/3/4 of the parents' passives with weights 40/30/20/10; random extra passives and a 1% mutation exist (sources disagree on the details) | wiki + calculators; not relied on |
| Giving an item | `UPalPlayerInventoryData:AddItem_ServerInternal(FName StaticItemId, int32 Count, bool IsAssignPassive, float LogDelay, bool bNotifyLog) -> EPalItemOperationResult`; reached with `PalPlayerState:GetInventoryData()` | confirmed (KIT + two working mods; neither checks the result) |
| Result codes | `EPalItemOperationResult`: 0 Success, 1 SuccessNoOperation, 15 FailedNotFoundStaticItemData (unknown id), 16 FailedNotEnoughSlotSpace (no room), ... | confirmed by declaration order (KIT). What a **full inventory** really does (nothing, partial, drop): **unknown**, which is why Noctua counts the item before and after (`CountItemNum(FName)`) |
| Item ids used by the starter kit | `PalSphere`, `Pickaxe_Tier_00` (Stone Pickaxe), `Axe_Tier_00` (Stone Axe), `Torch`, `Baked_Berries`; also known: `PalSphere_Mega`, `PalSphere_Giga`, `Wood`, `Stone`, `Fiber`, `Bat`, `WeakerBow`, `Arrow`, `Glider_Old` | confirmed (paldb, AdminCommands' item list, two more lists) |

## Saving, backups, stuck players, raids and spawning (researched 2026-09-29)

| Used for | Identifier | Status |
|---|---|---|
| Autosave interval | `FPalOptionWorldSettings.autoSaveSpan` (float, seconds, default 30; **the header spells it with a small a**; ini key `AutoSaveSpan`) | confirmed (KIT + several server guides). Run-time effect unconfirmed |
| The game's own rolling backups | `bIsUseBackupSaveData` (default true); 5 per 30 s, 6 per 10 min, 12 per hour, 7 per day, in `<world>/backup/` | confirmed (official docs) |
| Saving now | no reflected function for RCON or REST `Save` exists; `UPalSaveGameManager:StartWorldDataAutoSave` may only arm the timer. **Noctua does not trigger a save.** | absence confirmed (KIT) |
| Is a save running | `UPalUtility::GetSaveGameManager(ctx)` -> `UPalSaveGameManager:IsWorldAutoSaving()` | confirmed (KIT) |
| World folder | `KismetSystemLibrary:GetProjectSavedDirectory()` + `SaveGames/0/` + `APalGameStateInGame:GetWorldSaveDirectoryName()` (or `backup.world_folder`) | names confirmed (KIT, UE docs); the values on a dedicated server: **unconfirmed** |
| Copying folders | Lua cannot; Noctua writes a small script and starts it as a separate process: robocopy (`/E /R:1 /W:1`, exit codes 0-7 are success, never `/MIR`), xcopy under Wine (no robocopy), `cp -a` on Linux. `os.execute` returns `true|nil, "exit", code`; on Windows the code is not shifted | Microsoft docs, Lua source, Wine notes. **The Windows script has not run.** A copy taken while the game writes can look fine and refuse to load: hence the waiting and the size checks |
| Player unstuck | `APalPlayerController:TeleportToSafePoint_ToServer(bool bWasOutOfWorld)`, called as `pc:TeleportToSafePoint_ToServer(true)` | confirmed (KIT; AdminCommands' `!unstuck`). What the bool changes: unknown |
| Detecting an embedded player | a line trace's `bStartPenetrating` is unreliable against terrain and complex meshes; Noctua uses `KismetSystemLibrary:CapsuleOverlapActors(ctx, pos, radius, halfHeight, objectTypes, classFilter, ignore, out)` with a capsule 10 cm smaller than the pawn's | UE 5.1 signature confirmed (docs). How UE4SS passes the out array and whether the object types `{0, 1}` cover Palworld's terrain: **unverified** |
| Stuck Pals | 1.0 already added recovery (`APalAIController` block detection) and fixes; no verified relocation call other than `UPalUtility::Teleport`. **Not built.** | KIT + patch notes |
| Wild Pal spawning | `UPalNPCManager::SpawnNPCForServer(FPalNPCSpawnInfo, callback) -> UPalIndividualCharacterHandle` (async); the working mod then needs about 16 calls to wake the Pal's AI, applies `IsRarePal`, passives, status ids and scale afterwards. Licence: no formal one, the README asks for credit, the download page says All Rights Reserved. **Not built.** | KIT + reading the mod's source |
| Lucky and Predator odds | `UPalGameSetting.RarePal_AppearanceProbability`, `PredatorPal_AppearanceProbability` (units unknown: one mod uses 100 for "always", another comments 0.1 as the default); Predators need `EnablePredatorBossPal` | confirmed (KIT + mods). Applies to Pals that spawn afterwards |
| Raid settings | `UPalGameSetting.InvadeProbability`, `InvadeJudgmentInterval_Minutes`, `InvadeCollTime_Min_Minutes`, `InvadeCollTime_Max_Minutes` (plus others); world setting `bEnableInvaderEnemy` | confirmed (KIT + mods) |
| Starting a raid | `UPalUtility::GetInvaderManager(ctx)` -> `UPalInvaderManager:StartInvaderMarchForBaseCamp(FGuid campID)` | declared (KIT); **no mod shows it working**, and cooldowns and dedicated-server behaviour are unknown |
| Raid composition | data table `DT_PalInvader` (240 rows); rewriting it needs PalSchema, not Lua alone. **Not built.** | palmods.gg, PalSchema docs |
| Placement redlines | no world setting; `APalBuildObject.InstallCapacitySlopeAngle` etc. are protected and the client also checks placement. **Not built.** | KIT |

## Engine library functions (Palworld's UE 5.1)

| Used for | Identifier | Status |
|---|---|---|
| Ground and wall checks | `UKismetSystemLibrary::LineTraceSingleForObjects(WorldContextObject, Start, End, ObjectTypes, bTraceComplex, ActorsToIgnore, DrawDebugType, OutHit, bIgnoreSelf, TraceColor, TraceHitColor, DrawTime)`: 12 arguments, OutHit passed as a table and filled in place | confirmed (SDK; UE4SS LineTraceMod shows the out-table pattern) |
| Object types traced | `{0, 1}` = WorldStatic, WorldDynamic (engine default indices). Landscape uses BlockAll (WorldStatic); buildings use MapObjectPhysics* (WorldDynamic) | indices **unconfirmed for Palworld**. The trace self-test in main.lua reports it on the first live run |
| TPS | `UKismetSystemLibrary::GetFrameCount()` (int64) | confirmed (SDK) |
| Clock | `UGameplayStatics::GetRealTimeSeconds(ctx)`, `GetWorldDeltaSeconds(ctx)` (double) | confirmed (SDK) |

## UE4SS behaviour Noctua relies on

| Behaviour | Status |
|---|---|
| Mods folder is `Win64/ue4ss/Mods`; `Win64/Mods` is only a fallback when `ue4ss/Mods` is absent (legacy 3.0.1 layout) | UE4SS source (UE4SSProgram.cpp) |
| A mod's script folder may be `Scripts` or `scripts` | UE4SS source (LuaMod.cpp) |
| `enabled.txt` starts a mod even when `mods.txt` does not list it | UE4SS source |
| `RegisterHook` cannot stop the original function; a pre-hook write to a parameter (`param:set(...)`) is *inferred* to reach the game, not documented | UE4SS source + inference, so `chat.hide_commands_experimental` is off by default |
| Hook callbacks are not guaranteed to run on the game thread, so Noctua only queues inside the hook | UE4SS docs |
| `LoopInGameThreadWithDelay` runs on the game thread (builds after 3.0.1, including the Palworld build); 3.0.1 falls back to `LoopAsync` + `ExecuteInGameThread` | UE4SS docs and source |
| `print` adds `[Lua] ` and no newline | UE4SS source |
| All standard Lua libraries (io, os, debug ...) are open; Lua 5.4.7 in the Palworld build | UE4SS source |
| Server RPC hooks fire on PalServer; open report of a hook-dispatch crash with 25+ players (RE-UE4SS issue #1372) | community reports |
| A "/" chat line reaches the server and is not broadcast, but the game answers "Unknown command."; Lua cannot stop that without C++ | AdminCommands GUIDES.md |
| Linux: UE4SS supports Windows only; Linux hosts run the Windows server under Wine/Proton | pwmodding.wiki |
