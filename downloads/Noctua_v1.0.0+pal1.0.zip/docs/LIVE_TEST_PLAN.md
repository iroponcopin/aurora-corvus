# Noctua: the first live test / 実機での最初の確認手順

Phase 5 of NOCTUA_INIT.md asks for two things that no offline test can give: a vanilla client joining a server that runs Noctua, and the server's tick rate with 20 people. This page is the order to do them in, and what to write down.

Phase 5 が求めるのは、オフラインでは確かめられない 2 つです。MOD なしのクライアントが Noctua 入りのサーバーに入れること、そして 20 人のときのサーバーの処理速度です。この手順書は、その順番と、控えておくことをまとめたものです。

Everything Noctua does can be undone by deleting the `NoctuaCore` folder. The checklist of individual items is [UNVERIFIED.md](../UNVERIFIED.md); this page is the order.

## 0. Before the server starts / サーバーを起動する前

1. Back up the world folder (`Pal/Saved/SaveGames/0/<world>`). Noctua does not touch it unless you switch on the backup or the base settings, but a copy costs nothing.
2. Install as in [SERVER_SETUP_GUIDE.md](SERVER_SETUP_GUIDE.md). Leave `noctua_settings.json` at its defaults for the first boot: every feature that changes game rules is off.
3. Keep UE4SS's GUI console off.

## 1. First boot: read the log / 最初の起動でログを読む

Open `Win64/ue4ss/UE4SS.log` and look for these lines. Copy any line that says `MISSING`, `FAILED` or `could not` and keep it: each one is a fact the next version needs.

| Line | Means |
|---|---|
| `[NOCTUA] [INFO] Initializing Noctua ...` | the mod started |
| `health check #1: N symbols found, M missing` and `feature ... ON/OFF` | which game functions exist; an OFF feature is switched off, the rest runs |
| `chat hook registered on /Script/Pal.PalPlayerController:EnterChat_Receive` | commands can be heard |
| `ticker started every 250 ms (...)` | the game-thread loop runs |
| `world settings the game started with: ...` | what the game uses for the worker cap and decay before Noctua touches anything |
| `trace self-test: ground found ...` | (after the first player spawns) the ground check works |
| `base-level table probe: ...` (30 s after start) | the layout of the base-level table: **send this back** |
| `probe ...: FAILED` | a game field is named differently in this version |

## 2. One player, a vanilla client / 1 人、MOD なしのクライアントで

Join with an unmodified game (Steam, Game Pass or Mac). Nothing may be installed on the client.

- [ ] `/help` (and `!help`) answers in the chat box; Japanese text is not garbled.
- [ ] `/stats` shows uptime, players and TPS. Compare the TPS with the REST API `/v1/api/metrics` `serverfps` if the REST API is on.
- [ ] `/home` from a base, then from far away; check the landing spot and that arrival is confirmed in the log.
- [ ] Take damage, then `/home`: refused. Move during the warmup: cancelled.
- [ ] As admin (logged in with the admin password): `/noctua health`, `/noctua base`, `/noctua version`.

## 3. Two or three players / 2〜3 人

- [ ] `/tpa`, `/tpaccept`, `/tpdeny`, `/tpcancel` between two vanilla clients.
- [ ] Two players with the same name (`name#abcd`), a name with Japanese characters, a player logging out during a request.

## 4. Features that change the game / ゲームのルールを変える機能（1 つずつ）

Switch on one setting at a time in `noctua_settings.json`, run `/noctua reload`, and check with the admin commands. The individual items are in UNVERIFIED.md. After each one, look at the log for `the game put ... back` lines: they mean something resets the value. Suggested order, safest first:

1. `guardian.unstuck_auto = "log"` (only writes to the log), play normally for a while and read the log.
2. `commands.kit.enabled` (with a test account, including a full inventory).
3. `base.disable_decay`, `base.worker_max = 20`, then `30`.
4. `breeding.egg_hatch_enabled`, then `breeding.optimal_temperature`, then `breeding.passive_inherit_weights`.
5. `encounter.*` and `raid.*`, then `/noctua raid` near a base.
6. `guardian.autosave_minutes`.
7. `backup.enabled` with a folder on another disk; do a restore test on a copy of the server before relying on it.
8. `guardian.unstuck_auto = "rescue"` only after step 1 showed no false positives.

## 5. Load with many players / 人数が多いときの負荷

The offline profile (`tools/profile.lua`) measures only Noctua's own Lua and cannot say what the game does. For the real figure:

1. With Noctua removed, note `serverfps` from `/v1/api/metrics` while N players are online (N = 5, 10, 20 if you can gather them).
2. Repeat with Noctua installed and the defaults.
3. Repeat with the base, backup and guard features on.
4. A difference of more than a frame or two per second at the same N is a finding: write down N, both figures, and what the players were doing.

RE-UE4SS issue #1372 reports a crash in hook dispatch with 25 or more players: watch for it.

## 6. What to send back / 持ち帰るもの

- The log lines marked above (health check, probes, level-table probe).
- Which UNVERIFIED items passed, failed or could not be judged.
- Anything odd a vanilla client showed (snap-back after a teleport, garbled text, wrong slot counts).
