# Noctua サーバー導入手順 / Server setup guide

Noctua はパルワールドの専用サーバーだけで動く MOD です。参加するプレイヤーは何も入れる必要がありません。Steam 版・Game Pass 版・Mac 版のままサーバーに接続すれば、チャットからコマンドが使えます。

Noctua runs only on the Palworld dedicated server. Players install nothing: they join with the game as it is (Steam, Game Pass or Mac) and use Noctua from the chat box.

> 状態: V1.0 開発版（Phase 1–2）。オフラインの自動テストは通っていますが、実際のサーバーではまだ動かしていません。確認の項目は [UNVERIFIED.md](../UNVERIFIED.md) にあります。
> Status: V1.0 development build (Phases 1–2). It passes its offline test suite and has not yet run on a real server. See [UNVERIFIED.md](../UNVERIFIED.md).

---

## 日本語

### 必要なもの
- パルワールド **1.0** の専用サーバー（Windows 版 `PalServer`）。Linux のサーバー機では、Windows 版のサーバーを Wine / Proton で動かします。UE4SS は公式には Windows だけに対応しています。
- **UE4SS のパルワールド版**（Okaetsu 氏の fork、https://github.com/Okaetsu/RE-UE4SS/releases ）。パルワールドのアップデートに合わせた修正（MemberVariableLayout）が入っています。導入方法は pwmodding.wiki の「UE4SS installation (server)」を見てください。
- Noctua の `NoctuaCore` フォルダー。

### 入れ方
1. サーバーを止めます。
2. UE4SS を `PalServer\Pal\Binaries\Win64\` に入れます。`Win64\ue4ss\` フォルダーができ、その中に `UE4SS.dll` と `Mods\` があれば正しく入っています。
3. `NoctuaCore` フォルダーをまるごと `PalServer\Pal\Binaries\Win64\ue4ss\Mods\` にコピーします。
   配布物のフォルダー構成はサーバーと同じなので、`PalServer` フォルダーをサーバーの `PalServer` に重ねても構いません。
   ```
   PalServer\Pal\Binaries\Win64\ue4ss\Mods\NoctuaCore\
       enabled.txt
       scripts\main.lua  (ほか)
       config\noctua_settings.example.json   （既定値の見本。本物の noctua_settings.json は初回の起動で作られます）
       data\
   ```
   - 古い UE4SS 3.0.1（`ue4ss` フォルダーがなく、`Win64\UE4SS.dll` と `Win64\Mods\` がある構成）の場合だけ、`Win64\Mods\NoctuaCore\` に置きます。`ue4ss\Mods` があるとき、UE4SS は `Win64\Mods` を読みません。
   - `enabled.txt` があれば `mods.txt` に書き足す必要はありません。
4. サーバーを起動し、`Win64\ue4ss\UE4SS.log` に次の行が出ることを確かめます（UE4SS が行の頭に `[Lua]` を付けます）。
   ```
   [Lua] [NOCTUA] [INFO] Noctua 1.0.0 ready: 19/19 features on (...)
   ```
   `MISSING` の行があるときは、パルワールドの更新で関数の名前が変わっています。Noctua はその関数を使う機能だけを止めて、残りの機能は動かし続けます。
5. UE4SS のコンソール窓（GUI コンソール）は切っておきます。サーバーが重くなります。設定は `UE4SS-settings.ini` の `[Debug]` にあります。キー名はお使いの版のファイルで確かめてください。

### 更新するとき
- 配布物には `config\noctua_settings.json`（あなたの設定）も `data\players.json`（プレイヤーの言語選択・キットの受け取り記録）も入っていません。上書きしても、この 2 つは消えません。新しい設定が加わったときは、ファイルになくても既定の値で動きます。

### プレイヤーが使うコマンド
コマンドは `/` でも `!` でも始められます（設定で変えられます）。

| コマンド | 内容 |
|---|---|
| `/help` | 使えるコマンドの一覧 |
| `/home` | ギルドの拠点へテレポート（`/home 2` で 2 番目の拠点、`/home list` で一覧）。5 秒動かずに待つと飛びます。直前にダメージを受けていると使えません |
| `/tpa <名前>` | そのプレイヤーの所へのテレポートを申請します |
| `/tpaccept [名前]`・`/tpdeny [名前]` | 申請を承認・拒否します |
| `/tpcancel` | 自分が出した申請を取り消します |
| `/stats` | 稼働時間、接続人数、サーバーの TPS |
| `/lang ja` ・ `/lang en` | Noctua の返事の言語を切り替えます（プレイヤーごとに保存） |
| `/kit starter` | スターターキット（中身は設定で決める）を受け取ります。アイテムごとに 1 人 1 回だけで、あとで個数を変えても配り直しません。あとから一覧に足したアイテムは、受け取り済みの人にも 1 回だけ配られます。既定ではオフです |
| `/unstuck` | 地形に埋まったとき、ゲーム自身の「最寄りの安全な場所へ」を実行します。直前にダメージを受けていると使えません |
| `/noctua health\|base\|raid\|backup\|reload\|version` | 管理者用（ゲームの管理者パスワードでログインした人だけ）。`base` はゲームの設定の現在値、`raid` は最寄りの拠点への襲撃の開始、`backup` はバックアップの状況 |

**`/` と `!` の違い**: `/` で始めた行は他の人のチャットに出ません。ただしゲーム本体が「Unknown command.」と返してきます。Lua ではこれを止められません。`!` で始めた行はゲームには普通のチャットとして扱われるので、全員に見えます。どちらを使っても Noctua は同じように返事をします。設定の `chat.hide_commands_experimental` を `true` にすると両方とも隠せる見込みですが、まだ実際のサーバーでは試していません。

### 設定（`config/noctua_settings.json`）
初回の起動で既定の値のファイルが作られます。書き換えたら、サーバーを再起動するか、管理者がゲーム内で `/noctua reload` を実行します。間違った値は、その項目だけ既定の値に戻して UE4SS.log に理由を書きます。ファイルを消す必要はありません。

| キー | 既定 | 意味 |
|---|---|---|
| `schema_version` | 1 | ファイルの形式の版。変えないでください |
| `language` | `"ja"` | `/lang` を使っていないプレイヤーへの返事の言語（`ja` / `en`） |
| `log_level` | `"info"` | UE4SS.log に書く量（`debug` / `info` / `warn` / `error`） |
| `chat.command_prefixes` | `["/", "!"]` | コマンドの頭の文字（`/` `!` `.` から 1〜3 個） |
| `chat.max_line_bytes` | 200 | これより長いコマンドは断ります |
| `chat.hide_commands_experimental` | false | 実験的な機能で、まだ試していません。コマンドの行を、ゲームが処理する前に空にします |
| `chat.rate_limit_burst` | 5 | 続けて送れるコマンドの数 |
| `chat.rate_limit_refill_seconds` | 2.0 | 1 回分が戻るまでの秒数 |
| `commands.home.enabled` | true | `/home` を使えるようにする |
| `commands.home.cooldown_seconds` | 300 | `/home` の後、次に使えるまでの秒数 |
| `commands.home.warmup_seconds` | 5 | 飛ぶまで動かずに待つ秒数 |
| `commands.home.combat_lockout_seconds` | 15 | HP が減ってからこの秒数は `/home` を使えない |
| `commands.tpa.enabled` | true | `/tpa` 系を使えるようにする |
| `commands.tpa.request_timeout_seconds` | 60 | 申請が失効するまでの秒数 |
| `commands.tpa.cooldown_seconds` | 120 | `/tpa` で飛んだ後、次に飛べるまでの秒数 |
| `commands.tpa.warmup_seconds` | 3 | 承認の後、動かずに待つ秒数 |
| `commands.tpa.combat_lockout_seconds` | 15 | HP が減ってからこの秒数は申請も移動もできない |
| `commands.tpa.max_incoming` | 5 | 1 人が同時に受けられる申請の数 |
| `commands.stats.enabled` | true | `/stats` を使えるようにする |
| `commands.stats.cooldown_seconds` | 5 | `/stats` の間隔 |
| `commands.stats.tps_window_seconds` | 60 | TPS を平均する秒数 |
| `commands.lang.enabled` | true | `/lang` を使えるようにする |
| `teleport.cancel_move_distance_cm` | 150 | 待っている間にこれ以上動くと中止（0 で動いても中止しない） |
| `teleport.cancel_on_damage` | true | 待っている間に HP が減ったら中止 |
| `teleport.landing_search_radius_cm` | 400 | 着地点を探す範囲 |
| `teleport.headroom_cm` | 220 | 着地点の上に必要な空間の高さ |
| `base.worker_max` | 0 | 拠点あたりの作業パルの数。0 はゲームの設定に触らない。30 を超える値は、ゲームの拠点レベルの表にも上限があるため、効かない見込みです（下の「拠点の設定」） |
| `base.disable_decay` | false | true で、拠点の外の建築物の劣化を止めます（ゲームの劣化の倍率を 0 にします） |
| `base.reassert_seconds` | 30 | ゲームが上の値を使い続けているかを確かめる間隔。戻されていたら書き直します |
| `commands.kit.enabled` | false | `/kit starter` を使えるようにする（アイテムを配るので、既定ではオフ） |
| `commands.kit.starter_items` | `["PalSphere:10", "Pickaxe_Tier_00:1", "Axe_Tier_00:1", "Torch:1", "Baked_Berries:10"]` | キットの中身（`"アイテムID:個数"`、20 種類まで）。ゲームが知らない ID は飛ばして、プレイヤーに知らせます |
| `commands.unstuck.enabled` | true | `/unstuck` を使えるようにする |
| `commands.unstuck.cooldown_seconds` | 300 | `/unstuck` の後、次に使えるまでの秒数 |
| `commands.unstuck.combat_lockout_seconds` | 15 | HP が減ってからこの秒数は `/unstuck` を使えない |
| `breeding.egg_hatch_enabled` | false | true で、卵の孵化時間（下）を Noctua が設定する |
| `breeding.egg_hatch_hours` | 1.0 | いちばん大きい卵が孵るまでの時間（時間）。小さい卵はもっと早い。0 で即座に孵る |
| `breeding.optimal_temperature` | false | true で、どのインキュベーターも最適な温度として扱う（孵化がいちばん速い倍率） |
| `breeding.passive_inherit_weights` | `[]` | 実験的。子が親のパッシブを 1・2・3・4 個引き継ぐ重み。例 `[0, 0, 0, 1]` は常に 4 個を狙う。`[]` はゲームのまま |
| `encounter.rare_pal_probability` | -1 | 野生のパルがラッキー（色違い）になる確率（ゲームの単位）。-1 はゲームのまま |
| `encounter.predator_probability` | -1 | 野生のパルが暴走個体（捕食者）になる確率。-1 はゲームのまま |
| `raid.probability` | -1 | 襲撃が始まる確率（ゲームの単位）。-1 はゲームのまま |
| `raid.judgment_interval_minutes` | -1 | 襲撃が始まるかを判定する間隔（分）。-1 はゲームのまま |
| `raid.cooldown_min_minutes` | -1 | 襲撃のあと、次まで最短で空ける時間（分）。-1 はゲームのまま |
| `raid.cooldown_max_minutes` | -1 | 同じく最長（分）。最短より小さいと、両方ともゲームのままになります |
| `guardian.autosave_minutes` | 0 | ゲーム自身の自動保存の間隔（分）。0 はゲームのまま（ゲームの既定は 30 秒） |
| `guardian.unstuck_auto` | `"off"` | 埋まったプレイヤーの自動検知: `off` / `log`（ログに書くだけ）/ `rescue`（動かす）。まず `log` で様子を見てください |
| `guardian.unstuck_confirm_checks` | 3 | 5 秒おきの検知が何回続いたら救済するか |
| `guardian.unstuck_max_per_hour` | 4 | 1 人あたり、1 時間の自動救済の上限（誤検知でも動かし続けない） |
| `backup.enabled` | false | true でワールドのセーブフォルダーを定期的にコピーする（`backup.folder` が要ります） |
| `backup.folder` | `""` | バックアップの置き場所。`D:/PalBackups` のような絶対パス（ワールドのフォルダーの中は不可）。Noctua はここで自分が作ったフォルダーしか消しません |
| `backup.world_folder` | `""` | Noctua がワールドのフォルダーを見つけられないときだけ指定（`Pal/Saved/SaveGames/0/<ワールド>`）。空なら自動 |
| `backup.interval_minutes` | 60 | バックアップの間隔（分） |
| `backup.keep` | 24 | 残すバックアップの数。古いものは、新しいものを確かめたあとにだけ消します |
| `backup.settle_seconds` | 15 | この秒数、セーブファイルの大きさが変わらず、ゲームが保存中でないことを確かめてからコピーする |
| `admin.reload_enabled` | true | `/noctua reload` を使えるようにする |

### 拠点の設定（作業パルの上限・劣化）
- **既定では何も変えません。** `base.worker_max` と `base.disable_decay` を自分で設定したときだけ、Noctua がゲームの世界設定を書き換えます。
- 仕組み: ゲームの世界設定（`BaseCampWorkerMaxNum`、`BuildObjectDeteriorationDamageRate`）を、実行中に書き換え、読み戻して確かめます。ゲームが元の値に戻したら書き直します。ini ファイルや `WorldOption.sav` の内容に関わらず効く見込みですが、実機ではまだ確かめていません。
- 効いたかどうかは、管理者が `/noctua base` で見られます。ゲームの現在値、Noctua の目標、状態、そしてゲーム自身が計算した自分のギルドの作業パルの上限が出ます。
- **作業パルの上限**: 30 を超える値は効かない見込みです。拠点レベルごとの上限の表（`DT_BaseCampLevelData`）が 30 体までで、Noctua はこの表をまだ書き換えません。表の作りが実機で確かめられていないためです。起動から 30 秒後に、この表の中身が UE4SS.log に 1 回だけ書かれます（`base-level table probe`）。
- 作業パルを増やすと、サーバーの負荷が上がります（ゲームの公式の注意書きにもあります）。クライアントの画面が、30 を超える枠をどう表示するかも未確認です。
- **劣化**: 拠点の外の建築物だけが対象です。拠点の範囲内の建築物は、もともと劣化しません。`bAutoResetGuildNoOnlinePlayers`（誰もオンラインでない拠点をゲームが消す設定）は Noctua は変えません。オンなら起動時に警告を出します。
- **傾斜や岩肌に建てられるようにすること**は、サーバー側の設定ではできません。建築の可否はクライアント側でも判定されるため、対応する MOD の多くはクライアント側にも要ります。Noctua は提供しません。

### 繁殖・遭遇・襲撃（ゲームの設定を書き換えるもの）
どれも既定ではゲームのままで、設定したときだけ Noctua が書き換えます（拠点の設定と同じ仕組み: 書いて、読み戻して確かめ、戻されたら書き直し、設定を切ったら元に戻します）。効いたかは `/noctua base` で見られます。
- **卵**: 仕様にあった「温度判定を最適に見せかける」は、ゲームに合否の判定がないため、そのままは作れません。ゲームの温度は孵化速度の倍率（×0.75〜×2）です。`breeding.optimal_temperature` は、倍率を決める関数を、温度差 0（最適）に差し替えます。実機ではまだ動かしていません。`breeding.egg_hatch_hours` は、ゲームの世界設定の孵化時間を書き換えます。実行中にゲームがこの値を読み直すかは未確認です。
- **パッシブスキルの継承**: 「失われた親のパッシブを取り戻す」フックは、ゲームに見つかりませんでした。作れるのは、引き継ぐ個数の重み表の書き換えだけです（`breeding.passive_inherit_weights`、実験的）。引き継ぐ個数が増えるだけで、特定のパッシブが必ず残るわけではありません。
- **野生のアペックスパル**: 自前でボス級のパルを出す仕組みは作っていません（下の「作っていないもの」）。代わりに、ゲーム自身の「ラッキー」「捕食者（大きく、赤いオーラ）」の出現確率を上げられます（`encounter.*`）。捕食者は、ゲームの設定 `EnablePredatorBossPal` が True のときだけ出ます。
- **襲撃**: 頻度と間隔の調整（`raid.*`）と、管理者が自分に最も近い拠点（300 m 以内）へ襲撃を起こす `/noctua raid` です。ゲームの設定 `bEnableInvaderEnemy` が False だと襲撃は起きません。

### 保全（保存・バックアップ・埋まった人の救出）
- **自動保存**: ゲームは元から自動保存します（既定 30 秒）。`guardian.autosave_minutes` を設定すると、その間隔に変えます（実行中に間隔が効くかは未確認）。
- **バックアップ**（`backup.*`）: 既定ではオフです。オンにすると、間隔ごとに次の順で動きます。
  1. ゲームが保存中でなく、`Level.sav` などの大きさが `settle_seconds` 変わらなくなるのを待つ。
  2. 作業ごとに名前の違う小さなスクリプトを **別のプロセスで** 起動して、コピーさせる（大きなコピーで、ゲームが止まらない）。`noctua-backup-<UTC の日時>.partial` にコピーするだけで、名前は変えません。
  3. `.partial` のコピーの大きさが、コピーの前と後の元の大きさと合うかを確かめる。合っていれば、Noctua 自身がその場で名前を `noctua-backup-<UTC の日時>` に変える。合わなければ（コピー中にゲームが保存した）、捨てて数えず、あとでやり直す。壊れたコピーが正式な名前を持つことはないので、消せなかったときも、良いバックアップとして数えられることはありません。
  4. 確かめたあとにだけ、`backup.keep` を超えた古いものと、途中で止まったコピーの残りを消す。消すのは Noctua が作った名前のフォルダーだけです。今作ったものは消しません。
  - スクリプトを起動するので、Windows のコマンドプロンプト（robocopy。Wine では xcopy）か、Linux の `sh` が要ります。**Windows 用のスクリプトは、実機ではまだ動かしていません。**
  - **1 つのサーバーに 1 つのバックアップフォルダー**を使ってください。2 つのサーバーが同じフォルダーを使うと、古い世代の整理が混ざり、片方の新しいバックアップが、もう片方の唯一のバックアップを押し出すことがあります。
  - 途中で `backup.enabled` を false にすると、その作業は打ち切られます。あとで true に戻しても、古いコピーは判定されません。前の作業が答えないまま残っているときは、答えが出るまで新しい作業を始めません（1 日たつと死んだものとみなします）。
  - パスには `( ) [ ] { } ' ~ #` も使えます（`C:/Program Files (x86)/...`）。使えないのは、引用符の中でも意味を持つ `" % ! $` ` と、区切りの `& | < > ^ ; * ?`、制御文字です。`..` や、絶対でないパス、ネットワークのパス（`\\サーバー\...`）も使えません。
  - 仕様にあった「差分」バックアップは作っていません。毎回、独立した完全なコピーです（鎖の途中が壊れた差分より、ディスクの使用量のほうがましなため）。
  - ゲーム自身も、自分の世代バックアップを作ります（`bIsUseBackupSaveData`）。Noctua のは、それとは別の場所へのコピーです。
- **埋まった人の救出**: `/unstuck` は、プレイヤー自身が使う、ゲーム自身の機能です（動いた実績のある呼び出し）。`guardian.unstuck_auto` は、プレイヤーのカプセルを少し小さくして、地形や建物と重なるかを 5 秒おきに調べます。連続して重なったときだけ動かし、1 人あたりの回数にも上限があります。**最初は `log` にして、誤検知がないかログで確かめてから `rescue` にしてください。**

### 作っていないもの（と、その理由）
- **傾斜や岩肌への建築の緩和**: サーバー側の設定ではできません（建築の可否はクライアント側でも判定されます）。
- **作業パル 50 体**: 拠点レベルの表が 30 で止まるため、まだ届いていません（上の「拠点の設定」）。
- **野生のアペックスパルを自前で出す仕組み**: 実績のある実装（別の管理者向け MOD）は、AI を起こすのに約 16 段の呼び出しが要ります。利用許諾が不明で、MOD なしのクライアントに大きさや光が届くかも確かめられていないため、実機で確かめられるまで作りません。
- **襲撃の敵の構成（ドラゴン・ダーク種の編隊）**: ゲームのデータ表（`DT_PalInvader`）の書き換えが要り、Lua だけではできません。手で出したパルを拠点に攻めさせる方法も、確かめられていません。
- **パル（人ではなく）の自動救出**: ゲームが 1.0 で自前の対策を入れており、全パルを探すのは重いため作っていません。

### 安全のための決まり
- 着地点は、地面を下向きのレイで確かめ、頭の上が空いていて、壁の向こうではない場所だけを使います。地面が見つからなければ飛ばしません。奈落や読み込まれていない場所に落とすことはありません。
- `/tpa` の相手の周りに良い場所がないときは、相手が立っている場所そのものに降ろします。
- 飛んだ後に、実際にその場所に着いたかを確かめます。着いていなければ「テレポートに失敗しました」と伝え、成功とは言いません。
- ゲームの管理者コマンド（`/AdminPassword` など）の行は、Noctua は触らず、ログにも書きません。

### 困ったとき
| 症状 | 見る所 |
|---|---|
| UE4SS.log に `[NOCTUA]` が出ない | `NoctuaCore` の置き場所（`ue4ss\Mods` か `Mods` か）、`enabled.txt`、UE4SS 自体が起動しているか |
| `MISSING /Script/...` | パルワールドの更新で名前が変わっています。止まるのはその機能だけです。Noctua の更新を待ってください |
| `trace self-test: no ground found` | 着地点の判定がこのゲームの版と合っていません。`/home` は安全側に倒して飛ばしません |
| `/stats` の TPS が「計測中」のまま | 最初の 1 秒は計測中と出ます。ずっと出るときは UE4SS.log を見てください |
| キットが渡らず「記録を保存できない」と出る | `data\players.json` が読めません（権限や他のプログラムが開いている）。読めるようになると 5 分以内に自動で再開します。二重に渡さないため、それまで配りません |
| バックアップが始まらない | UE4SS.log の `backup:` の行を見てください。`backup.folder` が空・ワールドのフォルダーの中・パスに使えない文字がある、などを 1 回だけ書きます。`/noctua backup` で状況が見えます |
| Noctua の返事が文字化けする | 日本語の変換がこの UE4SS の版と合っていません。設定の `language` を `"en"` にしてください（英語の返事は ASCII 文字だけです） |
| 設定ファイルが読まれない・作られない | サーバーを日本語などを含まない（ASCII 文字だけの）フォルダーに置いてください。Lua のファイル操作は、Windows では ASCII 以外のパスを開けないことがあります |

### 外し方
`NoctuaCore` フォルダーを消して、サーバーを再起動します。セーブデータには何も残りません。

---

## English

### Requirements
- A Palworld **1.0** dedicated server (Windows `PalServer`). On Linux, run the Windows server under Wine/Proton: UE4SS officially supports Windows only.
- **The Palworld build of UE4SS** (Okaetsu's fork, https://github.com/Okaetsu/RE-UE4SS/releases), which includes the MemberVariableLayout fix Palworld needs. See pwmodding.wiki, "UE4SS installation (server)".
- Noctua's `NoctuaCore` folder.

### Install
1. Stop the server.
2. Install UE4SS into `PalServer\Pal\Binaries\Win64\`. You should now have `Win64\ue4ss\UE4SS.dll` and `Win64\ue4ss\Mods\`.
3. Copy the whole `NoctuaCore` folder into `PalServer\Pal\Binaries\Win64\ue4ss\Mods\`. The release mirrors the server tree, so you can also merge its `PalServer` folder into yours.
   - Only with the legacy UE4SS 3.0.1 layout (`Win64\UE4SS.dll` and `Win64\Mods\`, no `ue4ss` folder) does it go into `Win64\Mods\NoctuaCore\`. UE4SS ignores `Win64\Mods` when `ue4ss\Mods` exists.
   - `enabled.txt` starts the mod; you do not need to edit `mods.txt`.
4. Start the server and check `Win64\ue4ss\UE4SS.log` for `[Lua] [NOCTUA] [INFO] Noctua 1.0.0 ready: 19/19 features on (...)` (UE4SS adds the `[Lua]` prefix). A `MISSING` line means a game update renamed a function. Noctua switches off only the features that need it and keeps the rest running.
5. Keep UE4SS's GUI console off (`[Debug]` in `UE4SS-settings.ini`; check the key names in your version's file). It slows the server down.

### Updating
The release contains neither `config\noctua_settings.json` (your settings) nor `data\players.json` (language choices and kit records): Noctua creates them on first start, so extracting an update over the folder cannot overwrite them. A setting added in a later version works with its default until you add it to the file.

### Commands
Commands start with `/` or `!` (configurable). They are the same as in the Japanese table above: `/help`, `/home [number|list]`, `/tpa <name>`, `/tpaccept [name]`, `/tpdeny [name]`, `/tpcancel`, `/stats`, `/lang ja|en`, `/kit starter` (each item once per player, whatever count the list says later; an item added to the list later is given once to players who already claimed the rest; off by default), `/unstuck` (the game's own move-to-safe-point, refused just after damage) and, for admins, `/noctua health|base|raid|backup|reload|version` (`base` shows the game's current settings, `raid` starts a raid on the nearest base, `backup` shows the backup state). The admin check is the game's own admin state (logged in with the admin password).

**`/` versus `!`**: a `/` line is not shown to other players, but the game itself answers "Unknown command.", and Lua cannot prevent that. A `!` line is ordinary chat to the game, so everyone sees it. Noctua answers both the same way. `chat.hide_commands_experimental = true` should hide both, but it has not been tried on a real server yet.

### Settings
The table above lists every key in `config/noctua_settings.json`. Noctua writes the file with defaults on first boot. After editing it, restart the server or have an admin run `/noctua reload` in game. A bad value falls back to its default for that key only, with the reason in UE4SS.log. You never need to delete the file.

### Base settings (worker Pals and decay)
- **By default Noctua changes nothing.** It touches the game's world settings only when you set `base.worker_max` or `base.disable_decay`.
- **How:** it writes the game's world settings (`BaseCampWorkerMaxNum`, `BuildObjectDeteriorationDamageRate`) at run time, reads them back to prove the write took, and writes again if the game puts the old value back. It should work whatever the ini file or `WorldOption.sav` say, but this has not been tried on a real server.
- **Checking it:** an admin runs `/noctua base` and sees what the game uses now, Noctua's target, the state, and the worker Pal cap the game itself computes for the admin's own guild.
- **Worker Pal cap:** values above 30 are expected not to take effect. The game's per-level table (`DT_BaseCampLevelData`) stops at 30, and Noctua does not rewrite that table yet because its layout is unconfirmed. 30 seconds after start, the table's contents are written once to UE4SS.log (`base-level table probe`). More workers cost server performance (the game's own documentation says so), and how clients display more than 30 slots is unconfirmed.
- **Decay:** only structures outside a base are affected; structures inside base range do not decay anyway. Noctua does not change `bAutoResetGuildNoOnlinePlayers` (the game deleting bases with nobody online). It warns at start-up if it is on.
- **Building on slopes and rock** cannot be relaxed by any server setting. Placement is also checked on the client, so the mods that do it mostly need a client install too. Noctua does not offer it.

### Breeding, encounters and raids (settings Noctua writes into the game)
All of them leave the game alone by default. Like the base settings, Noctua writes the value, reads it back, writes again if the game resets it, and puts the game's own value back when you switch it off. `/noctua base` shows the result.
- **Eggs.** The spec's "make the incubator temperature check pass" cannot be built as written: the game has no pass/fail check, only a speed multiplier (x0.75 to x2). `breeding.optimal_temperature` replaces the temperature difference given to that multiplier with 0 (the best band); it has not run on a live server. `breeding.egg_hatch_hours` writes the game's egg hatching time (hours for the biggest egg; 0 hatches at once); whether the game re-reads it while running is unconfirmed.
- **Passive skill inheritance.** No hook exists to give back a parent's lost passive. What can be done is rewriting the weights for how many passives a child inherits (`breeding.passive_inherit_weights`, experimental). It raises how many are attempted; it does not guarantee a particular passive.
- **Wild apex Pals.** Noctua does not spawn boss-sized Pals itself (see "What is not built"). You can raise the game's own chance of Lucky Pals and rampaging Predator Pals (bigger, red aura) with `encounter.*`. Predators only appear while `EnablePredatorBossPal` is True in the game's settings.
- **Raids.** Frequency and spacing (`raid.*`), and `/noctua raid`, with which an admin starts a raid on the base nearest to them (within 300 m). Nothing happens if `bEnableInvaderEnemy` is False in the game's settings.

### Guarding the world (saves, backups, stuck players)
- **Autosave.** The game already saves by itself (every 30 s by default). `guardian.autosave_minutes` changes that interval; whether a change takes effect while running is unconfirmed.
- **Backups** (`backup.*`), off by default. Every interval Noctua waits until no game save is running and `Level.sav` keeps the same size for `settle_seconds`; starts a small script as a SEPARATE process (so a large copy never stalls the game) that copies the world to `noctua-backup-<UTC time>.partial` and renames it to `noctua-backup-<UTC time>` when finished; checks that the copy's size matches the original's size before and after (a copy made while the game saved is discarded and not counted); and only then removes the oldest folders beyond `backup.keep` and leftovers of interrupted copies. Noctua removes only folders it made, never the one it just made.
  - Each job gets script and result files of its own, tidied when it is over. If a job never answers it is abandoned, and no new job starts until it has answered (after a day it is assumed dead). Switching `backup.enabled` off in the middle of a job cuts the job off; switching it on later never judges the old copy.
  - The copy is only ever a `.partial` folder until it has been checked; Noctua itself renames it, so a torn copy can never be mistaken for a good backup, even if removing it fails.
  - **Use one backup folder per server.** Two servers in one folder pool their retention, and one server's new backups can push out the other's only ones.
  - Paths may contain `( ) [ ] { } ' ~ #` (so `C:/Program Files (x86)/...` works). Refused: `" % ! $` and the backtick, `& | < > ^ ; * ?`, control characters, `..`, relative paths and network paths.
  - It needs the Windows command prompt (robocopy; xcopy under Wine) or Linux `sh`. **The Windows script has not run on a live server.**
  - The spec's "differential" backup is not built: every copy is complete and independent, because a broken link in a chain of partial copies is worse than the disk space.
  - The game keeps its own rolling backups too (`bIsUseBackupSaveData`); Noctua's is an extra copy elsewhere.
- **Stuck players.** `/unstuck` is the players' own command and calls the game's own function (proven in another admin mod). `guardian.unstuck_auto` tests, every 5 s, whether a player's capsule (made slightly smaller) overlaps terrain or buildings, and rescues only after several checks in a row, with a per-hour limit per player. **Start with `log`, read UE4SS.log for false positives, then switch to `rescue`.**

### What is not built (and why)
- **Relaxing slope and rock building limits**: no server setting does it (placement is also checked on the client).
- **50 worker Pals**: the game's per-level table stops at 30, so it is not delivered yet (see "Base settings").
- **Spawning wild apex Pals**: the one working implementation (another admin mod) needs about 16 calls to wake the AI of a spawned Pal, its licence is unclear, and whether size and glow reach vanilla clients is unconfirmed. Not built until it can be checked on a live server.
- **Custom raid compositions (dragon and dark Pal formations)**: this means rewriting the game's data table (`DT_PalInvader`), which Lua alone cannot do; making hand-spawned Pals attack a base is unproven.
- **Automatic rescue of stuck Pals** (as opposed to players): the game already fixed much of this in 1.0, and finding every Pal is expensive.

### Safety rules
- Noctua lands a player only on ground found by a downward line trace, with free headroom and nothing solid between the spot and the destination. If no ground is found, nobody is moved: never into the void or unloaded terrain.
- For `/tpa`, if nothing suits around the target, the player lands exactly where the target is standing.
- Arrival is checked after the teleport. If the character did not arrive, the player is told the teleport failed.
- The game's own admin commands (`/AdminPassword` and so on) are never touched or logged.

### Troubleshooting
- No `[NOCTUA]` lines: check where `NoctuaCore` is (`ue4ss\Mods` or `Mods`), that `enabled.txt` is there, and that UE4SS itself starts.
- `MISSING /Script/...`: a game update renamed that function; only the features that need it are off until Noctua is updated.
- `trace self-test: no ground found`: landing checks do not match this game version, so `/home` refuses to move anyone (the safe side).
- Garbled replies: the UTF-8 conversion in this UE4SS build does not suit Japanese; set `language` to `"en"` (English replies are plain ASCII).
- Config not read or not created: install the server in a folder whose path is ASCII only. Lua's file functions may not open non-ASCII paths on Windows.

### Removing Noctua
Delete the `NoctuaCore` folder and restart. Nothing is left in the save.
