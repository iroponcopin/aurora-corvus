OUKA V1.0.0
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - ouka-1.0.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Fabric API を同じフォルダーに入れる(上の版以上)。
3. サーバーで遊ぶ場合は、サーバー側にも同じ 2 つと Fabric API を入れる。

■ ご注意
- GeckoLib はこの zip に同梱しています。ほかの MOD が同じ GeckoLib を入れている場合は、
  どちらか 1 つだけを残してください。2 つあると起動しません。
- 設定ファイルはありません。管理者用のコマンドもありません。

■ OUKA ビーコン
- 3×3×3 の構造物です。置いた場所が最下段の中央になります。
- 台座が要ります。ネザライト・ダイヤ・エメラルド・桜花合金のブロックを、
  8 段(3・3・5・5・7・7・9・9)で **328 個**。全部そろって初めて起動します。
- 起動すると、**半径 1,000 ブロック**の中にいるプレイヤー全員に効果を配ります。
  ビーコンのいる区画が読み込まれていなくても届きます。観戦者には配りません。
- 配る効果は 10 種類(移動速度・採掘速度・攻撃速度・攻撃力・跳躍・落下耐性・
  衝撃吸収・再生・満腹度・耐性と部分的な耐火・暗視)で、それぞれ **0.00 から 20.00 まで
  段階なし**で決められます。あわせて、エンチャントの金リンゴと同じ効果が常時つきます。
- ビーコンのどこかを右クリックすると、**すりガラスの端末**が開きます。スライダーを
  ドラッグ、マウスホイールで 0.1 刻み、Shift を押しながらで 0.01 刻み。
  ALL MAX / DEFENSIVE MATRIX / MINER'S PARADISE の 3 つの一括設定があります。
- 変更できるのは、置いた本人か OP だけです(8 ブロック以内)。ほかの人には読み取り専用で開きます。
- どこか 1 つでも壊すと 27 個すべてが外れ、設定を持ったビーコンが 1 つ落ちます。

■ サークル弾
- 桜花の杖(Ouka Caster)は 0.25 秒ごとに 1 発。直線・螺旋・追尾。
- 弾幕の焦点(Danmaku Focus)は 2 秒ごとに一斉射。収束(見ている点に 12 発)と
  周囲滞空シールド(8 発が回り、6 ブロック以内の敵へ飛ぶ)。
- どちらもスニーク+右クリックで、色と弾道を選ぶホログラムの画面が開きます。
- 色は 12 種類。それぞれ効果が違います(鈍化と魅了、画面の閃光、火柱、
  不死者へ倍の傷、引き寄せ、凍結、味方の回復と敵への毒、壁を貫く直線、
  索敵範囲を 8 割削る、2 つに分かれて追尾、3 回跳ね返る、ほか 11 色を巡る)。
- 着弾した場所から平らな輪が広がり、**通った敵を消滅させます**。ボスには最大体力の 2 割。
  プレイヤー・ペット・動物には当たりません。ブロックは壊れず、燃えません。
- 飛んでいる弾はその色の軌跡を残します。桜花桃だけは桜の花びらで、何秒も落ち続けます。

■ 道具とレシピ
- 桜花合金インゴット / 桜花合金ブロック(相互に変換できます)
- OUKA ビーコン
- 桜花の杖(Ouka Caster)
- 弾幕の焦点(Danmaku Focus)
  レシピはゲーム内のレシピ本で見られます。

■ マルチプレイ
- サーバーとクライアントの両方に入れてください。
- 端末の操作はすべてサーバー側で確かめています。範囲外の値や、権限のない変更は通りません。

■ ライセンス
- OUKA: MIT(LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT(LICENSES/GeckoLib_MIT.txt)。改変せずそのまま同梱しています。

------------------------------------------------------------------

[English]

■ What you need
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

■ Installing (on both the client and the server)
1. Put the two jars from this zip's mods/ folder into your Minecraft mods folder.
   - ouka-1.0.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Put Fabric API in the same folder (the version above or newer).
3. To play on a server, install the same two jars and Fabric API on the server as well.

■ Please note
- GeckoLib is bundled in this zip. If another mod already installs GeckoLib, keep only
  one copy — two will stop the game from starting.
- There is no config file and there are no admin commands.

■ The OUKA Beacon
- A 3×3×3 structure. Where you place it becomes the middle of the bottom layer.
- It needs a pedestal: **328 blocks** of netherite, diamond, emerald or Ouka alloy,
  in eight layers (3, 3, 5, 5, 7, 7, 9, 9). It only wakes when all 328 are present.
- Once awake it reaches every player within **1,000 blocks**, even while the beacon's
  own area is unloaded. Spectators receive nothing.
- It gives ten effects (speed, mining speed, attack speed, strength, jump, safe fall,
  absorption, regeneration, food, resistance with partial fire resistance, and night
  vision), each tuned **steplessly from 0.00 to 20.00**, plus the constant effects of
  an enchanted golden apple.
- Right-click any part of it to open a **frosted-glass terminal**: drag a slider, or use
  the mouse wheel in steps of 0.1, or 0.01 with Shift. Three presets are provided:
  ALL MAX, DEFENSIVE MATRIX and MINER'S PARADISE.
- Only the player who placed it, or an operator, may change it, and only from within
  8 blocks. Everyone else sees a read-only terminal.
- Breaking any part removes all 27 and drops one beacon carrying its tuning.

■ The circle projectiles
- The Ouka Caster fires one circle every 0.25 s: straight, spiral or homing.
- The Danmaku Focus fires a barrage every 2 s: converging (twelve circles onto the point
  you are looking at) or orbital guard (eight circles orbit you and launch at an enemy
  within 6 blocks).
- Sneak and use either item to open a holographic selector for colour and trajectory.
- There are twelve colours, each with its own effect: slowness and charm, a screen flash,
  a plasma pillar, double damage to the undead, a pull, a freeze, healing for allies and
  poison for enemies, a line that pierces walls, an 80% cut to a mob's follow range, a
  split into two homing circles, three bounces, and one that cycles the other eleven.
- Where a circle stops, a flat ring spreads and **erases the enemies it crosses**; bosses
  take 20% of their maximum health instead. Players, pets and animals are untouched, and
  no block is broken or set alight.
- A circle in flight leaves a trail in its own colour. Sakura Pink leaves cherry petals,
  which keep falling for several seconds.

■ Items and recipes
- Ouka Alloy Ingot / Block of Ouka Alloy (each converts to the other)
- OUKA Beacon
- Ouka Caster
- Danmaku Focus
  The recipes are in the in-game recipe book.

■ Multiplayer
- Install on both the server and the client.
- Every terminal action is checked on the server: values outside the range, and changes
  from anyone without permission, are refused.

■ Licences
- OUKA: MIT (LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT (LICENSES/GeckoLib_MIT.txt), bundled unmodified.
