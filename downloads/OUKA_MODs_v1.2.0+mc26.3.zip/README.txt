OUKA V1.2.0
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - ouka-1.2.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Fabric API を同じフォルダーに入れる(上の版以上)。
3. サーバーで遊ぶ場合は、サーバー側にも同じ 2 つと Fabric API を入れる。

■ ご注意
- GeckoLib はこの zip に同梱しています。ほかの MOD が同じ GeckoLib を入れている場合は、
  どちらか 1 つだけを残してください。2 つあると起動しません。
- 前の版から入れ替えるときは、古い OUKA の jar(ouka-1.1.0+mc26.3.jar・ouka-1.0.1+mc26.3.jar など)を
  mods フォルダーから消してください。OUKA の jar が 2 つあると起動しません。
- 設定ファイルはありません。管理者用のコマンドもありません。

■ V1.2「The Heavy Industrial & Kinematics Epoch」—— 重工業の 20 品
- 機械はどれも OUKA の電力網で動きます。電力網はテスラパイロンがつなぎ、ケーブルは要りません。
- どの機械も、動きと音が働きぶりに合わせて変わります(音はすべて一から合成したもので、録音は使っていません)。
- レシピはすべて最初からレシピ本に出ます。

■ 電力(発電・送電・蓄電)
- 超高圧送電テスラパイロン(2 段): **64 ブロック以内**で届き合うパイロンが 1 つの網になり、網の近くの OUKA の機械へ
  無線で電気を配ります。電気が流れている間は、パイロンから機械へ青白い放電の弧が走ります。
- 超伝導磁気蓄電ブロック(SMES): **400 MJ**、充電・放電とも最大 **2 MW**、ロスはありません。面のホログラムに充電の割合。
- 重水減速型核分裂リアクター(5×5×5): ウラン・トリウムの燃料棒で最大 **2 MW**。炉心はチェレンコフ光で青く光ります。
  炉が 800 °C に届くと制御棒が落ちて止まり(スクラム)、冷えて冷却水が来ると動き出します。爆発はしません。
  冷却水は取水タービンから網を通って届きます。
- 太陽熱集光蓄熱タワー(3×3×8): 周り 16 ブロック以内のヘリオスタット(平面鏡、最大 32 枚)が日の光を集め、
  溶融塩に熱を蓄えます。タービンは最大 **400 kW** で、網の求めに合わせて出し、夜も蓄えから出し続けます。
  屋根の下の鏡は集めません。

■ 格納と物流
- 超次元量子圧縮サイロ(5×5×7): チタン外殻・耐熱ガラス・入出力ポートで外殻を組み、側面に制御盤を置くと完成します。
  **2,147,483,647 個**まで格納でき、画面で中身を一覧し、名前や「@MOD 名」で絞り込めます。
  ポート(底面と各側面)はホッパー・コンベア・ほかの MOD の管とそのままつながります。
  制御盤を壊すと中身の札を持った制御盤が落ち、別の場所で組み直せば同じ中身です。
- 高速超伝導リニアコンベア: **毎秒 20 個**を運びます。形(直線・カーブ・坂)は隣から自動で決まり、
  品は落ちず、詰まると並んで待ちます。運ぶ品はブロックに載ったまま見えます。
- リニアコンベアの分岐器: 左・前・右へ 1 つずつ順に分けます。詰まった出口は飛ばします。
- 波長分光式インテリジェント・ソーター: 通る品を、面ごとの決まり(品・タグ・MOD・データ成分・傷んでいるか)で 6 方向へ振り分けます。
- 自律型物流ドローンステーション(3×3): 行き先の港でドローン航路カードをしゃがんで使い、送る港で使うと、
  **Ouka-Cargo Drone** が荷を積んで港どうしを往復します。行き先では甲板(その港のドローンの場所)に降りず、港の脇で浮いたまま
  荷を渡します。区画が読み込まれていない間も、飛ぶ時間ぶん遅れて荷は届きます。

■ 精錬と加工
- 電弧重熱精錬炉(3×3×4): 鉱石を一度に **32 個**入れられ、かまどの **16 倍**の速さで精錬します。
  溶けた金属が樋を流れ、型に流し込まれるのが見えます。
- 超高圧油圧クラッシャー(2 段): 鉱石・原石 1 つから粉 2 つ(粉は精錬してインゴットに)、インゴットからは板を作ります。
  油圧でハンマーを持ち上げ、一気に叩きつけます。
- 高精度オートメーション組立ライン(1×4×2): 3 本のロボットアームとプレスが、電子回路・複合素材の板・機械の骨組みを
  組み立てます。溶接の火花が散ります。
- 分子遠心分離抽出機: 土・砂・砂利(と月のレゴリス)から、チタン・リチウム・石英・ヘリウム3 を微量に取り出します。
  ウランの粉からは確率で濃縮ウラン。

■ 採掘と収穫
- 地殻深層掘削クァーリー(4×4×6): 岩盤を壊さずに、深い鉱脈から鉱石・原油の缶を掘り続けます。
  **ジ・エンドでは掘りません**(ネザーではネザーの鉱石)。
- 超大型重水取水タービン(3×3×3): 水の上に置くと、下の水源から水を汲み上げます(深さ 2 の池で最大、**毎秒 200 バケツ**)。
  汲んだ水は網を通して、水を使う機械(核分裂リアクター・培養槽)へ届きます。
- 自律型重機製材ミル(3×3×2): 周り 8 ブロックの木を見つけて、上から切り倒し、板材にして、切り株に苗を植え直します。
- バイオリアクター培養槽(3×3×3): 有機物と水から、工業用プラスチック・潤滑油の缶・スタミナ増強剤を培養します。

■ 道具と装備
- 万能工業ラチェット: 機械を右クリックで前後を反転(中身と仕事はそのまま)。スニークして右クリックで、
  分岐器・ソーターの出口やコンベアの出口を開け閉めします。電力で動く加工機械では **オーバークロックの盤**が開き、
  速さを ×1.00〜×2.50 から選べます(速くするほど、品 1 つにかかる電力も増えます)。
- 携帯型熱分解カッター: OUKA の機械を 1 秒ねらい続けると、中身ごと持ち物へ解体します(1 滴もこぼしません)。
- 回路投影ブループリント: 向かい合う 2 つの角をスニークして使うと、その間(1 辺 16 マスまで)を写します。
  写したブループリントを持つと、建つ場所に**実物大の半透明のホログラム**が映り(置ける所は水色・品が足りない所は琥珀色・
  ふさがった所は赤)、使うと持ち物の品で建てます。
- 全天候型重工業防護外骨格(4 部位): 4 つそろえると、感電・熱・落下で傷つかず、溶岩の中を泳げ、採掘が 3 倍の速さになります。

■ V1.1.0 からの直し
- 桜花合金ブロックを掘っても何も落ちなかったのを直しました。
- シェルターの落とし物の表が古い形式だったのを直しました。

■ OUKA ビーコン
- 3×3×3 の構造物です。置いた場所が最下段の中央になります。
- 台座が要ります。ネザライト・ダイヤ・エメラルド・桜花合金のブロックを、
  8 段(3・3・5・5・7・7・9・9)で **328 個**。全部そろって初めて起動します。
- 起動すると、**半径 1,000 ブロック**の中にいるプレイヤー全員に効果を配ります。
  ビーコンのいる区画が読み込まれていなくても届きます。観戦者には配りません。
- 配る効果は 10 種類(移動速度・採掘速度・攻撃速度・攻撃力・跳躍・落下耐性・
  衝撃吸収・再生・満腹度・耐性と部分的な耐火・暗視)で、それぞれ **0.00 から 20.00 まで
  段階なし**で決められます。あわせて、エンチャントの金リンゴと同じ効果が常時つきます。
- ビーコンのどこかを右クリックすると、**すりガラスの端末**が開きます。スライダーを
  ドラッグ、マウスホイールで 0.1 刻み、Shift を押しながらで 0.01 刻み。
  ALL MAX / DEFENSIVE MATRIX / MINER'S PARADISE の 3 つの一括設定があります。
- 変更できるのは、置いた本人か OP だけです(8 ブロック以内)。ほかの人には読み取り専用で開きます。
- どこか 1 つでも壊すと 27 個すべてが外れ、設定を持ったビーコンが 1 つ落ちます。

■ サークル弾
- 桜花の杖(Ouka Caster)は 0.25 秒ごとに 1 発。直線・螺旋・追尾。
- 弾幕の焦点(Danmaku Focus)は 2 秒ごとに一斉射。収束(見ている点に 12 発)と
  周囲滞空シールド(8 発が回り、6 ブロック以内の敵へ飛ぶ)。
- どちらもスニーク+右クリックで、色と弾道を選ぶホログラムの画面が開きます。
- 色は 12 種類。それぞれ効果が違います(鈍化と魅了、画面の閃光、火柱、
  不死者へ倍の傷、引き寄せ、凍結、味方の回復と敵への毒、壁を貫く直線、
  索敵範囲を 8 割削る、2 つに分かれて追尾、3 回跳ね返る、ほか 11 色を巡る)。
- 着弾した場所から平らな輪が広がり、**通った敵を消滅させます**。ボスには最大体力の 2 割。
  プレイヤー・ペット・動物には当たりません。ブロックは壊れず、燃えません。
- 飛んでいる弾はその色の軌跡を残します。桜花桃だけは桜の花びらで、何秒も落ち続けます。

■ オペレーティング・シェルター・ブロック(V1.1 で追加)
- **OP 権限を持つ人だけ**が置けて、壊せます。ほかの人はどのゲームモードでも一切できません。
- どんな爆発も通りません。Mob も、ピストンも、クリエイティブの破壊も通しません。
  バニラが岩盤を入れている 11 のタグすべてに、同じように入れてあります。
- OP はサバイバルでも普通に掘れて回収できます(ダイヤ以上のつるはし)。
- OP でない人が触れると、面に六角のエネルギー格子が張り、金属の反発音と火花が返ります。
- 作り方: 黒曜石 4・ネザライトインゴット 4・桜花合金ブロック 1 で 2 個。

■ 音
- 音はすべて **OUKA のために一から作ったもの**です(56 種)。ほかのゲームの音も、素材集の音も、
  録音も使っていません。
- **12 色は 12 半音。**サークル弾の音は色ごとに高さが違い、桜花桃から神光虹までが
  ちょうど 1 オクターブに収まります。**音を聞けば、どの色が飛んだか分かります。**
- 祭壇は、組み上がるとき・目を開けるとき・閉じるとき・解体されるときに鳴り、
  起動しているあいだは低い唸りを出します。
- 端末を開いた音や、変更が断られた音は、**その本人にだけ**聞こえます。
- 字幕(「サブタイトルを表示」)に対応しています。

■ 道具とレシピ
- 桜花合金インゴット / 桜花合金ブロック(相互に変換できます)
- OUKA ビーコン
- 桜花の杖(Ouka Caster)
- 弾幕の焦点(Danmaku Focus)
- V1.2 の機械・道具・装備・素材(上の V1.2 の節)
  レシピはゲーム内のレシピ本で見られます。

■ マルチプレイ
- サーバーとクライアントの両方に入れてください。
- 端末の操作はすべてサーバー側で確かめています。範囲外の値や、権限のない変更は通りません。
- オーバークロックの盤も同じです。ラチェットを持ち、8 ブロック以内にいて、そこで建築できる人だけが変えられ、
  ×1.00〜×2.50 の外の値は通りません。

■ ライセンス
- OUKA: MIT(LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT(LICENSES/GeckoLib_MIT.txt)。改変せずそのまま同梱しています。

------------------------------------------------------------------

[English]

■ What you need
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

■ Installing (on both the client and the server)
1. Put the two jars from this zip's mods/ folder into your Minecraft mods folder.
   - ouka-1.2.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Put Fabric API in the same folder (the version above or newer).
3. To play on a server, install the same two jars and Fabric API on the server as well.

■ Please note
- GeckoLib is bundled in this zip. If another mod already installs GeckoLib, keep only
  one copy — two will stop the game from starting.
- When updating from an earlier version, remove the old OUKA jar (ouka-1.1.0+mc26.3.jar, ouka-1.0.1+mc26.3.jar
  and so on) from the mods folder. Two OUKA jars will stop the game from starting.
- There is no config file and there are no admin commands.

■ V1.2 "The Heavy Industrial & Kinematics Epoch" — twenty pieces of heavy industry
- Every machine runs on OUKA's power grid. Tesla pylons join the grid; there are no cables.
- Every machine's movement and sound follow how hard it is working. Every sound is synthesised from nothing;
  nothing is recorded.
- Every recipe is in the recipe book from the start.

■ Power (generation, transmission, storage)
- Wireless Tesla Pylon (two blocks tall): pylons within **64 blocks** of one another form one grid and power the
  OUKA machines near it without wires. While power flows, blue-white arcs run from the pylon to the machines.
- SMES Quantum Battery: **400 MJ**, charging and discharging at up to **2 MW**, with no loss. A hologram on its face
  shows the charge.
- Heavy-Duty Fission Core (5×5×5): up to **2 MW** from uranium or thorium fuel rods. The core glows blue with
  Cherenkov light. At 800 °C the control rods drop and it stops (a scram); it restarts once it has cooled and
  coolant is arriving. It never explodes. Coolant water reaches it through the grid from the desalinator.
- Solar-Thermal Molten Salt Tower (3×3×8): heliostats (flat mirrors, up to 32) within 16 blocks gather sunlight
  and store the heat in molten salt. The turbine gives up to **400 kW**, follows what the grid asks for, and keeps
  running at night on what it stored. A mirror under a roof gathers nothing.

■ Storage and logistics
- Quantum-Compression Vault (5×5×7): build the shell from titanium casing, heat-resistant glass and I/O ports, then
  place the controller on a side to complete it. It holds up to **2,147,483,647 items**; its screen lists the contents
  and filters them by name or by "@mod". The ports (the bottom and each side) connect straight to hoppers, conveyors
  and other mods' pipes. Breaking the controller drops it with a tag of the contents; build the shell again anywhere
  and the contents are the same.
- Maglev Conveyor: carries **20 items a second**. Its shape (straight, curve, slope) follows its neighbours
  automatically. Nothing falls off; when the way is blocked, items queue and wait. You can see each item riding it.
- Maglev Splitter: hands items out one at a time — left, front, right — and skips an exit that is blocked.
- Spectral Sorter: sends each passing item in one of six directions by per-face rules (item, tag, mod,
  data component, or damaged).
- Logistics Drone Port (3×3): sneak-use a Drone Route Card on the destination port, then use it on the sending
  port, and an **Ouka-Cargo Drone** carries loads between the two. At the destination it does not land on the deck,
  which is that port's own drone's place: it hovers beside the port and hands the load over. While the area is
  unloaded, the load still arrives, delayed by the flight time.

■ Smelting and processing
- Blast-Arc Smelting Foundry (3×3×4): takes **32 ores** at a time and smelts **16 times** faster than a furnace.
  You can watch the molten metal run down the trough into the moulds.
- Hydraulic Impact Crusher (two blocks tall): one ore or raw ore makes two dusts (smelt dust into ingots); an ingot
  makes a plate. The hydraulics lift the hammer and slam it down.
- Automated Precision Assembly Line (1×4×2): three robot arms and a press assemble electronic circuits, composite
  plates and machine frames, with welding sparks.
- Molecular Centrifuge Extractor: draws traces of titanium, lithium, quartz and helium-3 from dirt, sand and gravel
  (and lunar regolith). From uranium dust it sometimes yields enriched uranium.

■ Mining and harvesting
- Sub-Crustal Thermal Bore (4×4×6): digs ore and crude oil canisters from deep veins without end, without breaking
  bedrock. **It does not dig in the End** (in the Nether it digs Nether ores).
- Hydro-Vapor Desalinator (3×3×3): placed over water, it pumps from the sources below (at most **200 buckets a
  second**, from a pond two blocks deep). The grid carries the water to the machines that use it (the fission core
  and the culture vat).
- Automated Timber Mill (3×3×2): finds trees within 8 blocks, fells them from the top down, turns them into planks
  and replants the stump.
- Bio-Reactor Culture Vat (3×3×3): cultures industrial plastic, lubricant canisters and stamina serum from organic
  matter and water.

■ Tools and gear
- Industrial Omni-Wrench: use it on a machine to turn it front to back (its contents and work carry on). Sneak-use
  it to open or close a splitter's or sorter's exit, or a conveyor's exit. On a powered processing machine it opens
  the **overclock panel**: choose a speed from ×1.00 to ×2.50 (the faster, the more power each item costs).
- Thermal Demolition Laser: hold it on an OUKA machine for one second and the machine comes apart into your
  inventory with everything inside it (not a drop is spilt).
- Holographic Circuit Blueprint: sneak-use two opposite corners to record what lies between them (up to 16 blocks
  a side). While you hold the recorded blueprint, a **life-size translucent hologram** shows where it will stand
  (cyan where it can be placed, amber where you are short of items, red where the space is taken); use it to build
  it from the items you carry.
- Industrial Hazard Exoskeleton (four pieces): wear all four and electric shocks, heat and falls no longer hurt you,
  you can swim in lava, and you mine three times as fast.

■ Fixed since V1.1.0
- Mining a Block of Ouka Alloy now drops it (it dropped nothing).
- The shelter's loot table was in an old format; it is fixed.

■ The OUKA Beacon
- A 3×3×3 structure. Where you place it becomes the middle of the bottom layer.
- It needs a pedestal: **328 blocks** of netherite, diamond, emerald or Ouka alloy,
  in eight layers (3, 3, 5, 5, 7, 7, 9, 9). It only wakes when all 328 are present.
- Once awake it reaches every player within **1,000 blocks**, even while the beacon's
  own area is unloaded. Spectators receive nothing.
- It gives ten effects (speed, mining speed, attack speed, strength, jump, safe fall,
  absorption, regeneration, food, resistance with partial fire resistance, and night
  vision), each tuned **steplessly from 0.00 to 20.00**, plus the constant effects of
  an enchanted golden apple.
- Right-click any part of it to open a **frosted-glass terminal**: drag a slider, or use
  the mouse wheel in steps of 0.1, or 0.01 with Shift. Three presets are provided:
  ALL MAX, DEFENSIVE MATRIX and MINER'S PARADISE.
- Only the player who placed it, or an operator, may change it, and only from within
  8 blocks. Everyone else sees a read-only terminal.
- Breaking any part removes all 27 and drops one beacon carrying its tuning.

■ The circle projectiles
- The Ouka Caster fires one circle every 0.25 s: straight, spiral or homing.
- The Danmaku Focus fires a barrage every 2 s: converging (twelve circles onto the point
  you are looking at) or orbital guard (eight circles orbit you and launch at an enemy
  within 6 blocks).
- Sneak and use either item to open a holographic selector for colour and trajectory.
- There are twelve colours, each with its own effect: slowness and charm, a screen flash,
  a plasma pillar, double damage to the undead, a pull, a freeze, healing for allies and
  poison for enemies, a line that pierces walls, an 80% cut to a mob's follow range, a
  split into two homing circles, three bounces, and one that cycles the other eleven.
- Where a circle stops, a flat ring spreads and **erases the enemies it crosses**; bosses
  take 20% of their maximum health instead. Players, pets and animals are untouched, and
  no block is broken or set alight.
- A circle in flight leaves a trail in its own colour. Sakura Pink leaves cherry petals,
  which keep falling for several seconds.

■ The Operating Shelter Block (added in V1.1)
- **Only a player with operator permission** can place or break it. Nobody else can, in any
  game mode.
- No explosion gets through, and neither does a mob, a piston, or a creative-mode break.
  It sits in all eleven block tags that vanilla puts bedrock in.
- An operator mines it normally in survival and gets it back (a diamond pickaxe or better).
- When anyone else touches it, a hexagonal energy lattice snaps across its faces, with a
  metallic repulsion and sparks.
- Crafted from 4 obsidian, 4 netherite ingots and 1 block of Ouka alloy, for 2.

■ Sound
- Every sound (fifty-six of them) was **made from nothing for OUKA**. No sound from another
  game, no sample library, no recording.
- **Twelve colours are twelve semitones.** Each circle colour sounds at its own pitch, from
  Sakura Pink to Prismatic Chroma, exactly one octave apart end to end — **you can hear
  which colour flew.**
- The beacon sounds when it is assembled, when it wakes, when it closes and when it breaks
  apart, and hums quietly while it is awake.
- Opening the terminal, and being refused by it, are heard **only by the player it happened
  to** — nobody nearby hears them.
- Subtitles are supported.

■ Items and recipes
- Ouka Alloy Ingot / Block of Ouka Alloy (each converts to the other)
- OUKA Beacon
- Ouka Caster
- Danmaku Focus
- V1.2's machines, tools, gear and materials (the V1.2 section above)
  The recipes are in the in-game recipe book.

■ Multiplayer
- Install on both the server and the client.
- Every terminal action is checked on the server: values outside the range, and changes
  from anyone without permission, are refused.
- So is the overclock panel: only a player holding the wrench, within 8 blocks, who may build
  there can change it, and nothing outside ×1.00 to ×2.50 is accepted.

■ Licences
- OUKA: MIT (LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT (LICENSES/GeckoLib_MIT.txt), bundled unmodified.
