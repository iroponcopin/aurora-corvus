OUKA V1.3.0
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - ouka-1.3.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Fabric API を同じフォルダーに入れる(上の版以上)。
3. サーバーで遊ぶ場合は、サーバー側にも同じ 2 つと Fabric API を入れる。

■ ご注意
- GeckoLib はこの zip に同梱しています。ほかの MOD が同じ GeckoLib を入れている場合は、
  どちらか 1 つだけを残してください。2 つあると起動しません。
- 前の版から入れ替えるときは、古い OUKA の jar(ouka-1.2.0+mc26.3.jar・ouka-1.1.0+mc26.3.jar・ouka-1.0.1+mc26.3.jar など)を
  mods フォルダーから消してください。OUKA の jar が 2 つあると起動しません。
- 設定ファイルはありません。管理者用のコマンドもありません。

■ V1.3「The Washitsu Architectural Masterpiece」—— 和室の 30 品と、工場の設備 10 種
- 和室の 30 品は、クリエイティブの新しいタブ「OUKA 和室」にまとまっています。工場の設備は OUKA のタブにあります。
- 電気で動く設備は、V1.2 の機械と同じく OUKA の電力網から電気を受けます。
- 新しい音 37 種は、すべて一から合成したものです。ブロックを壊す音や木を置く音などには、バニラの音も使います
  (くわしくは下の「音」の節)。
- レシピはすべて最初からレシピ本に出ます。

■ 和室: 床(畳・縁側・天井・壁)
- 本藺草仕立て畳: 1 枚で 2 マス。素手で右クリックすると、縁(へり)の柄が替わります(4 種)。
- **8 マス以上**つながった畳の部屋に立つと「スタミナ増強」が付き、満腹度の減りが半分になります。
- 縁なし市松畳: 隣の市松畳と直角の向きに敷かれ、並べると市松模様になります。しゃがんで素手で右クリックすると
  向きが替わります。畳の部屋のマスとしても数えられます。
- 桧磨き縁側床・杉目透かし天井板・聚楽土壁。天井板は固いブロックの下にだけ張れます。
  畳と縁側は、踏むとそれぞれの足音がします。

■ 和室: 障子と襖
- 本障子・金箔山水 襖: 2 マスの高さの引き戸です。素手の右クリックか、レッドストーンの信号で、
  ほぼ 1 ブロック滑って開け閉めします。開いていれば通り抜けられます。
- 同じ向きの戸の隣に置くと別の溝に入り、2 枚がすれ違って開きます(引き違い)。
- 襖は 4 枚並べると、1 枚の山水画になります。

■ 和室: 鴨居と、掛けるもの・吊るすもの
- 鴨居・長押フレーム: 欄間・透かし彫りを鴨居に使うと、鴨居の上に嵌まります。四季の掛け軸と二本掛け刀掛け台は
  (欄間を嵌めていない)長押の面に掛けられ、高級竹簾・藍染家紋暖簾・鉄器の風鈴は鴨居の下に吊るせます。
- 欄間・透かし彫り: しゃがんで使えば 1 枚で立ちます。光を通します。
  素手の右クリックで図柄が替わります(松に鶴・波千鳥)。
- 四曲金屏風: 置いた所を左下に、横 2 マス・高さ 2 マスに立ちます。
- 高級竹簾: 素手の右クリックで巻き上げます(全閉・半開・全開)。縦に 3 マスまで継いで 1 本の簾になります。
- 藍染家紋暖簾: 人がくぐると、布がめくれます。
- 簾・暖簾・風鈴は、鴨居か固いブロックの下に吊るします。支えが無くなると落ちます。

■ 和室: 調度
- 欅無垢座卓: 天板の 4 つの区画に、品を持って右クリックすると 1 つずつ飾れます(素手で取り戻します)。
  しゃがめばブロックを置けます。本格茶道 茶筅・抹茶碗セットと漆塗り 重箱は、座卓の上に置くと天板に載ります。
- 錦織の座布団と殿様脇息・座椅子: 素手で右クリックすると座り、しゃがむと立ちます。
  殿様脇息・座椅子は置いた人の方を向き、1 脚に 1 人です。
- 漆金具 桐箪笥: **27 枠**。ホッパーでもチェストと同じように出し入れでき、開けている間は引き出しが出ます。
- 本格茶道 茶筅・抹茶碗セット: 素手で右クリックすると茶を点て(2 秒)、もう一度右クリックすると飲みます。
  体力が全回復し、採掘速度上昇 II が **3 分**付きます。1 服は **5 分に 1 度**で、死んでもこの待ち時間は消えません。
- 漆塗り 重箱: バニラの食べ物だけが、3 段 × 3 つ入ります。壊しても中身は品の中に残り、置けば戻ります。
  火で焼け落ちません。

■ 和室: 床の間と坪庭
- 絞り丸太 床柱・四季の掛け軸: 掛け軸は 2 マスの高さで、壁か鴨居の長押に掛けます。
  絵はゲームの中の **8 日ごと**に季節で替わります(桜・滝・紅葉・雪嶺)。
- 竹筒生け花、銘木台座 水石、青磁香炉・伽羅香は、下に支えがあるときだけ立ちます。
  香炉からは一筋の香煙が昇ります。素手で消し、火打石と打ち金でまた火をつけられます。
- 二本掛け刀掛け台: 剣を持って右クリックすると掛けます(2 本まで)。素手で上の段から取ります。
  床に置くか、壁か鴨居の長押に掛けます。
- 角行灯・六角雪洞・御影石 雪見灯籠: 素手の右クリックで灯し、消します。雪洞は 2 マスの高さです。
  雪見灯籠の笠には、冬(32 日のうち 24〜31 日目)と、雪の降る寒い所では季節を問わず、雪が積もります。
- 庭園 鹿威し: 竹筒が水を溜めては傾き、**4.4 秒ごと**に受け石を打ちます。
- 鉄器の風鈴: 風で鳴ります。晴れのそよ風でも時おり、雨や雷雨ではよく鳴り、閉じた部屋の中では鳴りません。
- 榧の木碁盤・将棋盤: 素手で交点を右クリックすると、黒と白の碁石を交互に打ちます(9 路)。しゃがんで右クリックすると
  石を取ります。しゃがんで素手で盤の横を右クリックすると、碁盤と将棋盤が切り替わります(石は片付きます)。

■ 工場: 物流
- 超高加速インパルス・ホッパー: 上の器から吸い出し、上に落ちた品を吸い込み、吐き口の先のチェストやほかの MOD の管へ
  **1 tick に 64 個**(バニラのホッパーの 512 倍)押し出します。OUKA のコンベアへは 1 tick に 1 個です。
  しゃがんで素手で使うとフィルターの画面が開きます(5 マス。それぞれ完全一致・タグ一致・耐久値無視)。
  レッドストーンの信号で止まります。電気は要りません。
- OUKA式 空間転送トランシーバー [32m]: 器(チェスト・大釜・機械・サイロのポート)の面に置き、
  共振リンカーを送信機に、次に受信機に使って結びます。送信機 1 基から受信機 **4 基**まで、
  どの向きでも **32 ブロック**以内なら壁を越えて、1 tick に最大 **64 個**(画面で 1〜64)と **1 バケツ**を送ります。
  同じ次元の中だけです。電気は要りません。
- 量子サイロ直結I/Oバス: 量子圧縮サイロの部位の面に置き、後ろに器かコンベアを置きます。
  搬出では、選んだ品(**9 項目**まで)を、項目ごとの維持数をサイロに残して、後ろのチェストやほかの MOD の管へ
  **1 tick に 256 個**まで出します(OUKA のコンベアへは 1 tick に 1 個)。
  搬入では、後ろの器の品をすべてサイロへ入れます。電気は要りません。
- 超伝導加圧流体ポンプと超伝導加圧流体 導管: ポンプは、置くときに押した面の器から汲み、ほかの 5 つの面の
  導管へ送ります。**1 tick に 8 バケツ**を、導管の網のすべての行き先へ順番に、同じ tick のうちに配ります
  (水・溶岩・ほかの MOD の液体)。網は導管 **4,096 本**まで。ポンプは電気で動き(10 kW)、導管は電気を使いません。
  核分裂リアクターと培養槽は、導管から届く水でも動きます。
- 次元同期ポータブル端末: 組まれたサイロの制御盤に使って結び、何も無い所で使うと、そのサイロの画面が
  開きます(別の次元からでも)。持ち物(ホットバーとこの端末を除く)をまとめてサイロへ預けられます。
  結んだ端末を持っている人なら誰でも開けるので、鍵と同じように大切に持っていてください。

■ 工場: 生産
- 火山熱水式 造石・超粉砕機: 溶岩と水を 1 バケツずつ入れておけば、どちらも減らずに、丸石(**8 tick に 1 つ**)・
  砂利・砂・鉱砂のうち選んだものを作り続けます。鉱砂では砂 1 つと、ときどき鉄の粉(10 %)や金の粉(3 %)も出ます。
  電気で動き(30 kW)、作った品は前の器へ送ります。
- 自律共振式ブロック掘削機: 掘りたい岩の面に置き、道具の枠につるはしかシャベルを入れます。
  範囲は 1×1・3×3・**5×5**、深さは **16** まで。オーバークロックしなければ、その道具で人が掘るのと同じ時間で
  1 つずつ掘ります。シルクタッチ・幸運・効率強化・耐久力も同じように効き、道具の耐久値も 1 つ掘るごとに減ります。
  岩盤やチェストは掘りません。電気で動き(40 kW)、掘った品は後ろの器へ送ります。
- 分子超圧縮オートクラフター: 見本の 3×3 に品を並べると、作業台で同じ並びから作れる品を作ります
  (鉄のインゴット 9 つで鉄ブロック、など)。入口は見本の品だけを受けます。1 tick に 1 回
  (オーバークロックとタキオン・オーバークロック加速コアで **10 回**まで)作り、空のバケツなどの残り物も出します。
  電気で動き(20 kW)、作った品は前の器へ送ります。
- キネティック生体粉砕コレクター: 前の **5×3×5** の場で敵対モブをとらえ、(速めなければ)1 秒後に倒します。
  プレイヤーが倒したときの落とし物と経験値が出ます。ボス・名前の付いたモブ・プレイヤー・村人には触れません。
  場の中に落ちている品は、プレイヤーが落とした物も含めてすべて 27 枠へ吸い寄せます。
  電気で動き(50 kW)、品は後ろの器へ送ります。
- オーラカプセル: 粉砕コレクターのカプセルの枠に入れると、ためた経験値で満ちます
  (1 つに **1,395 ポイント**まで。レベル 0 からちょうどレベル 30 になる量です)。使うと、その経験値をすべて受け取ります。
- タキオン・オーバークロック加速コア: オーバークロックできる OUKA の機械の面に付けます
  (1 台に 1 つ。バニラのブロックには付きません)。素手の右クリックで段が替わり(200・400・600・800・1000 %)、
  しゃがんで素手で右クリックすれば段を選べます。万能工業ラチェットのオーバークロック(×1.00〜×2.50)と掛け算になり、
  **全体で ×10 まで**速めます。電気で動き(100 % を超える 100 % ごとに 20 kW)、
  機械の電力も速さの 2 乗で増えます。
- V1.3 の電気で動く設備(造石機・掘削機・クラフター・ポンプ・粉砕コレクター)も、
  万能工業ラチェットでオーバークロックできます。
- 回路投影ブループリントは、畳も屏風も、それぞれ 1 つとして写して建てます。

■ V1.2.0 からの直し
- OUKAビーコン・コア端末でスライダーを動かしたときの目盛りの音と、桜花の杖・弾幕の焦点の
  「色と弾道を選ぶ画面」で選んだときの音が、加わった V1.0.1 から V1.1.0・V1.2.0 まで、ずっと鳴っていませんでした。
  どちらも鳴るように直しました。

■ V1.2「The Heavy Industrial & Kinematics Epoch」—— 重工業の 20 品
- 機械はどれも OUKA の電力網で動きます。電力網はテスラパイロンがつなぎ、ケーブルは要りません。
- どの機械も、動きと音が働きぶりに合わせて変わります(音はすべて一から合成したもので、録音は使っていません)。
- レシピはすべて最初からレシピ本に出ます。

■ 電力(発電・送電・蓄電)
- 超高圧送電テスラパイロン(2 段): **64 ブロック以内**で届き合うパイロンが 1 つの網になり、網の近くの OUKA の機械へ
  無線で電気を配ります。電気が流れている間は、パイロンから機械へ青白い放電の弧が走ります。
- 超伝導磁気蓄電ブロック(SMES): **400 MJ**、充電・放電とも最大 **2 MW**、ロスはありません。面のホログラムに充電の割合。
- 重水減速型核分裂リアクター(5×5×5): ウラン・トリウムの燃料棒で最大 **2 MW**。炉心はチェレンコフ光で青く光ります。
  炉が 800 °C に届くと制御棒が落ちて止まり(スクラム)、冷えて冷却水が来ると動き出します。爆発はしません。
  冷却水は取水タービンから網を通って届きます。
- 太陽熱集光蓄熱タワー(3×3×8): 周り 16 ブロック以内のヘリオスタット(平面鏡、最大 32 枚)が日の光を集め、
  溶融塩に熱を蓄えます。タービンは最大 **400 kW** で、網の求めに合わせて出し、夜も蓄えから出し続けます。
  屋根の下の鏡は集めません。

■ 格納と物流
- 超次元量子圧縮サイロ(5×5×7): チタン外殻・耐熱ガラス・入出力ポートで外殻を組み、側面に制御盤を置くと完成します。
  **2,147,483,647 個**まで格納でき、画面で中身を一覧し、名前や「@MOD 名」で絞り込めます。
  ポート(底面と各側面)はホッパー・コンベア・ほかの MOD の管とそのままつながります。
  制御盤を壊すと中身の札を持った制御盤が落ち、別の場所で組み直せば同じ中身です。
- 高速超伝導リニアコンベア: **毎秒 20 個**を運びます。形(直線・カーブ・坂)は隣から自動で決まり、
  品は落ちず、詰まると並んで待ちます。運ぶ品はブロックに載ったまま見えます。
- リニアコンベアの分岐器: 左・前・右へ 1 つずつ順に分けます。詰まった出口は飛ばします。
- 波長分光式インテリジェント・ソーター: 通る品を、面ごとの決まり(品・タグ・MOD・データ成分・傷んでいるか)で 6 方向へ振り分けます。
- 自律型物流ドローンステーション(3×3): 行き先の港でドローン航路カードをしゃがんで使い、送る港で使うと、
  **Ouka-Cargo Drone** が荷を積んで港どうしを往復します。行き先では甲板(その港のドローンの場所)に降りず、港の脇で浮いたまま
  荷を渡します。区画が読み込まれていない間も、飛ぶ時間ぶん遅れて荷は届きます。

■ 精錬と加工
- 電弧重熱精錬炉(3×3×4): 鉱石を一度に **32 個**入れられ、かまどの **16 倍**の速さで精錬します。
  溶けた金属が樋を流れ、型に流し込まれるのが見えます。
- 超高圧油圧クラッシャー(2 段): 鉱石・原石 1 つから粉 2 つ(粉は精錬してインゴットに)、インゴットからは板を作ります。
  油圧でハンマーを持ち上げ、一気に叩きつけます。
- 高精度オートメーション組立ライン(1×4×2): 3 本のロボットアームとプレスが、電子回路・複合素材の板・機械の骨組みを
  組み立てます。溶接の火花が散ります。
- 分子遠心分離抽出機: 土・砂・砂利(と月のレゴリス)から、チタン・リチウム・石英・ヘリウム3 を微量に取り出します。
  ウランの粉からは確率で濃縮ウラン。

■ 採掘と収穫
- 地殻深層掘削クァーリー(4×4×6): 岩盤を壊さずに、深い鉱脈から鉱石・原油の缶を掘り続けます。
  **ジ・エンドでは掘りません**(ネザーではネザーの鉱石)。
- 超大型重水取水タービン(3×3×3): 水の上に置くと、下の水源から水を汲み上げます(深さ 2 の池で最大、**毎秒 200 バケツ**)。
  汲んだ水は網を通して、水を使う機械(核分裂リアクター・培養槽)へ届きます。
- 自律型重機製材ミル(3×3×2): 周り 8 ブロックの木を見つけて、上から切り倒し、板材にして、切り株に苗を植え直します。
- バイオリアクター培養槽(3×3×3): 有機物と水から、工業用プラスチック・潤滑油の缶・スタミナ増強剤を培養します。

■ 道具と装備
- 万能工業ラチェット: 機械を右クリックで前後を反転(中身と仕事はそのまま)。スニークして右クリックで、
  分岐器・ソーターの出口やコンベアの出口を開け閉めします。電力で動く加工機械では **オーバークロックの盤**が開き、
  速さを ×1.00〜×2.50 から選べます(速くするほど、品 1 つにかかる電力も増えます)。
- 携帯型熱分解カッター: OUKA の機械を 1 秒ねらい続けると、中身ごと持ち物へ解体します(1 滴もこぼしません)。
- 回路投影ブループリント: 向かい合う 2 つの角をスニークして使うと、その間(1 辺 16 マスまで)を写します。
  写したブループリントを持つと、建つ場所に**実物大の半透明のホログラム**が映り(置ける所は水色・品が足りない所は琥珀色・
  ふさがった所は赤)、使うと持ち物の品で建てます。
- 全天候型重工業防護外骨格(4 部位): 4 つそろえると、感電・熱・落下で傷つかず、溶岩の中を泳げ、採掘が 3 倍の速さになります。

■ V1.1.0 からの直し
- 桜花合金ブロックを掘っても何も落ちなかったのを直しました。
- シェルターの落とし物の表が古い形式だったのを直しました。

■ OUKA ビーコン
- 3×3×3 の構造物です。置いた場所が最下段の中央になります。
- 台座が要ります。ネザライト・ダイヤ・エメラルド・桜花合金のブロックを、
  8 段(3・3・5・5・7・7・9・9)で **328 個**。全部そろって初めて起動します。
- 起動すると、**半径 1,000 ブロック**の中にいるプレイヤー全員に効果を配ります。
  ビーコンのいる区画が読み込まれていなくても届きます。観戦者には配りません。
- 配る効果は 10 種類(移動速度・採掘速度・攻撃速度・攻撃力・跳躍・落下耐性・
  衝撃吸収・再生・満腹度・耐性と部分的な耐火・暗視)で、それぞれ **0.00 から 20.00 まで
  段階なし**で決められます。あわせて、エンチャントの金リンゴと同じ効果が常時つきます。
- ビーコンのどこかを右クリックすると、**すりガラスの端末**が開きます。スライダーを
  ドラッグ、マウスホイールで 0.1 刻み、Shift を押しながらで 0.01 刻み。
  ALL MAX / DEFENSIVE MATRIX / MINER'S PARADISE の 3 つの一括設定があります。
- 変更できるのは、置いた本人か OP だけです(8 ブロック以内)。ほかの人には読み取り専用で開きます。
- どこか 1 つでも壊すと 27 個すべてが外れ、設定を持ったビーコンが 1 つ落ちます。

■ サークル弾
- 桜花の杖(Ouka Caster)は 0.25 秒ごとに 1 発。直線・螺旋・追尾。
- 弾幕の焦点(Danmaku Focus)は 2 秒ごとに一斉射。収束(見ている点に 12 発)と
  周囲滞空シールド(8 発が回り、6 ブロック以内の敵へ飛ぶ)。
- どちらもスニーク+右クリックで、色と弾道を選ぶホログラムの画面が開きます。
- 色は 12 種類。それぞれ効果が違います(鈍化と魅了、画面の閃光、火柱、
  不死者へ倍の傷、引き寄せ、凍結、味方の回復と敵への毒、壁を貫く直線、
  索敵範囲を 8 割削る、2 つに分かれて追尾、3 回跳ね返る、ほか 11 色を巡る)。
- 着弾した場所から平らな輪が広がり、**通った敵を消滅させます**。ボスには最大体力の 2 割。
  プレイヤー・ペット・動物には当たりません。ブロックは壊れず、燃えません。
- 飛んでいる弾はその色の軌跡を残します。桜花桃だけは桜の花びらで、何秒も落ち続けます。

■ オペレーティング・シェルター・ブロック(V1.1 で追加)
- **OP 権限を持つ人だけ**が置けて、壊せます。ほかの人はどのゲームモードでも一切できません。
- どんな爆発も通りません。Mob も、ピストンも、クリエイティブの破壊も通しません。
  バニラが岩盤を入れている 11 のタグすべてに、同じように入れてあります。
- OP はサバイバルでも普通に掘れて回収できます(ダイヤ以上のつるはし)。
- OP でない人が触れると、面に六角のエネルギー格子が張り、金属の反発音と火花が返ります。
- 作り方: 黒曜石 4・ネザライトインゴット 4・桜花合金ブロック 1 で 2 個。

■ 音
- OUKA の音は **93 種**です(V1.3 で 37 種ふえました)。新しい音も含めて、どれも **OUKA のために一から合成したもの**で、
  ほかのゲームの音も、素材集の音も、録音も使っていません。
- OUKA のブロック(V1.2 の機械も含みます)を壊す音・置く音・踏む音(畳と縁側の足音は OUKA の音です)と、
  和室の品のいくつかの音(木を置く音、抹茶を飲む音、火打石で灯す音など)、オーラカプセルを使ったときの音などには、
  バニラの音を使っています。
- **12 色は 12 半音。**サークル弾の音は色ごとに高さが違い、桜花桃から神光虹までが
  ちょうど 1 オクターブに収まります。**音を聞けば、どの色が飛んだか分かります。**
- 祭壇は、組み上がるとき・目を開けるとき・閉じるとき・解体されるときに鳴り、
  起動しているあいだは低い唸りを出します。
- 端末を開いた音や、変更が断られた音は、**その本人にだけ**聞こえます。
- 字幕(「サブタイトルを表示」)に対応しています。

■ 道具とレシピ
- 桜花合金インゴット / 桜花合金ブロック(相互に変換できます)
- OUKA ビーコン
- 桜花の杖(Ouka Caster)
- 弾幕の焦点(Danmaku Focus)
- V1.2 の機械・道具・装備・素材(上の V1.2 の節)
- V1.3 の和室の 30 品と工場の設備 10 種、それに共振リンカー・オーラカプセル・導管(上の V1.3 の節)
  レシピはゲーム内のレシピ本で見られます。

■ マルチプレイ
- サーバーとクライアントの両方に入れてください。
- 端末の操作はすべてサーバー側で確かめています。範囲外の値や、権限のない変更は通りません。
- オーバークロックの盤も同じです。ラチェットを持ち、8 ブロック以内にいて、そこで建築できる人だけが変えられ、
  ×1.00〜×2.50 の外の値は通りません。
- V1.3 の設備の画面(トランシーバー・I/O バス・掘削機・造石機・クラフター・加速コア・ホッパーのフィルター)も同じです。
  8 ブロック以内にいて、そこで建築できる人だけが変えられます。

■ ライセンス
- OUKA: MIT(LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT(LICENSES/GeckoLib_MIT.txt)。改変せずそのまま同梱しています。

------------------------------------------------------------------

[English]

■ What you need
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

■ Installing (on both the client and the server)
1. Put the two jars from this zip's mods/ folder into your Minecraft mods folder.
   - ouka-1.3.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Put Fabric API in the same folder (the version above or newer).
3. To play on a server, install the same two jars and Fabric API on the server as well.

■ Please note
- GeckoLib is bundled in this zip. If another mod already installs GeckoLib, keep only
  one copy — two will stop the game from starting.
- When updating from an earlier version, remove the old OUKA jar (ouka-1.2.0+mc26.3.jar, ouka-1.1.0+mc26.3.jar,
  ouka-1.0.1+mc26.3.jar and so on) from the mods folder. Two OUKA jars will stop the game from starting.
- There is no config file and there are no admin commands.

■ V1.3 "The Washitsu Architectural Masterpiece" — thirty pieces for a Japanese room, and ten factory facilities
- The thirty room pieces have their own new creative tab, OUKA Washitsu. The factory facilities are in the OUKA
  tab.
- The facilities that need power take it from OUKA's power grid, like the V1.2 machines.
- All thirty-seven new sounds are synthesised from nothing (some sounds, such as breaking blocks and wood being set
  down, are vanilla sounds; see Sound below).
- Every recipe is in the recipe book from the start.

■ The room: floors (tatami, engawa, ceiling, wall)
- Igusa Tatami Mat: one mat covers two blocks. An empty-hand right-click changes its border (heri); there are four.
- Stand in a room of **8 or more** joined tatami cells and you get Stamina: hunger drains half as fast.
- Borderless Checkered Tatami: it lies crosswise to a neighbouring checkered mat, so laid together they make a
  checkerboard. Sneak-right-click one with an empty hand to turn it. It counts as a cell of a tatami room.
- Polished Hinoki Engawa Decking, Sugi Cedar Grooved Ceiling and Juraku Earthen Plaster Wall. The ceiling hangs only
  under a solid block. The tatami and the engawa each have their own footsteps.

■ The room: shoji and fusuma
- Shoji Lattice Paper Sliding Door and Gold-Leaf Sansui Fusuma: sliding doors two blocks tall. An empty-hand
  right-click or a redstone signal slides a door open or shut, almost a full block. You can walk through an open one.
- Placed beside another door facing the same way, it takes the other groove, and the two slide past each other.
- Four fusuma in a row make one landscape painting.

■ The room: the lintel, and what fits on it or hangs from it
- Kamoi & Nageshi Lintel Framing: use a Ranma Openwork Transom on it and the ranma fits on top. A Seasonal Kakejiku
  or a Katanakake Sword Stand hangs on its face (when no ranma is fitted); a Bamboo Sudare Roll-up Blind, an Indigo
  Family-Crest Noren or a Cast-Iron Furin hangs underneath.
- Ranma Openwork Transom: sneak-use it to stand it on its own. Light passes through it. An empty-hand right-click
  changes the carving (pine and crane, or waves and plovers).
- Four-Panel Gold Leaf Byobu: stands two blocks wide and two high, to the right of where you place it.
- Bamboo Sudare Roll-up Blind: an empty-hand right-click rolls it (lowered, half, rolled up). Up to three hung one
  under another make one blind.
- Indigo Family-Crest Noren: parts as anyone walks through it.
- The sudare, the noren and the furin hang under a lintel or a solid block, and fall without it.

■ The room: furniture
- Solid Zelkova Low Chabudai: its top has four spaces; right-click one with an item to display it there, and an
  empty hand takes it back. Sneak to place blocks on it. The Matcha Ceremony Whisk & Bowl and the Urushi Lacquer
  Jubako sit on the table top when placed on it.
- Brocade Zabuton and Zaisu Chair & Kyosoku Armrest: right-click with an empty hand to sit; sneak to stand up. The
  zaisu faces whoever placed it, and seats one person at a time.
- Paulownia Tansu with Brass Latches: **27 slots**. Hoppers fill and empty it like a chest. The drawers slide out
  while it is open.
- Matcha Ceremony Whisk & Bowl: right-click with an empty hand to whisk the tea (2 s), then again to drink it. It
  restores full health and gives Haste II for **3 minutes**. One bowl every **5 minutes**, and dying does not reset
  the wait.
- Urushi Lacquer Jubako: holds vanilla foods only, three tiers of three. Break it and the food stays inside the
  item; place it and the food is back. Fire never burns it away.

■ The room: tokonoma and garden
- Shibori Cedar Tokobashira and Seasonal Kakejiku: the scroll hangs two blocks tall on a wall or on a lintel's face.
  Its painting follows the season, a new one every **8 in-game days** (cherry blossom, waterfall, autumn maple,
  snowy peak).
- Bamboo Ikebana, Suiseki Viewing Stone and Celadon Koro Incense Burner stand only on a support. A thread of incense
  smoke rises from the koro; an empty hand puts it out, and flint and steel lights it again.
- Katanakake Sword Stand: right-click with a sword to rest it there, two at most; an empty hand takes the top one
  back. It stands on a floor, or hangs on a wall or on a lintel's face.
- Square Andon Lantern, Hexagonal Bonbori Lamp and Granite Yukimi-Toro Lantern: an empty hand lights them and puts
  them out. The bonbori stands two blocks tall. Snow settles on the yukimi-toro's roof in winter (days 24 to 31 of
  every 32) and always in snowy places.
- Bamboo Shishi-odoshi: the bamboo tube fills, tips and strikes its stone every **4.4 seconds**.
- Cast-Iron Furin: rings in the wind — now and then in a clear breeze, often in rain and storms, never in a closed
  room.
- Kaya Go & Shogi Board: right-click a point with an empty hand to play black and white stones in turn on its nine
  lines; sneak-right-click to take a stone back. Sneak-right-click its side with an empty hand to turn it between go
  and shogi (the stones are cleared).

■ The factory: logistics
- Hyper-Impulse Extractor Hopper: pulls from the container above, vacuums items lying on top, and pushes
  **64 items a tick** (512 times as fast as a vanilla hopper) into the chest or another mod's item pipe its spout
  points at; an OUKA conveyor takes only one a tick. Sneak-use it with an empty hand to set its filter (five slots,
  each set to Exact, Tag or Ignore damage). A redstone signal stops it. It needs no power.
- OUKA Matter Transceiver [32m]: place it on a face of a container (a chest, cauldron, machine or vault port), then
  use a Resonance Linker on the sender and then on its receivers. One sender feeds up to **4 receivers** within
  **32 blocks** in any direction, through walls: up to **64 items** a tick (set from 1 to 64 on its screen) and
  **1 bucket** a tick. Only within one dimension. It needs no power.
- Quantum Vault I/O Bus Terminal: place it against any part of a quantum vault, with a container or a conveyor
  behind it. Export sends the items you choose (up to **9 entries**) into the chest or another mod's item pipe
  behind, up to **256 a tick**, and leaves each entry's keep count in the vault (an OUKA conveyor takes only one a
  tick). Import takes everything in the container behind into the vault. It needs no power.
- Cryo-Fluid Superconductor Pump and Cryo-Fluid Superconductor Pipe: the pump draws from the fluid container on the
  face you place it against and sends into the pipes on its other five faces: **8 buckets a tick**, shared in turn
  among every outlet of the network, all in the same tick (water, lava or any mod's fluid). One network holds up to
  **4,096 pipes**. The pump runs on power (10 kW); the pipes need none. The fission core and the culture vat also
  run on piped water.
- Pocket Dimensional Uplink PDA: use it on a formed vault's controller to bind it, then use it in the air to open
  that vault's screen, even from another dimension. It can put your whole inventory (not the hotbar, not the PDA)
  into the vault. Anyone holding a bound PDA can open the vault, so look after it as you would a key.

■ The factory: production
- Volcanic-Hydraulic Cobblestone Synthesizer: give it a bucket of lava and a bucket of water, which are never used
  up, and it makes whichever you choose: cobblestone (**1 every 8 ticks**), gravel, sand or ore sand. Ore sand
  gives one sand, with a 10 % chance of iron dust and a separate 3 % chance of gold dust. It runs on power (30 kW)
  and pushes what it makes out of its front.
- Autonomous Resonant Miner Head: place it on the rock face you want to mine and put a pickaxe or shovel in its tool
  slot. The area is 1×1, 3×3 or **5×5**, up to **16** deep. Without overclock it takes as long over each block as
  you would with that tool; Silk Touch, Fortune, Efficiency and Unbreaking work as they do for you, and the tool
  wears with each block. It leaves bedrock and chests alone. It runs on power (40 kW) and sends what it mines into
  the container behind it.
- Molecular Micro-Crafter: set a 3×3 pattern and it crafts what that pattern makes on a crafting table (nine iron
  ingots into an iron block, and so on). It takes in only the pattern's items, crafts once a tick (up to
  **10 times** a tick with overclock and a Tachyon Acceleration Pylon), and leftovers such as empty buckets come out
  too. It runs on power (20 kW) and pushes what it makes out of its front.
- Kinetic Stasis Grinder: holds hostile mobs in a **5×3×5** field in front of it and, after a second at normal
  speed, dispatches them for the loot and XP of a player kill. It never touches bosses, named mobs, players or
  villagers. It pulls every loose item in its field into its 27 slots, including anything a player drops there. It
  runs on power (50 kW) and pushes the loot out of its back.
- Aura Capsule: put it in the grinder's capsule slot and it fills with the stored XP (up to **1,395 points** each,
  enough to take a player from level 0 to level 30). Use it to take in all the XP it holds.
- Tachyon Acceleration Pylon: attaches to a face of an OUKA machine that can be overclocked, one per machine, never
  to a vanilla block. An empty-hand right-click steps through 200, 400, 600, 800 and 1000 %; sneak-right-click with
  an empty hand to pick one. It multiplies the Industrial Omni-Wrench's overclock (×1.00 to ×2.50),
  **up to ×10 in all**. It runs on power (20 kW for every 100 % above 100 %), and the machine's power grows with
  the square of its speed.
- The V1.3 facilities that run on power (synthesizer, miner, crafter, pump, grinder) can be overclocked with the
  Industrial Omni-Wrench too.
- The Holographic Circuit Blueprint records and builds each tatami and each byobu as one piece.

■ Fixed since V1.2.0
- Two sounds added in V1.0.1 never played in V1.0.1, V1.1.0 or V1.2.0: the tick as you drag a slider on the OUKA
  Beacon Core Terminal, and the sound as you change a choice on the colour and trajectory selector of the Ouka
  Caster and the Danmaku Focus. Both play now.

■ V1.2 "The Heavy Industrial & Kinematics Epoch" — twenty pieces of heavy industry
- Every machine runs on OUKA's power grid. Tesla pylons join the grid; there are no cables.
- Every machine's movement and sound follow how hard it is working. Every sound is synthesised from nothing;
  nothing is recorded.
- Every recipe is in the recipe book from the start.

■ Power (generation, transmission, storage)
- Wireless Tesla Pylon (two blocks tall): pylons within **64 blocks** of one another form one grid and power the
  OUKA machines near it without wires. While power flows, blue-white arcs run from the pylon to the machines.
- SMES Quantum Battery: **400 MJ**, charging and discharging at up to **2 MW**, with no loss. A hologram on its face
  shows the charge.
- Heavy-Duty Fission Core (5×5×5): up to **2 MW** from uranium or thorium fuel rods. The core glows blue with
  Cherenkov light. At 800 °C the control rods drop and it stops (a scram); it restarts once it has cooled and
  coolant is arriving. It never explodes. Coolant water reaches it through the grid from the desalinator.
- Solar-Thermal Molten Salt Tower (3×3×8): heliostats (flat mirrors, up to 32) within 16 blocks gather sunlight
  and store the heat in molten salt. The turbine gives up to **400 kW**, follows what the grid asks for, and keeps
  running at night on what it stored. A mirror under a roof gathers nothing.

■ Storage and logistics
- Quantum-Compression Vault (5×5×7): build the shell from titanium casing, heat-resistant glass and I/O ports, then
  place the controller on a side to complete it. It holds up to **2,147,483,647 items**; its screen lists the contents
  and filters them by name or by "@mod". The ports (the bottom and each side) connect straight to hoppers, conveyors
  and other mods' pipes. Breaking the controller drops it with a tag of the contents; build the shell again anywhere
  and the contents are the same.
- Maglev Conveyor: carries **20 items a second**. Its shape (straight, curve, slope) follows its neighbours
  automatically. Nothing falls off; when the way is blocked, items queue and wait. You can see each item riding it.
- Maglev Splitter: hands items out one at a time — left, front, right — and skips an exit that is blocked.
- Spectral Sorter: sends each passing item in one of six directions by per-face rules (item, tag, mod,
  data component, or damaged).
- Logistics Drone Port (3×3): sneak-use a Drone Route Card on the destination port, then use it on the sending
  port, and an **Ouka-Cargo Drone** carries loads between the two. At the destination it does not land on the deck,
  which is that port's own drone's place: it hovers beside the port and hands the load over. While the area is
  unloaded, the load still arrives, delayed by the flight time.

■ Smelting and processing
- Blast-Arc Smelting Foundry (3×3×4): takes **32 ores** at a time and smelts **16 times** faster than a furnace.
  You can watch the molten metal run down the trough into the moulds.
- Hydraulic Impact Crusher (two blocks tall): one ore or raw ore makes two dusts (smelt dust into ingots); an ingot
  makes a plate. The hydraulics lift the hammer and slam it down.
- Automated Precision Assembly Line (1×4×2): three robot arms and a press assemble electronic circuits, composite
  plates and machine frames, with welding sparks.
- Molecular Centrifuge Extractor: draws traces of titanium, lithium, quartz and helium-3 from dirt, sand and gravel
  (and lunar regolith). From uranium dust it sometimes yields enriched uranium.

■ Mining and harvesting
- Sub-Crustal Thermal Bore (4×4×6): digs ore and crude oil canisters from deep veins without end, without breaking
  bedrock. **It does not dig in the End** (in the Nether it digs Nether ores).
- Hydro-Vapor Desalinator (3×3×3): placed over water, it pumps from the sources below (at most **200 buckets a
  second**, from a pond two blocks deep). The grid carries the water to the machines that use it (the fission core
  and the culture vat).
- Automated Timber Mill (3×3×2): finds trees within 8 blocks, fells them from the top down, turns them into planks
  and replants the stump.
- Bio-Reactor Culture Vat (3×3×3): cultures industrial plastic, lubricant canisters and stamina serum from organic
  matter and water.

■ Tools and gear
- Industrial Omni-Wrench: use it on a machine to turn it front to back (its contents and work carry on). Sneak-use
  it to open or close a splitter's or sorter's exit, or a conveyor's exit. On a powered processing machine it opens
  the **overclock panel**: choose a speed from ×1.00 to ×2.50 (the faster, the more power each item costs).
- Thermal Demolition Laser: hold it on an OUKA machine for one second and the machine comes apart into your
  inventory with everything inside it (not a drop is spilt).
- Holographic Circuit Blueprint: sneak-use two opposite corners to record what lies between them (up to 16 blocks
  a side). While you hold the recorded blueprint, a **life-size translucent hologram** shows where it will stand
  (cyan where it can be placed, amber where you are short of items, red where the space is taken); use it to build
  it from the items you carry.
- Industrial Hazard Exoskeleton (four pieces): wear all four and electric shocks, heat and falls no longer hurt you,
  you can swim in lava, and you mine three times as fast.

■ Fixed since V1.1.0
- Mining a Block of Ouka Alloy now drops it (it dropped nothing).
- The shelter's loot table was in an old format; it is fixed.

■ The OUKA Beacon
- A 3×3×3 structure. Where you place it becomes the middle of the bottom layer.
- It needs a pedestal: **328 blocks** of netherite, diamond, emerald or Ouka alloy,
  in eight layers (3, 3, 5, 5, 7, 7, 9, 9). It only wakes when all 328 are present.
- Once awake it reaches every player within **1,000 blocks**, even while the beacon's
  own area is unloaded. Spectators receive nothing.
- It gives ten effects (speed, mining speed, attack speed, strength, jump, safe fall,
  absorption, regeneration, food, resistance with partial fire resistance, and night
  vision), each tuned **steplessly from 0.00 to 20.00**, plus the constant effects of
  an enchanted golden apple.
- Right-click any part of it to open a **frosted-glass terminal**: drag a slider, or use
  the mouse wheel in steps of 0.1, or 0.01 with Shift. Three presets are provided:
  ALL MAX, DEFENSIVE MATRIX and MINER'S PARADISE.
- Only the player who placed it, or an operator, may change it, and only from within
  8 blocks. Everyone else sees a read-only terminal.
- Breaking any part removes all 27 and drops one beacon carrying its tuning.

■ The circle projectiles
- The Ouka Caster fires one circle every 0.25 s: straight, spiral or homing.
- The Danmaku Focus fires a barrage every 2 s: converging (twelve circles onto the point
  you are looking at) or orbital guard (eight circles orbit you and launch at an enemy
  within 6 blocks).
- Sneak and use either item to open a holographic selector for colour and trajectory.
- There are twelve colours, each with its own effect: slowness and charm, a screen flash,
  a plasma pillar, double damage to the undead, a pull, a freeze, healing for allies and
  poison for enemies, a line that pierces walls, an 80% cut to a mob's follow range, a
  split into two homing circles, three bounces, and one that cycles the other eleven.
- Where a circle stops, a flat ring spreads and **erases the enemies it crosses**; bosses
  take 20% of their maximum health instead. Players, pets and animals are untouched, and
  no block is broken or set alight.
- A circle in flight leaves a trail in its own colour. Sakura Pink leaves cherry petals,
  which keep falling for several seconds.

■ The Operating Shelter Block (added in V1.1)
- **Only a player with operator permission** can place or break it. Nobody else can, in any
  game mode.
- No explosion gets through, and neither does a mob, a piston, or a creative-mode break.
  It sits in all eleven block tags that vanilla puts bedrock in.
- An operator mines it normally in survival and gets it back (a diamond pickaxe or better).
- When anyone else touches it, a hexagonal energy lattice snaps across its faces, with a
  metallic repulsion and sparks.
- Crafted from 4 obsidian, 4 netherite ingots and 1 block of Ouka alloy, for 2.

■ Sound
- OUKA has **ninety-three sounds** of its own (thirty-seven new in V1.3). Every one of them, the
  new ones included, was **synthesised from nothing for OUKA**. No sound from another game, no
  sample library, no recording.
- Vanilla sounds are used for breaking, placing and stepping on OUKA blocks (the V1.2 machines
  included; the tatami and engawa footsteps are OUKA's own), for some of the room's actions (wood
  being set down, drinking the matcha, lighting with flint and steel and so on), for using an Aura
  Capsule, and for a few others.
- **Twelve colours are twelve semitones.** Each circle colour sounds at its own pitch, from
  Sakura Pink to Prismatic Chroma, exactly one octave apart end to end — **you can hear
  which colour flew.**
- The beacon sounds when it is assembled, when it wakes, when it closes and when it breaks
  apart, and hums quietly while it is awake.
- Opening the terminal, and being refused by it, are heard **only by the player it happened
  to** — nobody nearby hears them.
- Subtitles are supported.

■ Items and recipes
- Ouka Alloy Ingot / Block of Ouka Alloy (each converts to the other)
- OUKA Beacon
- Ouka Caster
- Danmaku Focus
- V1.2's machines, tools, gear and materials (the V1.2 section above)
- V1.3's thirty room pieces and ten factory facilities, plus the Resonance Linker, the Aura Capsule and the pipe
  (the V1.3 section above)
  The recipes are in the in-game recipe book.

■ Multiplayer
- Install on both the server and the client.
- Every terminal action is checked on the server: values outside the range, and changes
  from anyone without permission, are refused.
- So is the overclock panel: only a player holding the wrench, within 8 blocks, who may build
  there can change it, and nothing outside ×1.00 to ×2.50 is accepted.
- So are the V1.3 facilities' screens (the transceiver, I/O bus, miner, synthesizer, crafter,
  accelerator and the hopper's filter): only a player within 8 blocks who may build there can
  change them.

■ Licences
- OUKA: MIT (LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT (LICENSES/GeckoLib_MIT.txt), bundled unmodified.
